# -*- coding: utf-8 -*-
"""探测 ObjectARX 2012 (18.2) 托管程序集里是否含项目依赖的关键 CAD API。"""
import os

tmp = os.path.expandvars(r"%TEMP%\la_acad2012")
files = {
    "acmgd.dll": os.path.join(tmp, "lib", "acmgd.dll"),
    "acdbmgd.dll": os.path.join(tmp, "lib", "acdbmgd.dll"),
}

# 元数据 #Strings 堆是 UTF-8，类型名/方法名可直接按 ASCII 检索
NEED = [
    # 拾取器（本次「文件命名」的核心）
    "PromptNestedEntityOptions", "PromptNestedEntityResult", "GetNestedEntity",
    "PromptSelectionOptions", "PromptSelectionResult", "GetSelection",
    "MessageForAdding", "AllowDuplicates", "SelectionFilter", "PickPoint",
    "PromptEntityResult", "PromptPointResult", "GetNestedEntityOptions",
    # 面板/事务常用
    "LayoutManager", "BlockTransform", "AttributeReference", "AttributeCollection",
    "BlockReference", "PromptStatus", "SelectionSet", "ObjectIdCollection",
    # 打印链路
    "PlotConfigManager", "RefreshCode", "PlotEngine", "PlotInfo", "PlotSettingsValidator",
    "PlotSettings", "PlotType", "PlotProgressDialog", "PlotConfig", "RefreshPC3DevicesList",
    # 图形
    "TransientManager", "TransientDrawingMode", "IntegerCollection",
    # 应用层
    "ApplicationServices", "DatabaseServices", "EditorInput", "GraphicsInterface",
    "Colors", "PaletteSet", "AcadPreferences", "SetSystemVariable",
    # 多文档
    "DocumentCollection", "DocumentManager", "DocumentLock",
    # 其他
    "Runtime.Exception", "CommandMethodAttribute", "LispFunctionAttribute",
    "DatabaseServices.Filters", "LayerTableRecord", "RegAppTableRecord",
]

print("== 关键 API 逐一检索 ==")
for label, p in files.items():
    if not os.path.exists(p):
        print("MISSING FILE:", p)
        continue
    d = open(p, "rb").read()
    print("\n--- %s (%d bytes) ---" % (label, len(d)))
    for name in NEED:
        blob = name.encode("ascii")
        print("  %-32s %s" % (name, "YES" if blob in d else "-- no"))
