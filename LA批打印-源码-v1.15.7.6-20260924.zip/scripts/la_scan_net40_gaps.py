# -*- coding: utf-8 -*-
"""统计 src/ 里用到「.NET 4.0 没有、需 4.5+」的 API，评估 net40 移植量。"""
import io, os, re

ROOT = r"src"

# 关键字 -> 首次引入的框架
PATTERNS = [
    ("IReadOnlyList",      "4.5", r"\bIReadOnlyList<"),
    ("IReadOnlyDictionary", "4.5", r"\bIReadOnlyDictionary<"),
    ("IReadOnlyCollection", "4.5", r"\bIReadOnlyCollection<"),
    ("ReadOnlyDictionary", "4.5", r"\bReadOnlyDictionary<"),
    ("CallerMemberName",   "4.5", r"CallerMemberName"),
    ("CallerFilePath",     "4.5", r"CallerFilePath"),
    ("CallerLineNumber",   "4.5", r"CallerLineNumber"),
    ("Array.Empty",        "4.6", r"Array\.Empty<"),
    ("Task.Run",           "4.5", r"Task\.Run"),
    ("Task.Delay",         "4.5", r"Task\.Delay"),
    ("async/await",        "4.5", r"\basync\b|\bawait\b"),
    ("IProgress",          "4.5", r"\bIProgress<"),
    ("WeakReference<T>",   "4.5", r"WeakReference<"),
    ("ExceptionDispatchInfo", "4.5", r"ExceptionDispatchInfo"),
    ("GetFieldValue",      "4.5", r"GetFieldValue<"),
    ("Enum.GetValues<T>",  "5.0", r"Enum\.GetValues<"),
    ("ValueTuple",         "4.7", r"\(\s*\w+\s+\w+\s*,\s*\w+\s+\w+\s*\)\s*="),
    ("Equals(string,StringComparison)", "4.0", r"\.Equals\([^)]*StringComparison"),
    ("nameof",             "6.0 lang", r"\bnameof\("),
    ("using var",          "8.0 lang", r"^\s*using var "),
    ("switch expr",        "8.0 lang", r"=>\s*$"),
]

total = {}
detail = {}
for dirpath, dirs, files in os.walk(ROOT):
    # 跳过 obj/bin
    if re.search(r"[\\/](obj|bin)[\\/]", dirpath + "\\"):
        continue
    for f in files:
        if not f.endswith(".cs"):
            continue
        p = os.path.join(dirpath, f)
        s = io.open(p, "r", encoding="utf-8-sig", errors="ignore").read()
        for label, fw, rx in PATTERNS:
            n = len(re.findall(rx, s, re.M))
            if n:
                total[label] = total.get(label, 0) + n
                detail.setdefault(label, []).append((n, p))

print("== 需要 4.5+ 的 API 使用统计（net40 会编译失败的那些）==")
for label, fw, _ in PATTERNS:
    n = total.get(label, 0)
    if not n:
        continue
    print("\n[%s]  needs .NET %s   共 %d 处" % (label, fw, n))
    for cnt, p in sorted(detail[label], reverse=True)[:12]:
        print("    %3d  %s" % (cnt, p))
