# -*- coding: utf-8 -*-
"""在 package-release.ps1 里增加 AutoCAD 2010-2012 发布包。"""
import io, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REL = r"scripts\package-release.ps1"
FULL = os.path.join(ROOT, REL)

raw = open(FULL, "rb").read()
if raw.startswith(b"\xef\xbb\xbf"):
    s, enc = raw.decode("utf-8-sig"), "utf-8-sig"
else:
    s, enc = raw.decode("utf-8"), "utf-8"

def sub(old, new, tag, must=None, gone=None):
    global s
    n = s.count(old)
    if n != 1:
        print("FAIL [%s] 期望命中 1 次，实际 %d 次：\n%s" % (tag, n, old[:300]))
        sys.exit(1)
    s = s.replace(old, new, 1)
    for m in (must or []):
        if m not in s:
            print("FAIL [%s] 缺少: %s" % (tag, m)); sys.exit(1)
    for g in (gone or []):
        if g in s:
            print("FAIL [%s] 仍存在: %s" % (tag, g)); sys.exit(1)
    print("OK   [%s]" % tag)

# ── 1. 新增参数 ──
sub(
    """    [string]$ZwcadOutput,
    [string]$LegacyAcadOutput,
    [string]$CoreAcadOutput
)""",
    """    [string]$ZwcadOutput,
    [string]$LegacyAcadOutput,
    [string]$Legacy2012AcadOutput,
    [string]$CoreAcadOutput
)""",
    "1 新增 Legacy2012AcadOutput 参数",
    must=["$Legacy2012AcadOutput"],
)

# ── 2. 解析输出目录 ──
sub(
    """    $legacyAcadOutput = Resolve-BuildOutput -Candidate $LegacyAcadOutput -DefaultRelativePath 'bin-acad'
    $coreAcadOutput = Resolve-BuildOutput -Candidate $CoreAcadOutput -DefaultRelativePath 'bin-acad2025-2027'""",
    """    $legacyAcadOutput = Resolve-BuildOutput -Candidate $LegacyAcadOutput -DefaultRelativePath 'bin-acad'
    $legacy2012AcadOutput = Resolve-BuildOutput -Candidate $Legacy2012AcadOutput -DefaultRelativePath 'bin-acad2012'
    $coreAcadOutput = Resolve-BuildOutput -Candidate $CoreAcadOutput -DefaultRelativePath 'bin-acad2025-2027'""",
    "2 解析 bin-acad2012",
    must=["$legacy2012AcadOutput = Resolve-BuildOutput"],
)

# ── 3. 增加打包调用（排在 2015-2024 之前，按版本递增排列）──
sub(
    """    # AutoCAD 2015-2024 共用同一个 net48 DLL，只生成一个完整兼容包。""",
    """    # AutoCAD 2010-2012 共用同一个 net45 DLL（ObjectARX R18.x，无 AcCoreMgd，不支持 PNG/JPG 转图）。
    Add-ReleasePackage `
        -FolderName 'AutoCAD2010-2012' `
        -ArchiveName "LA批打印-AutoCAD2010-2012-v$Version.zip" `
        -BuildOutput $legacy2012AcadOutput `
        -MainDll 'AcadBatchPlot2012.dll' `
        -InstallerSource (Join-Path $root 'installer_acad2012')

    # AutoCAD 2015-2024 共用同一个 net48 DLL，只生成一个完整兼容包。""",
    "3 增加 AutoCAD2010-2012 打包",
    must=[
        "-FolderName 'AutoCAD2010-2012'",
        "-MainDll 'AcadBatchPlot2012.dll'",
        "-InstallerSource (Join-Path $root 'installer_acad2012')",
    ],
)

with io.open(FULL, "w", encoding=enc, newline="") as f:
    f.write(s)
print("\n已写回 %s (enc=%s)" % (REL, enc))
print("ALL DONE")
