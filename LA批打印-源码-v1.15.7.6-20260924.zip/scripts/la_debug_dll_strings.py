# -*- coding: utf-8 -*-
"""调试：在 DLL 原始字节里定位程序集名与中文串的真实编码/大小写。"""
import os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DLL = os.path.join(ROOT, "bin-acad2012", "AcadBatchPlot2012.dll")
data = open(DLL, "rb").read()
low = data.lower()

print("=== 大小写无关的 ASCII 子串命中次数 ===")
for s in ("acmgd", "acdbmgd", "coremgd", "sharpzip", "pdfsharp", "newtonsoft", "valuetuple",
          "docnet", "presentationframework", "windowsbase", "system.xaml", "system.windows.forms",
          "mscorlib", "system.core", "acad", "autodesk"):
    print("  %-26s %d" % (s, low.count(s.encode("ascii"))))

print()
print("=== 打印包含 acmgd / sharpzip 的上下文 ===")
for needle in ("acmgd", "sharpzip", "docnet"):
    b = needle.encode("ascii")
    pos = 0
    shown = 0
    while True:
        i = low.find(b, pos)
        if i < 0 or shown >= 4:
            break
        ctx = data[max(0, i - 24):i + 40]
        print("  [%s] @%d: %s" % (needle, i, repr(ctx)))
        pos = i + 1
        shown += 1

print()
print("=== 中文串编码探测 ===")
for s in ("图幅", "增加图幅", "文件命名", "通用型批量打印", "划" ):
    u16 = s.encode("utf-16-le")
    u8 = s.encode("utf-8")
    print("  %-8s utf16le(even)=%d utf16le(odd)=%d utf8=%d" % (
        s,
        data[0:].count(u16),
        data[1:].count(u16),
        data.count(u8),
    ))

print()
print("=== BAML 里的 XAML 中文（UTF-8）示例 ===")
for s in ("增加图幅", "增加横线"):
    print("  %-8s utf8=%d utf16=%d" % (s, data.count(s.encode("utf-8")), data[0:].count(s.encode("utf-16-le"))))
