# -*- coding: utf-8 -*-
"""图框块扫描提速：按图框世界包围盒预筛布局文字候选 + 轻量分段计时。

编码安全：先按 utf-8-sig 读，失败回退 gbk；写回保持原编码（探测到的字节）。
每个替换带 must/gone 断言，确保正好命中一次。
"""
import io
import os
import sys
import traceback

ROOT = r"D:\00YPL内部环境V1.0\03-插件合集\LA打印\batchPrintZWCAD-1.15.7.6"


def _excepthook(exc_type, exc, tb):
    try:
        with open(os.path.join(ROOT, "scripts", "_opt_trace.txt"), "w", encoding="utf-8") as f:
            traceback.print_exception(exc_type, exc, tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc, tb)


sys.excepthook = _excepthook

FILES = {
    "cad": os.path.join(ROOT, "src", "Common", "Services", "Scanning", "CadTextExtractor.cs"),
    "tb": os.path.join(ROOT, "src", "Common", "Services", "Scanning", "TitleBlockScanner.cs"),
}


def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8-sig"), raw
    except UnicodeDecodeError:
        return raw.decode("gbk"), raw


def write_text(path, text, orig_raw):
    enc = "utf-8-sig"
    try:
        orig_raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        enc = "gbk"
    with open(path, "w", encoding=enc, newline="") as f:
        f.write(text)


def replace_once(text, old, new, tag, must=None, gone=None):
    cnt = text.count(old)
    assert cnt == 1, f"[{tag}] expected exactly 1 match, got {cnt}"
    if must:
        for m in must:
            assert m in text, f"[{tag}] precondition missing: {m}"
    if gone:
        for g in gone:
            assert g not in new, f"[{tag}] should be gone but present: {g}"
    print(f"OK [{tag}]")
    return text.replace(old, new)


cad, cad_raw = read_text(FILES["cad"])
tb, tb_raw = read_text(FILES["tb"])

# ───────────────────────── CadTextExtractor.cs ─────────────────────────

# 1) 1st overload 转发 6 参
cad = replace_once(
    cad,
    "    public static string ExtractRegionText(Transaction tr, BlockReference blockRef, BlockTableRecord owner, LocalRectangle region)\n"
    "    {\n"
    "        return ExtractRegionText(tr, blockRef, owner, region, null);\n"
    "    }",
    "    public static string ExtractRegionText(Transaction tr, BlockReference blockRef, BlockTableRecord owner, LocalRectangle region)\n"
    "    {\n"
    "        return ExtractRegionText(tr, blockRef, owner, region, null, null);\n"
    "    }",
    "cad-1st-overload",
    must=["return ExtractRegionText(tr, blockRef, owner, region, null);"],
)

# 2) 2nd overload 转发 7 参
cad = replace_once(
    cad,
    "    public static string ExtractRegionText(Transaction tr, BlockReference blockRef, BlockTableRecord owner, LocalRectangle region, OwnerTextCache? ownerTextCache)\n"
    "    {\n"
    "        return ExtractRegionText(tr, blockRef, owner, region, ownerTextCache, null);\n"
    "    }",
    "    public static string ExtractRegionText(Transaction tr, BlockReference blockRef, BlockTableRecord owner, LocalRectangle region, OwnerTextCache? ownerTextCache)\n"
    "    {\n"
    "        return ExtractRegionText(tr, blockRef, owner, region, ownerTextCache, null, null);\n"
    "    }",
    "cad-2nd-overload",
    must=["return ExtractRegionText(tr, blockRef, owner, region, ownerTextCache, null);"],
)

# 3) 3rd overload 增加 ownerCandidateScope 形参
cad = replace_once(
    cad,
    "    public static string ExtractRegionText(\n"
    "        Transaction tr,\n"
    "        BlockReference blockRef,\n"
    "        BlockTableRecord owner,\n"
    "        LocalRectangle region,\n"
    "        OwnerTextCache? ownerTextCache,\n"
    "        BlockReferenceTextCache? blockTextCache)\n"
    "    {",
    "    public static string ExtractRegionText(\n"
    "        Transaction tr,\n"
    "        BlockReference blockRef,\n"
    "        BlockTableRecord owner,\n"
    "        LocalRectangle region,\n"
    "        OwnerTextCache? ownerTextCache,\n"
    "        BlockReferenceTextCache? blockTextCache,\n"
    "        IReadOnlyList<TextCandidate>? ownerCandidateScope = null)\n"
    "    {",
    "cad-3rd-signature",
)

# 4) 3rd overload body: 用 ownerCandidateScope 子集
cad = replace_once(
    cad,
    "        if (ownerTextCache == null)\n"
    "        {\n"
    "            ownerTextCache = BuildOwnerTextCache(tr, owner);\n"
    "        }\n"
    "\n"
    "        foreach (var candidate in ownerTextCache.Candidates)\n"
    "        {\n"
    "            var local = candidate.Point.TransformBy(inverse);\n"
    "            if (IsCandidateInRegion(candidate, inverse, region, local))\n"
    "            {\n"
    "                values.Add(new TextCandidate(candidate.Text, local, candidate.Priority));\n"
    "            }\n"
    "        }",
    "        if (ownerTextCache == null)\n"
    "        {\n"
    "            ownerTextCache = BuildOwnerTextCache(tr, owner);\n"
    "        }\n"
    "\n"
    "        // 同一图框 7 个字段区域共用同一份布局文字缓存：若传入按图框世界包围盒预筛过的子集，\n"
    "        // 避免对每个区域都全量遍历整张图候选（候选数 M × 区域数 × 图框数 的重复扫描）。\n"
    "        var ownerCandidates = ownerCandidateScope ?? ownerTextCache.Candidates;\n"
    "        foreach (var candidate in ownerCandidates)\n"
    "        {\n"
    "            var local = candidate.Point.TransformBy(inverse);\n"
    "            if (IsCandidateInRegion(candidate, inverse, region, local))\n"
    "            {\n"
    "                values.Add(new TextCandidate(candidate.Text, local, candidate.Priority));\n"
    "            }\n"
    "        }",
    "cad-body-owner-scope",
)

# 5) 新增 ScopeOwnerCandidatesToBlock：插入到 AppendCachedCandidates 之后
cad = replace_once(
    cad,
    "        foreach (var candidate in cached)\n"
    "        {\n"
    "            if (IsCandidateInRegion(candidate, blockLocal, region, candidate.Point))\n"
    "            {\n"
    "                values.Add(new TextCandidate(candidate.Text, candidate.Point, candidate.Priority));\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "\n"
    "    private static string SelectBestRegionText(List<TextCandidate> values)",
    "        foreach (var candidate in cached)\n"
    "        {\n"
    "            if (IsCandidateInRegion(candidate, blockLocal, region, candidate.Point))\n"
    "            {\n"
    "                values.Add(new TextCandidate(candidate.Text, candidate.Point, candidate.Priority));\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "\n"
    "    /// <summary>\n"
    "    /// 按图框的世界包围盒预筛布局文字候选：仅保留世界坐标点落入该包围盒的候选。\n"
    "    /// 各字段区域都在图框内部，位于包围盒外的候选不可能命中任何区域，因此该预筛不改变识别结果，\n"
    "    /// 仅把「整张图候选 × 区域数 × 图框数」的全量扫描降为「建一次子集 + 子集内扫描」。\n"
    "    /// 候选以“文字插入点”判定，与下方区域匹配中 owner 候选仅按点判定（WorldBounds 为空）口径一致。\n"
    "    /// </summary>\n"
    "    public static IReadOnlyList<TextCandidate> ScopeOwnerCandidatesToBlock(\n"
    "        OwnerTextCache? ownerTextCache,\n"
    "        double minX,\n"
    "        double minY,\n"
    "        double maxX,\n"
    "        double maxY)\n"
    "    {\n"
    "        if (ownerTextCache == null || ownerTextCache.Candidates.Count == 0)\n"
    "        {\n"
    "            return Array.Empty<TextCandidate>();\n"
    "        }\n"
    "\n"
    "        var scoped = new List<TextCandidate>(ownerTextCache.Candidates.Count);\n"
    "        foreach (var candidate in ownerTextCache.Candidates)\n"
    "        {\n"
    "            var p = candidate.Point;\n"
    "            if (p.X >= minX && p.X <= maxX && p.Y >= minY && p.Y <= maxY)\n"
    "            {\n"
    "                scoped.Add(candidate);\n"
    "            }\n"
    "        }\n"
    "\n"
    "        return scoped;\n"
    "    }\n"
    "\n"
    "    private static string SelectBestRegionText(List<TextCandidate> values)",
    "cad-scope-helper",
)

# ───────────────────────── TitleBlockScanner.cs ─────────────────────────

# 5b) 增加 using System.Diagnostics（Stopwatch）
tb = replace_once(
    tb,
    "using System;\n"
    "using System.Collections.Generic;\n"
    "using System.IO;\n"
    "using System.Linq;",
    "using System;\n"
    "using System.Collections.Generic;\n"
    "using System.Diagnostics;\n"
    "using System.IO;\n"
    "using System.Linq;",
    "tb-using-diagnostics",
)

# 6) 类顶部增加轻量分段计时类型与开关
tb = replace_once(
    tb,
    "public static class TitleBlockScanner\n"
    "{\n",
    "public static class TitleBlockScanner\n"
    "{\n"
    "    /// <summary>扫描分阶段耗时（仅诊断用，需 EnableProfiling = true）。</summary>\n"
    "    public sealed class TitleBlockScanProfile\n"
    "    {\n"
    "        public long CollectMs { get; set; }\n"
    "        public long MatchMs { get; set; }\n"
    "        public long SortMs { get; set; }\n"
    "        public int CandidateCount { get; set; }\n"
    "        public int JobCount { get; set; }\n"
    "\n"
    "        public string FormatReport()\n"
    "        {\n"
    "            return $\"TitleBlockScan: collect={CollectMs}ms match={MatchMs}ms sort={SortMs}ms candidates={CandidateCount} jobs={JobCount}\";\n"
    "        }\n"
    "    }\n"
    "\n"
    "    /// <summary>为 true 时填充 <see cref=\"LastProfile\"/> 并在 scan_debug.log 追加一行摘要。</summary>\n"
    "    public static bool EnableProfiling { get; set; }\n"
    "\n"
    "    /// <summary>最近一次启用 Profiling 的扫描报告。</summary>\n"
    "    public static TitleBlockScanProfile? LastProfile { get; private set; }\n"
    "\n"
    "    [ThreadStatic]\n"
    "    private static TitleBlockScanProfile? _activeProfile;\n",
    "tb-profile-type",
    must=["public static class TitleBlockScanner"],
)

# 7) 公共 Scan(Database...) 入口：启用时建/收尾 profile
tb = replace_once(
    tb,
    "        TitleBlockScanCaches.Begin();\n"
    "        try\n"
    "        {\n"
    "            return ScanCore(\n"
    "                db,\n"
    "                library,\n"
    "                sourceName,\n"
    "                scanWindow,\n"
    "                scope,\n"
    "                currentSpaceName,\n"
    "                effectivePaperToleranceMm,\n"
    "                modelCoordinateContext,\n"
    "                allowedLayoutNames);\n"
    "        }\n"
    "        finally\n"
    "        {\n"
    "            TitleBlockScanCaches.End();\n"
    "        }",
    "        if (EnableProfiling)\n"
    "        {\n"
    "            _activeProfile = new TitleBlockScanProfile();\n"
    "        }\n"
    "\n"
    "        TitleBlockScanCaches.Begin();\n"
    "        try\n"
    "        {\n"
    "            return ScanCore(\n"
    "                db,\n"
    "                library,\n"
    "                sourceName,\n"
    "                scanWindow,\n"
    "                scope,\n"
    "                currentSpaceName,\n"
    "                effectivePaperToleranceMm,\n"
    "                modelCoordinateContext,\n"
    "                allowedLayoutNames);\n"
    "        }\n"
    "        finally\n"
    "        {\n"
    "            TitleBlockScanCaches.End();\n"
    "            if (_activeProfile != null)\n"
    "            {\n"
    "                LastProfile = _activeProfile;\n"
    "                try\n"
    "                {\n"
    "                    Directory.CreateDirectory(TitleBlockLibraryStore.DefaultDirectory);\n"
    "                    File.AppendAllText(\n"
    "                        Path.Combine(TitleBlockLibraryStore.DefaultDirectory, \"scan_debug.log\"),\n"
    "                        $\"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [SCAN_PROFILE] {_activeProfile.FormatReport()}\\n\");\n"
    "                }\n"
    "                catch\n"
    "                {\n"
    "                }\n"
    "\n"
    "                _activeProfile = null;\n"
    "            }\n"
    "        }",
    "tb-scan-entry-profile",
)

# 8) ScanCore 无窗口分支：给候选收集计时
tb = replace_once(
    tb,
    "        if (scanWindow == null)\n"
    "        {\n"
    "            var candidateIds = ScanCandidateFilter.CollectInLayouts(\n"
    "                db,\n"
    "                (layout, owner) => ShouldScanLayout(layout, owner, scope, currentSpaceName, allowedLayoutNames),\n"
    "                ScanCandidateFilter.IsTitleBlockCandidate);\n"
    "            var storedForSelected = AppSettingsStore.Load();",
    "        if (scanWindow == null)\n"
    "        {\n"
    "            var collectSw = _activeProfile != null ? Stopwatch.StartNew() : null;\n"
    "            var candidateIds = ScanCandidateFilter.CollectInLayouts(\n"
    "                db,\n"
    "                (layout, owner) => ShouldScanLayout(layout, owner, scope, currentSpaceName, allowedLayoutNames),\n"
    "                ScanCandidateFilter.IsTitleBlockCandidate);\n"
    "            if (collectSw != null && _activeProfile != null)\n"
    "            {\n"
    "                collectSw.Stop();\n"
    "                _activeProfile.CollectMs = collectSw.ElapsedMilliseconds;\n"
    "                _activeProfile.CandidateCount = candidateIds.Count;\n"
    "            }\n"
    "\n"
    "            var storedForSelected = AppSettingsStore.Load();",
    "tb-core-collect-profile",
)

# 9) ScanSelectedCore：给匹配循环与排序计时
tb = replace_once(
    tb,
    "        var jobs = new List<PlotJob>();\n"
    "        var warnings = new List<string>();\n"
    "        var libraryIndex = new TitleBlockLibraryIndex(library);\n"
    "        var groups = new Dictionary<ObjectId, List<BlockReference>>();",
    "        var jobs = new List<PlotJob>();\n"
    "        var warnings = new List<string>();\n"
    "        var libraryIndex = new TitleBlockLibraryIndex(library);\n"
    "        var matchSw = _activeProfile != null ? Stopwatch.StartNew() : null;\n"
    "        var groups = new Dictionary<ObjectId, List<BlockReference>>();",
    "tb-selected-match-start",
)

tb = replace_once(
    tb,
    "        var matchIndex = 0;\n"
    "        foreach (var pair in groups)\n"
    "        {\n"
    "            var (owner, layout) = owners[pair.Key];\n"
    "            var spaceName = layout.LayoutName;\n"
    "            CadTextExtractor.OwnerTextCache? ownerTextCache = null;\n"
    "            try\n"
    "            {\n"
    "                ownerTextCache = CadTextExtractor.BuildOwnerTextCache(tr, owner, libraryIndex.NameParts);\n"
    "            }\n"
    "            catch (Exception ex)\n"
    "            {\n"
    "                warnings.Add($\"布局={spaceName} 文字缓存建立失败，将继续逐个扫描图框: {ex.Message}\");\n"
    "            }\n"
    "\n"
    "            foreach (var blockRef in pair.Value)\n"
    "            {\n"
    "                var job = TryCreateJobFromBlockReference(\n"
    "                    tr,\n"
    "                    blockRef,\n"
    "                    layout,\n"
    "                    owner,\n"
    "                    libraryIndex,\n"
    "                    ownerTextCache,\n"
    "                    scanWindow: null,\n"
    "                    modelCoordinateContext,\n"
    "                    effectivePaperToleranceMm,\n"
    "                    storedSettings,\n"
    "                    sourceName,\n"
    "                    matchIndex,\n"
    "                    warnings);\n"
    "                if (job != null)\n"
    "                {\n"
    "                    jobs.Add(job);\n"
    "                    matchIndex++;\n"
    "                }\n"
    "            }\n"
    "        }\n"
    "\n"
    "        tr.Commit();\n"
    "        LogScanWarnings(sourceName, warnings);\n"
    "        return DeduplicateOverlappingJobs(jobs)\n"
    "            .OrderBy(x => x.DrawingNumber, NaturalStringComparer.Instance)\n"
    "            .ThenBy(x => Path.GetFileName(x.SourceFile), StringComparer.OrdinalIgnoreCase)\n"
    "            .ToList();",
    "        if (matchSw != null && _activeProfile != null)\n"
    "        {\n"
    "            matchSw.Stop();\n"
    "            _activeProfile.MatchMs = matchSw.ElapsedMilliseconds;\n"
    "        }\n"
    "\n"
    "        tr.Commit();\n"
    "        LogScanWarnings(sourceName, warnings);\n"
    "        var sortSw = _activeProfile != null ? Stopwatch.StartNew() : null;\n"
    "        var result = DeduplicateOverlappingJobs(jobs)\n"
    "            .OrderBy(x => x.DrawingNumber, NaturalStringComparer.Instance)\n"
    "            .ThenBy(x => Path.GetFileName(x.SourceFile), StringComparer.OrdinalIgnoreCase)\n"
    "            .ToList();\n"
    "        if (sortSw != null && _activeProfile != null)\n"
    "        {\n"
    "            sortSw.Stop();\n"
    "            _activeProfile.SortMs = sortSw.ElapsedMilliseconds;\n"
    "            _activeProfile.JobCount = result.Count;\n"
    "        }\n"
    "\n"
    "        return result;",
    "tb-selected-sort-profile",
)

# 10) TryCreateJobFromBlockReference：计算图框世界包围盒并预筛 owner 候选
tb = replace_once(
    tb,
    "        var blockTextCache = CadTextExtractor.BuildBlockReferenceTextCache(tr, blockRef);\n"
    "            title = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, titleRegion, ownerTextCache, blockTextCache);",
    "        // 预筛布局文字候选到本图框世界包围盒内：各字段区域都在图框内部，\n"
    "        // 包围盒外的候选不可能命中，故预筛不改变识别结果，仅避免 7 个区域各自全量扫描整张图。\n"
    "        var ownerScope = CadTextExtractor.ScopeOwnerCandidatesToBlock(\n"
    "            ownerTextCache,\n"
    "            Math.Min(wcsCorners[0], Math.Min(wcsCorners[2], Math.Min(wcsCorners[4], wcsCorners[6]))),\n"
    "            Math.Min(wcsCorners[1], Math.Min(wcsCorners[3], Math.Min(wcsCorners[5], wcsCorners[7]))),\n"
    "            Math.Max(wcsCorners[0], Math.Max(wcsCorners[2], Math.Max(wcsCorners[4], wcsCorners[6]))),\n"
    "            Math.Max(wcsCorners[1], Math.Max(wcsCorners[3], Math.Max(wcsCorners[5], wcsCorners[7]))));\n"
    "\n"
    "        var blockTextCache = CadTextExtractor.BuildBlockReferenceTextCache(tr, blockRef);\n"
    "            title = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, titleRegion, ownerTextCache, blockTextCache, ownerScope);",
    "tb-owner-scope-compute",
)

# 11) 其余 6 个 ExtractRegionText 调用追加 ownerScope 实参
tb = replace_once(
    tb,
    "            number = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, numberRegion, ownerTextCache, blockTextCache);\n"
    "            if (dateRegion.HasArea())\n"
    "                date = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, dateRegion, ownerTextCache, blockTextCache);\n"
    "            if (revisionRegion.HasArea())\n"
    "                revision = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, revisionRegion, ownerTextCache, blockTextCache);\n"
    "            if (phaseRegion.HasArea())\n"
    "                phase = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, phaseRegion, ownerTextCache, blockTextCache);\n"
    "            if (info1Region.HasArea())\n"
    "                info1 = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, info1Region, ownerTextCache, blockTextCache);\n"
    "            if (info2Region.HasArea())\n"
    "                info2 = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, info2Region, ownerTextCache, blockTextCache);",
    "            number = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, numberRegion, ownerTextCache, blockTextCache, ownerScope);\n"
    "            if (dateRegion.HasArea())\n"
    "                date = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, dateRegion, ownerTextCache, blockTextCache, ownerScope);\n"
    "            if (revisionRegion.HasArea())\n"
    "                revision = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, revisionRegion, ownerTextCache, blockTextCache, ownerScope);\n"
    "            if (phaseRegion.HasArea())\n"
    "                phase = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, phaseRegion, ownerTextCache, blockTextCache, ownerScope);\n"
    "            if (info1Region.HasArea())\n"
    "                info1 = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, info1Region, ownerTextCache, blockTextCache, ownerScope);\n"
    "            if (info2Region.HasArea())\n"
    "                info2 = CadTextExtractor.ExtractRegionText(tr, blockRef, owner, info2Region, ownerTextCache, blockTextCache, ownerScope);",
    "tb-owner-scope-calls",
)

write_text(FILES["cad"], cad, cad_raw)
write_text(FILES["tb"], tb, tb_raw)
print("ALL DONE")
