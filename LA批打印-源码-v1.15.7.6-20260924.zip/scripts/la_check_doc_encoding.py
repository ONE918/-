# -*- coding: utf-8 -*-
"""检查仓库内若干文本文件的编码（UTF-8 是否成立、有无 BOM）。"""
import io, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

rels = [
    r"installer\使用说明.txt",
    r"installer_acad\使用说明.txt",
    r"installer_acad2012\使用说明.txt",
    r"README.md",
    r"docs\软件说明.txt",
]

for rel in rels:
    full = os.path.join(ROOT, rel)
    if not os.path.exists(full):
        print("MISSING  %s" % rel)
        continue
    raw = open(full, "rb").read()
    bom = raw.startswith(b"\xef\xbb\xbf")
    try:
        raw.decode("utf-8-sig")
        enc = "utf-8"
    except UnicodeDecodeError:
        try:
            raw.decode("gbk")
            enc = "gbk"
        except UnicodeDecodeError:
            enc = "unknown"
    print("%-34s bom=%-5s enc=%s size=%d" % (rel, bom, enc, len(raw)))
