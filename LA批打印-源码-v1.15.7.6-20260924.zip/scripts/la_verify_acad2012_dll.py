# -*- coding: utf-8 -*-
"""校验 bin-acad2012\AcadBatchPlot2012.dll 是否符合 AutoCAD 2010-2012 构建预期。

逐条检查，全部打印 PASS/FAIL，最后汇总。
"""
import os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DLL = os.path.join(ROOT, "bin-acad2012", "AcadBatchPlot2012.dll")

data = open(DLL, "rb").read()
results = []

def check(name, ok, extra=""):
    results.append((name, ok, extra))
    print("%-4s %s%s" % ("PASS" if ok else "FAIL", name, ("  -> " + extra) if extra else ""))

def has_ascii(s):
    return s.encode("ascii") in data

def has_utf16(s):
    return s.encode("utf-16-le") in data

def has_utf8(s):
    return s.encode("utf-8") in data

# ── PE 头 ──────────────────────────────────────────────────────────────
pe_off = struct.unpack_from("<I", data, 0x3C)[0]
check("PE 签名", data[pe_off:pe_off + 4] == b"PE\0\0", repr(data[pe_off:pe_off + 4]))
machine = struct.unpack_from("<H", data, pe_off + 4)[0]
check("Machine = x64 (0x8664)", machine == 0x8664, "0x%04X" % machine)
# COFF characteristics: bit 0x2000 = IMAGE_FILE_DLL
chars = struct.unpack_from("<H", data, pe_off + 22)[0]
check("是 DLL (IMAGE_FILE_DLL)", bool(chars & 0x2000), "chars=0x%04X" % chars)
# 32BIT 标志在 CorFlags（.NET 目录），这里用 32BITREQ 的常见判断：AnyCPU 会有 0x2
# 简化：直接看 CLR header flags
opt_off = pe_off + 24
magic = struct.unpack_from("<H", data, opt_off)[0]
check("PE32+ (0x20B)", magic == 0x20B, "0x%X" % magic)

# ── 程序集引用（AssemblyRef 名在 #Strings 堆，UTF-8/ASCII）────────────
for must in ("acmgd", "acdbmgd", "PdfSharp", "ICSharpCode.SharpZipLib", "Newtonsoft.Json", "System.ValueTuple"):
    check("引用 %s" % must, has_ascii(must))

for banned in ("Docnet.Core", "AcCoreMgd", "DocnetCore", "System.Resources.Extensions"):
    check("不含 %s" % banned, not has_ascii(banned))

# ── 目标框架 ─────────────────────────────────────────────────────────
check("目标框架 .NETFramework v4.5", has_utf8(".NETFramework,Version=v4.5"))
check("未标 v4.8", not has_utf8(".NETFramework,Version=v4.8"))

# ── 版本号 ───────────────────────────────────────────────────────────
check("版本串 1.15.7.6 (UTF-16)", has_utf16("1.15.7.6"))

# ── 关键功能（中文串 UTF-16LE，按 #US 堆长度前缀可能落在奇偶偏移）────
def has_utf16_any(s):
    b = s.encode("utf-16-le")
    return b in data[0:] or b in data[1:]

for feat in ("图幅", "文件命名", "增加图幅", "通用型批量打印"):
    check("含功能串「%s」" % feat, has_utf16_any(feat))

# ── 2012 不该出现 PNG/JPG 之外的转图依赖；但 UI 里确实不再有 PNG/JPG 选项 ──
# 这两个字符串在 PdfRasterExportStub 里仍有出现（防御性），所以不做「不存在」断言。

print()
bad = [r for r in results if not r[1]]
print("共 %d 项，失败 %d 项" % (len(results), len(bad)))
for n, _, e in bad:
    print("  FAILED: %s %s" % (n, e))
print("VERIFY DONE" if not bad else "VERIFY FAILED")
sys.exit(1 if bad else 0)
