﻿<#
.SYNOPSIS
    校验 AutoCAD 2010-2012 构建产物（bin-acad2012\AcadBatchPlot2012.dll）。

.DESCRIPTION
    发布前自检，确认 2012 专用包的关键属性没有被其它平台的条件编译串味：

      1. PE 头：x64 / PE32+ / IMAGE_FILE_DLL
      2. 程序集名与版本（AcadBatchPlot2012 / 指定版本）
      3. 目标框架为 .NET Framework 4.5
      4. CAD 程序集引用恰好是 Acmgd + Acdbmgd 18.2，且不含 accoremgd / AcCoreMgd
         （acmgd/acdbmgd 的拆分从 AutoCAD 2013 才开始）
      5. 不含 Docnet.Core —— netstandard2.0，需 .NET 4.6.1+，net45 用不了
      6. 关键中文功能串存在（图幅 / 文件命名 / 增加图幅）
      7. 二进制中不含 System.Resources.Extensions（net45 没有）

    注意：PowerShell 5.1 读无 BOM 的 .ps1 会按 ANSI 解码，所以本脚本的中文串
    一律用码点构造（New-FromCodePoints），不写字面量。

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File scripts\verify-acad2012.ps1
#>
param(
    [string]$Dll,
    [string]$Version = '1.15.7.6'
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($Dll)) {
    $Dll = Join-Path $root 'bin-acad2012\AcadBatchPlot2012.dll'
}

$script:fails = 0

function Assert-True {
    param([string]$Name, [bool]$Condition, [string]$Detail = '')
    if ($Condition) {
        Write-Host ('PASS  ' + $Name + $(if ($Detail) { '  -> ' + $Detail } else { '' }))
    }
    else {
        Write-Host ('FAIL  ' + $Name + $(if ($Detail) { '  -> ' + $Detail } else { '' })) -ForegroundColor Red
        $script:fails = $script:fails + 1
    }
}

function New-FromCodePoints {
    param([int[]]$CodePoints)
    -join ($CodePoints | ForEach-Object { [char]$_ })
}

$tuFu        = New-FromCodePoints @(0x56FE, 0x5E45)                          # 图幅
$zengJiaTuFu = New-FromCodePoints @(0x589E, 0x52A0, 0x56FE, 0x5E45)          # 增加图幅
$wenJianMing = New-FromCodePoints @(0x6587, 0x4EF6, 0x547D, 0x540D)          # 文件命名

Assert-True 'DLL 存在' (Test-Path -LiteralPath $Dll) $Dll
if (-not (Test-Path -LiteralPath $Dll)) { exit 1 }

$bytes = [IO.File]::ReadAllBytes($Dll)
# Latin1 = 字节到字符 1:1 映射，可安全用于 ASCII / UTF-8 序列检索。
$latin = [Text.Encoding]::GetEncoding(28591).GetString($bytes)
# #US 堆里的托管字符串是 UTF-16LE；长度前缀会让部分字符串落在奇数偏移，两端都要扫。
$utf16Even = [Text.Encoding]::Unicode.GetString($bytes)
$utf16Odd = [Text.Encoding]::Unicode.GetString($bytes, 1, $bytes.Length - 1)

Write-Host ''
Write-Host '--- PE 头 ---'
Assert-True 'PE 签名' ([BitConverter]::ToUInt16($bytes, [BitConverter]::ToInt32($bytes, 0x3C)) -eq 0x4550)
$peOffset = [BitConverter]::ToInt32($bytes, 0x3C)
$machine = [BitConverter]::ToUInt16($bytes, $peOffset + 4)
Assert-True 'Machine = x64 (0x8664)' ($machine -eq 0x8664) ('0x{0:X4}' -f $machine)
$chars = [BitConverter]::ToUInt16($bytes, $peOffset + 22)
Assert-True 'IMAGE_FILE_DLL' (($chars -band 0x2000) -ne 0) ('chars=0x{0:X4}' -f $chars)
$magic = [BitConverter]::ToUInt16($bytes, $peOffset + 24)
Assert-True 'PE32+ (0x20B)' ($magic -eq 0x20B) ('0x{0:X}' -f $magic)

Write-Host ''
Write-Host '--- 程序集身份 ---'
$an = [Reflection.AssemblyName]::GetAssemblyName($Dll)
Assert-True '程序集名 = AcadBatchPlot2012' ($an.Name -eq 'AcadBatchPlot2012') $an.Name
Assert-True ('版本 = ' + $Version) ($an.Version.ToString() -eq $Version) $an.Version.ToString()

$asm = [Reflection.Assembly]::ReflectionOnlyLoadFrom($Dll)
$refs = @($asm.GetReferencedAssemblies() | ForEach-Object { $_.Name })
$tfm = $asm.GetCustomAttributesData() |
    Where-Object { $_.AttributeType.Name -eq 'TargetFrameworkAttribute' } |
    Select-Object -First 1
$tfmValue = if ($tfm) { $tfm.ConstructorArguments[0].Value } else { '<none>' }
Assert-True '目标框架 = .NETFramework,Version=v4.5' ($tfmValue -eq '.NETFramework,Version=v4.5') $tfmValue
# 交叉验证：反射只读模式对某些程序集读不到 TargetFrameworkAttribute（net8 实测返回空），
# 所以再用字节级判定兜底 —— 元数据里必须出现该 TFM 串，且不得出现 net8 的 TFM 串。
Assert-True '字节级：含 .NETFramework,Version=v4.5' $latin.Contains('.NETFramework,Version=v4.5')
Assert-True '字节级：不含 .NETCoreApp' (-not $latin.Contains('.NETCoreApp,Version='))

Write-Host ''
Write-Host '--- CAD 程序集引用 ---'
Assert-True '引用 Acmgd'                ($refs -contains 'Acmgd')
Assert-True '引用 Acdbmgd'              ($refs -contains 'Acdbmgd')
Assert-True '不含 accoremgd'            (-not ($refs -contains 'accoremgd'))
Assert-True '不含 AcCoreMgd'            (-not ($refs -contains 'AcCoreMgd'))
Assert-True '引用 System.ValueTuple'    ($refs -contains 'System.ValueTuple')
Assert-True '引用 PianNoCN'             ($refs -contains 'PianNoCN')
Assert-True '引用 Newtonsoft.Json'      ($refs -contains 'Newtonsoft.Json')
Assert-True '引用 PdfSharp'             ($refs -contains 'PdfSharp')

Write-Host ''
Write-Host '--- 二进制禁用项 ---'
foreach ($banned in @('Docnet.Core', 'DocnetCore', 'System.Resources.Extensions')) {
    Assert-True ('不含 ' + $banned) (-not $latin.Contains($banned))
}

Write-Host ''
Write-Host '--- 关键功能串（UTF-16LE 托管串 / UTF-8 的 BAML）---'
foreach ($s in @($tuFu, $zengJiaTuFu, $wenJianMing)) {
    $hit16 = $utf16Even.Contains($s) -or $utf16Odd.Contains($s)
    # 把目标串的 UTF-8 字节按 Latin1 逐字节映射成字符，才能和 $latin 逐字节比较。
    $utf8BytesAsChars = [Text.Encoding]::GetEncoding(28591).GetString([Text.Encoding]::UTF8.GetBytes($s))
    $hit8 = $latin.Contains($utf8BytesAsChars)
    Assert-True ('含 ' + $s) ($hit16 -or $hit8) ('utf16=' + $hit16 + ' utf8=' + $hit8)
}

Write-Host ''
if ($script:fails -eq 0) {
    Write-Host 'ACAD2012 VERIFY OK' -ForegroundColor Green
    exit 0
}

Write-Host ('ACAD2012 VERIFY FAILED: ' + $script:fails + ' item(s)') -ForegroundColor Red
exit 1
