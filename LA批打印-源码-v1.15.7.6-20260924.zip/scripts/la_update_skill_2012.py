# -*- coding: utf-8 -*-
"""把 AutoCAD 2010-2012（net45）构建的知识补进 la-batchplot-plugin-dev 技能。"""
import io, os, sys

FULL = r"C:\Users\T490\.workbuddy\skills\la-batchplot-plugin-dev\SKILL.md"

raw = open(FULL, "rb").read()
if raw.startswith(b"\xef\xbb\xbf"):
    s, enc = raw.decode("utf-8-sig"), "utf-8-sig"
else:
    s, enc = raw.decode("utf-8"), "utf-8"

def sub(old, new, tag, must=None, gone=None):
    global s
    n = s.count(old)
    if n != 1:
        print("FAIL [%s] 期望命中 1 次，实际 %d 次：\n%s" % (tag, n, old[:300]))
        sys.exit(1)
    s = s.replace(old, new, 1)
    for m in (must or []):
        if m not in s:
            print("FAIL [%s] 缺少: %s" % (tag, m)); sys.exit(1)
    for g in (gone or []):
        if g in s:
            print("FAIL [%s] 仍存在: %s" % (tag, g)); sys.exit(1)
    print("OK   [%s]" % tag)


# ── 1. frontmatter description ──
sub(
    'description: 修改、编译、校验并打包 LA批量打印（LA.BatchPlot，ZWCAD + AutoCAD 双平台）插件的标准工作流。',
    'description: 修改、编译、校验并打包 LA批量打印（LA.BatchPlot，ZWCAD + AutoCAD 2010-2027 全平台）插件的标准工作流。',
    "1 description 平台范围",
    must=["AutoCAD 2010-2027 全平台"],
)

# ── 2. 项目表 ──
sub(
    """| `src/AcadBatchPlot.Core` | net8.0-windows + `ACAD_CORE` | `bin-acad2025-2027\\AcadBatchPlot.Core.dll`（AutoCAD 2025-2027） |
| `src/PianNoCN` | net45 + netstandard2.0 | 绘图仪配置解析 |""",
    """| `src/AcadBatchPlot.Core` | net8.0-windows + `ACAD_CORE` | `bin-acad2025-2027\\AcadBatchPlot.Core.dll`（AutoCAD 2025-2027） |
| `src/AcadBatchPlot2012` | net45 + `AUTOCAD;ACAD2012` | `bin-acad2012\\AcadBatchPlot2012.dll`（AutoCAD 2010-2012） |
| `src/PianNoCN` | net45 + netstandard2.0 | 绘图仪配置解析 |

**AutoCAD 版本 → 目标框架 / ObjectARX 对照**（改版本支持时先看这张表）：

| AutoCAD | ObjectARX | CLR / TFM | 关键差别 |
|---|---|---|---|
| 2010 / 2011 / 2012 | R18.x（2012 = 18.2） | CLR 4.0 → **net45** | 只有 `acmgd` + `acdbmgd`，**没有 `AcCoreMgd`**；`Application` 在 `acmgd` 里 |
| 2015 ~ 2024 | 20.0+ | net48 | `accoremgd` 拆分出来了（`ACAD_CORE` 走 `ApplicationServices.Core.Application`） |
| 2025 ~ 2027 | 25.0 | net8.0-windows | 纯 Core |""",
    "2 项目表 + 版本对照",
    must=["src/AcadBatchPlot2012", "R18.x（2012 = 18.2）"],
)

# ── 3. 共享源码条件编译说明 ──
sub(
    "- `src/Common/**` 是共享源码，按 `#if ZWCAD / AUTOCAD / ACAD_CORE` 条件编译分别内联进三个 DLL。**csproj 是通配包含，新增 .cs/.xaml 不用改工程文件。**",
    "- `src/Common/**` 是共享源码，按 `#if ZWCAD / AUTOCAD / ACAD_CORE / ACAD2012` 条件编译分别内联进四个 DLL。**csproj 是通配包含，新增 .cs/.xaml 不用改工程文件。**",
    "3 条件编译常量",
    must=["ACAD_CORE / ACAD2012"],
)

# ── 4. 编译章节：补 net45 子集 ──
sub(
    """- 目标：**0 错误 0 警告**。

## 2. 改完先自查（重要）""",
    """- 目标：**0 错误 0 警告**。

### 1.1 AutoCAD 2010-2012（net45）构建的额外约束

`AcadBatchPlot2012.csproj` 是**独立项目**（不是另一个 TFM），输出到 `bin-acad2012\\`：

```powershell
$dotnet build "src\\AcadBatchPlot2012\\AcadBatchPlot2012.csproj" -t:Rebuild --nologo
```

net45 是这次适配的成本集中点，**下面这些 API 在 net45 里不存在**，源码里都靠 `#if ACAD2012` 分流：

| 缺失的 API | 出现位置 | 处理 |
|---|---|---|
| `System.ValueTuple` | 源码大量元组 | csproj 加 `PackageReference System.ValueTuple 4.5.0`（**加了就完事，不用改源码**） |
| `Array.Empty<T>()`（4.6+） | 8 个文件 13 处 | 统一改成 `new T[0]`（**对 net48/net8 也无害**，只是少了个缓存单例） |
| `HostApplicationServices.UserRegistryProductRootKey` | `src/AutoCAD/AutoloadManager.cs` | 2012 只有 `RegistryProductRootKey` → `#if ACAD2012` 分流 |
| `VisualTreeHelper.GetDpi`（4.6.2+） | `src/Common/Views/`（可用性换算） | 用 `PresentationSource.FromVisual(this)?.CompositionTarget.TransformToDevice.M11` |
| `FormattedText(..., double pixelsPerDip)` 重载（4.6.2+） | `SettingsForm.xaml.cs` 目录预览 | net45 该位置是 `NumberSubstitution` → 收敛成 `CreatePreviewText(...)` 辅助方法，内部 `#if` 决定用哪个重载。**报错形态是 `CS1503 参数 7: 无法从"double"转换为"System.Windows.Media.NumberSubstitution"`** |
| `Docnet.Core`（netstandard2.0，需 4.6.1+） | PDF→PNG/JPG 转图 | 2012 项目 `Compile Remove` 掉 `PdfRasterExport.cs`，改用项目内 `PdfRasterExportStub.cs`（保留 `RasterExportSettings` 常量/`Normalize` 供 `AppSettings`/设置窗编译通过），两个面板的输出格式下拉里 `PNG`/`JPG` 用 `#if !ACAD2012` 摘掉 |

- **CAD 引用来自 NuGet 包 `YB.Objectarx.net` 1.0.2**（内含 ObjectARX 2012 的 `lib\\acmgd.dll` / `lib\\acdbmgd.dll`，程序集名是 **`Acmgd` / `Acdbmgd`（首字母大写）**、版本 18.2.0.0、**无公钥令牌（非强命名）**）。用 `<Reference>` + `$(PkgYB_Objectarx_net)\\lib\\...` 引用，`<Private>false</Private>`：**绝不能让这两个 DLL 拷进发布包**（拷错会让 CAD 加载到错的 acmgd 而崩溃）。包本身 `ExcludeAssets="all"`，只借文件。
- **net45 没有 `System.Resources.Extensions`** → 2012 csproj 必须写 `GenerateResourceUsePreserializedResources=false`，否则 resx 编译失败。

## 2. 改完先自查（重要）""",
    "4 net45 约束表",
    must=["1.1 AutoCAD 2010-2012（net45）构建的额外约束", "YB.Objectarx.net"],
)

# ── 5. 自查章节：补 GBK 源文件坑 ──
sub(
    """9. **显示口径有歧义先问，别猜**。""",
    """9. **仓库里有 3 个 GBK 编码无 BOM 的 .cs 文件**：`src\\Common\\Infrastructure\\BatchPlotHostProgress.cs`、`src\\Common\\Services\\Scanning\\CadEntGet.cs`、`src\\Common\\Services\\Scanning\\TianzhengTextReader.cs`（中文 locale 下 csc 按系统默认代码页读，所以一直能编过）。**用 Python 批量改源码时一律 `raw.decode('utf-8')` 失败后回退 `gbk`，并原样写回原编码**，否则 `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xc5` 或把中文写成乱码。批量改源码的脚本模板见 `scripts\\la_fix_array_empty.py`（含 must/gone 断言）。
10. **PowerShell 脚本（.ps1）里的中文必须配 UTF-8 BOM**，否则 PowerShell 5.1 按 ANSI 解码 → 注释乱码。若不方便写 BOM，就在脚本里用码点构造中文串（见 `scripts\\verify-acad2012.ps1` 的 `New-FromCodePoints`）。
11. **显示口径有歧义先问，别猜**。""",
    "5 GBK/BOM 坑",
    must=["New-FromCodePoints", "la_fix_array_empty.py"],
)

# ── 6. 校验章节：ReflectionOnlyLoadFrom 可用的重大更正 ──
sub(
    "- 沙箱会拦截 `Add-Type`、`[Reflection.Assembly]::LoadFile`（\"Assembly load APIs execute arbitrary C# code\"），所以**不要尝试反射枚举类型**。",
    """- 沙箱会拦截 `Add-Type`、`[Reflection.Assembly]::LoadFile`（"Assembly load APIs execute arbitrary C# code"），所以**不要尝试反射枚举类型**。
- **但 `[System.Reflection.Assembly]::ReflectionOnlyLoadFrom()` 和 `[System.Reflection.AssemblyName]::GetAssemblyName()` 是可用的**（2026-09-22 实测，前者只读元数据不执行代码）。这是拿到**准确程序集引用清单 + 目标框架**的最省事办法，比裸字节猜靠谱：
  ```powershell
  $an  = [System.Reflection.AssemblyName]::GetAssemblyName($dll)          # 名/版本/公钥令牌，不需要完整路径解析
  $asm = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom($dll)
  $asm.GetReferencedAssemblies() | ForEach-Object { $_.Name }             # 准确的 AssemblyRef
  $asm.GetCustomAttributesData() | Where-Object { $_.AttributeType.Name -eq 'TargetFrameworkAttribute' }
  ```
- **现成脚本：`scripts\\verify-acad2012.ps1`**（`-Dll` 可换路径）。一次跑完：PE 头 x64/PE32+/DLL → 程序集名与版本 → TFM = v4.5 → 引用 `Acmgd`+`Acdbmgd` 且**不含** `accoremgd`/`AcCoreMgd`/`Docnet.Core` → 含「图幅」「文件命名」「增加图幅」。2026-09-22 全 PASS。改动 2012 构建后务必重跑。
- **在 PowerShell 里做字节检索**：`$latin = [Text.Encoding]::GetEncoding(28591).GetString($bytes)` 得到**字节到字符 1:1 映射**的串，可以 `.Contains()` ASCII 与 **UTF-8 字节序列**。⚠️ 常见错误：用 `[Text.Encoding]::UTF8.GetString([Text.Encoding]::UTF8.GetBytes($s))` 得到的是**码点**不是字节，永远匹配不上（本次踩到）；查 BAML 里的中文（XAML 字面量是 UTF-8）必须走 Latin1 这条路，查 C# 中文字面量（`#US` 堆是 UTF-16LE）走 `[Text.Encoding]::Unicode.GetString($bytes)` 并同时试 offset 0 与 1。""",
    "6 ReflectionOnlyLoadFrom / 校验脚本",
    must=["verify-acad2012.ps1", "GetEncoding(28591)"],
)

# ── 7. 打包章节：4 个包 ──
sub(
    "- 产出 `release\\v<版本>\\`：ZWCAD / AutoCAD2015-2024 / AutoCAD2025-2027 三个 zip + `docs` + `release-manifest.txt`（SHA256）。\n- 打包内容取自 `bin\\`、`bin-acad\\`、`bin-acad2025-2027\\`、`installer\\使用说明.txt`、`docs\\LA批量打印 使用方法【使用必读】*.docx`。",
    """- 产出 `release\\v<版本>\\`：**ZWCAD / AutoCAD2010-2012 / AutoCAD2015-2024 / AutoCAD2025-2027 四个 zip** + `docs` + `release-manifest.txt`（SHA256）。
- 打包内容取自 `bin\\`、`bin-acad\\`、`bin-acad2012\\`、`bin-acad2025-2027\\`、`installer\\使用说明.txt`（+ `installer_acad\\` / `installer_acad2012\\`）、`docs\\LA批量打印 使用方法【使用必读】*.docx`。
- 脚本参数：`-ZwcadOutput` / `-LegacyAcadOutput` / `-Legacy2012AcadOutput` / `-CoreAcadOutput`，默认 `bin` / `bin-acad` / `bin-acad2012` / `bin-acad2025-2027`。
- 2012 包的主 DLL 是 **`AcadBatchPlot2012.dll`**，说明文件用 `installer_acad2012\\使用说明.txt`（已写明：x64、不提供 PNG/JPG）。""",
    "7 四个发布包",
    must=["AutoCAD2010-2012", "installer_acad2012"],
)

with io.open(FULL, "w", encoding=enc, newline="") as f:
    f.write(s)
print("\n已写回 %s (enc=%s)" % (FULL, enc))
print("ALL DONE")
