# -*- coding: utf-8 -*-
"""找出 src 下所有无法用 utf-8-sig 解码的 .cs 文件（跳过 obj/bin）。"""
import io, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

bad = []
ok = 0
for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, "src")):
    dirnames[:] = [d for d in dirnames if d.lower() not in ("obj", "bin")]
    for name in filenames:
        if not name.endswith(".cs"):
            continue
        full = os.path.join(dirpath, name)
        rel = os.path.relpath(full, ROOT)
        data = open(full, "rb").read()
        try:
            data.decode("utf-8-sig")
            ok += 1
        except UnicodeDecodeError as e:
            bad.append((rel, len(data), str(e)))
            print("BAD  [%s] %s" % (rel, e))

print("\n可解码 %d 个，失败 %d 个" % (ok, len(bad)))
for rel, sz, err in bad:
    print("  -> %s" % rel)
