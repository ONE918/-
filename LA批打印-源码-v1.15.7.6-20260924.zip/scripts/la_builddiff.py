# -*- coding: utf-8 -*-
"""把 dotnet build 输出里的错误/警告行提取出来（去掉中文路径前缀）。"""
import io, os, re, sys

src = sys.argv[1] if len(sys.argv) > 1 else os.path.expandvars(r"%TEMP%\la_b2012_2.txt")
d = io.open(src, encoding="utf-8-sig", errors="ignore").read()
lines = d.splitlines()
print("TOTAL LINES", len(lines))

KEY = re.compile(r"error [A-Z]{2,5}\d+|warning [A-Z]{2,5}\d+|Error\(s\)|Warning\(s\)|Build succeeded|Build FAILED")
PREFIX = re.compile(r"^.*?(?=src\\|LA\.BatchPlot\.sln)")

seen = set()
count = 0
for line in lines:
    if not KEY.search(line):
        continue
    k = PREFIX.sub("", line.strip())
    if k in seen:
        continue
    seen.add(k)
    count += 1
    print(k[:250])
print("\nUNIQUE MATCHED:", count)
