# -*- coding: utf-8 -*-
"""在 ObjectARX 2012 (18.2) 里找与注册表产品根路径相关的替代 API。"""
import os

tmp = os.path.expandvars(r"%TEMP%\la_acad2012")
files = [os.path.join(tmp, "lib", n) for n in ("acmgd.dll", "acdbmgd.dll")]

NEED = [
    "UserRegistryProductRootKey",
    "RegistryProductRootKey",
    "ProductRootKey",
    "HostApplicationServices",
    "AcadRegistryKey",
    "CurVer",
    "Applications",
    "GetAcAppKey",
    "CurrentProfileName",
    "Registry",
]

for p in files:
    d = open(p, "rb").read()
    print("--- %s ---" % os.path.basename(p))
    for n in NEED:
        print("   %-32s %s" % (n, "YES" if n.encode("ascii") in d else "-- no"))
