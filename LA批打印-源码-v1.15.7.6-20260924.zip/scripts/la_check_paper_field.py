# -*- coding: utf-8 -*-
"""校验「图幅」保留字段是否进了三套产物（C# 方法名走 ASCII 元数据，中文串走 UTF-16，XAML 走 UTF-8）。"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TARGETS = [
    ("ZWCAD", r"bin\BatchPlotter.dll"),
    ("ACAD2015-2024", r"bin-acad\AcadBatchPlot.dll"),
    ("ACAD2025-2027", r"bin-acad2025-2027\AcadBatchPlot.Core.dll"),
]

ASCII_MUST = [
    "IsPaperField",
    "PaperFieldName",
    "AddNameFieldPaper_Click",
    "InsertNameFieldPaper",
    "OutputPaperNameResolver",
    "NormalizeLongPaperFraction",
]
ASCII_GONE = []

UTF16_MUST = [
    "\u56fe\u5e45",                    # 图幅
    "\u5df2\u5728\u5217\u8868\u4e2d",  # 已在列表中
    "\u4fdd\u7559\u540d",              # 保留名（NameFieldEntry.Hint）
    "\u540c\u53e3\u5f84",              # 同口径（NameFieldEntry.Hint / 状态栏）
]
UTF8_MUST = [
    "\u589e\u52a0\u56fe\u5e45".encode("utf-8"),   # 增加图幅（XAML 菜单项）
    "AddNameFieldPaper_Click".encode("ascii"),
]

for label, rel in TARGETS:
    path = os.path.join(ROOT, rel)
    data = open(path, "rb").read()

    def has_ascii(s):
        return s.encode("ascii") in data

    def has_u16(s):
        blob = s.encode("utf-16-le")
        return blob in data or blob in data[1:]

    def has_u8(b):
        return b in data

    miss_a = [s for s in ASCII_MUST if not has_ascii(s)]
    gone_a = [s for s in ASCII_GONE if has_ascii(s)]
    miss_u = [s for s in UTF16_MUST if not has_u16(s)]
    miss_x = [s for s in UTF8_MUST if not has_u8(s)]

    ok = not (miss_a or gone_a or miss_u or miss_x)
    print("%-15s size=%7d  %s" % (label, len(data), "PASS" if ok else "FAIL"))
    if miss_a:
        print("   missing-ascii : %s" % miss_a)
    if gone_a:
        print("   should-be-gone: %s" % gone_a)
    if miss_u:
        print("   missing-cn    : %s" % [repr(s) for s in miss_u])
    if miss_x:
        print("   missing-xaml  : %s" % miss_x)
