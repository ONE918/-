# -*- coding: utf-8 -*-
"""把 AutoCAD 2010-2012（net45）构建的知识写进项目记忆。"""
import io, os, sys

ROOT = r"D:\00YPL内部环境V1.0\03-插件合集\LA打印\batchPrintZWCAD-1.15.7.6"
MEM = os.path.join(ROOT, r".workbuddy\memory\MEMORY.md")
DAILY = os.path.join(ROOT, r".workbuddy\memory\2026-09-22.md")

def load(p):
    raw = open(p, "rb").read()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig"), "utf-8-sig"
    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return raw.decode("gbk"), "gbk"

def save(p, s, enc):
    with io.open(p, "w", encoding=enc, newline="") as f:
        f.write(s)

def sub(s, old, new, tag, must=None, gone=None):
    if s.count(old) != 1:
        print("FAIL [%s] 期望命中 1 次，实际 %d 次：\n%s" % (tag, s.count(old), old[:300]))
        sys.exit(1)
    s = s.replace(old, new, 1)
    for m in (must or []):
        if m not in s:
            print("FAIL [%s] 缺少: %s" % (tag, m)); sys.exit(1)
    for g in (gone or []):
        if g in s:
            print("FAIL [%s] 仍存在: %s" % (tag, g)); sys.exit(1)
    print("OK   [%s]" % tag)
    return s


# ══════════════ MEMORY.md ══════════════
s, enc = load(MEM)

s = sub(
    s,
    "- `LA.BatchPlot.sln` 4 项目：`BatchPlotter`(net48,ZWCAD)→`bin\\`；`AcadBatchPlot`(net48)→`bin-acad\\`；`AcadBatchPlot.Core`(net8)→`bin-acad2025-2027\\`；`PianNoCN`(net45+netstandard2.0)。\n- `src/Common/**` 共享源码，靠 `#if ZWCAD/AUTOCAD/ACAD_CORE` 内联进各平台 DLL。",
    "- `LA.BatchPlot.sln` **5 项目**：`BatchPlotter`(net48,ZWCAD)→`bin\\`；`AcadBatchPlot`(net48,AUTOCAD)→`bin-acad\\`（AutoCAD 2015-2024）；`AcadBatchPlot.Core`(net8,ACAD_CORE)→`bin-acad2025-2027\\`；**`AcadBatchPlot2012`(net45,AUTOCAD+ACAD2012)→`bin-acad2012\\`（AutoCAD 2010-2012）**；`PianNoCN`(net45+netstandard2.0)。\n- `src/Common/**` 共享源码，靠 `#if ZWCAD / AUTOCAD / ACAD_CORE / ACAD2012` 内联进各平台 DLL。\n- **AutoCAD→TFM 对照**：2010-2012 = R18.x / CLR4.0 → net45（只有 `acmgd`+`acdbmgd`，**无 `AcCoreMgd`**）；2015-2024 = net48；2025-2027 = net8。",
    "MEM 结构",
    must=["AcadBatchPlot2012", "AcadBatchPlot2012`(net45"],
)

s = sub(
    s,
    "→ `release\\v1.15.7.6\\`（三 zip + docs + manifest）。",
    "→ `release\\v1.15.7.6\\`（**四 zip**：ZWCAD / AutoCAD2010-2012 / AutoCAD2015-2024 / AutoCAD2025-2027 + docs + manifest）。",
    "MEM 打包",
    must=["AutoCAD2010-2012"],
)

s = sub(
    s,
    "- **DLL 校验靠裸字节**：方法名 ASCII 命中；",
    """- **`[Reflection.AssemblyName]::GetAssemblyName()` 与 `[Reflection.Assembly]::ReflectionOnlyLoadFrom()` 可用**（只 `LoadFile` 被拦），能直接拿到准确的 AssemblyRef 清单 + `TargetFrameworkAttribute` —— 校验程序集引用的首选手段。
- **仓库有 3 个 GBK 无 BOM 的 .cs**：`BatchPlotHostProgress.cs`、`Services\\Scanning\\CadEntGet.cs`、`Services\\Scanning\\TianzhengTextReader.cs`。Python 批量改源码必须 utf-8 失败回退 gbk 并原样写回，否则 `UnicodeDecodeError` 或写乱码。
- `.ps1` 里写中文必须带 UTF-8 BOM（PS5.1 否则按 ANSI 解码）；日志/记忆等 .md 不要求。
- **DLL 校验靠裸字节**：方法名 ASCII 命中；""",
    "MEM 校验手段",
    must=["ReflectionOnlyLoadFrom", "GBK 无 BOM"],
)

s += """
## AutoCAD 2010-2012（net45）构建（2026-09-22 新增）
- 项目 `src/AcadBatchPlot2012`（net45 / x64 / `AUTOCAD;ACAD2012`）→ `bin-acad2012\\AcadBatchPlot2012.dll`，已加入 sln。CAD 引用来自 NuGet `YB.Objectarx.net` 1.0.2 的 `lib\\acmgd.dll` / `acdbmgd.dll`（程序集名 **`Acmgd`/`Acdbmgd`**、18.2.0.0、**无公钥令牌**）→ 用 `<Reference>` + `<Private>false</Private>`，**绝不能拷进发布包**。
- net45 缺 API 与对策：`System.ValueTuple`→加 `PackageReference 4.5.0`；`Array.Empty<T>()`→统一 `new T[0]`（8 文件 13 处，对 net48/net8 只是少个缓存单例）；`UserRegistryProductRootKey`→`#if ACAD2012` 用 `RegistryProductRootKey`；`VisualTreeHelper.GetDpi`→`PresentationSource.FromVisual(this)?.CompositionTarget.TransformToDevice.M11`；`FormattedText(...,pixelsPerDip)` 重载（4.6.2+）→ `SettingsForm` 收敛为 `CreatePreviewText(...)` 辅助方法内 `#if`；`Docnet.Core` 需 4.6.1+ → 2012 项目 `Compile Remove` 掉 `PdfRasterExport.cs` 改用项目内 `PdfRasterExportStub.cs`，两个面板输出格式下拉用 `#if !ACAD2012` 摘掉 PNG/JPG。
- 2012 csproj 必须 `GenerateResourceUsePreserializedResources=false`（net45 无 `System.Resources.Extensions`）。
- `NormalizeHkcuRelativePath` 已泛化为剥掉任意 `HKEY_*\\` 前缀（2012 的 `RegistryProductRootKey` 可能带 hive 前缀）；AutoCAD 查 DemandLoad 项**先 HKCU 再 HKLM**，写 HKCU 对 2010-2012 有效。
- 产物校验脚本：`scripts\\verify-acad2012.ps1`（PE x64 / TFM v4.5 / 引用 Acmgd+Acdbmgd 且无 accoremgd、Docnet / 含图幅等中文串），改 2012 构建后必跑。
- 2012 专用说明文件 `installer_acad2012\\使用说明.txt`；打包脚本新增 `-Legacy2012AcadOutput`（默认 `bin-acad2012`）。
- 无 CAD 运行时可跨平台验证：`dotnet build <csproj> -t:Rebuild -o %TEMP%\\xxx`（重定向输出，绕开被 CAD 锁住的 `bin-acad\\`）。
"""

save(MEM, s, enc)
print("已写回 MEMORY.md (%d bytes, enc=%s)" % (len(s.encode("utf-8")), enc))


# ══════════════ 当天日志（append-only）══════════════
d, denc = load(DAILY)
anchor = "- `git --version` = 2.55.0.windows.5；全局身份已配好（ONE / chenjiankai520@163.com）。"
if anchor not in d:
    print("FAIL 日志锚点未找到")
    sys.exit(1)

d = d.replace(anchor, anchor + """

---

## 编译适配 AutoCAD 2012（用户："编译适配autocad2012"）

**口径确认（AskUserQuestion）**：目标 = AutoCAD 2010-2012，选 **net45 + x64** 方案（另一条 net40 路线要改 148 处 `IReadOnlyList/Dictionary`→`IList/IDictionary`，成本过高，已排除）。

**新增项目** `src/AcadBatchPlot2012/AcadBatchPlot2012.csproj`：net45 / x64 / `AUTOCAD;ACAD2012` / 程序集 `AcadBatchPlot2012` → `bin-acad2012\\`，已加入 `LA.BatchPlot.sln`（`{B76C1DF8-...}`）。CAD 引用走 NuGet **`YB.Objectarx.net` 1.0.2**（内含 ObjectARX 2012 的 `lib\\acmgd.dll`/`lib\\acdbmgd.dll`；实测程序集名是 **`Acmgd`/`Acdbmgd`**（首字母大写）、18.2.0.0、**无公钥令牌**，非强命名 → 运行时按简单名大小写无关绑定，安全），用 `<Reference>` + `<Private>false</Private>` 引用，包本身 `ExcludeAssets="all"`。

**net45 缺失 API 与对策**（全部靠 `#if ACAD2012` 或项目内替换文件）：
- `System.ValueTuple` 不存在 → csproj 加 `PackageReference System.ValueTuple 4.5.0`（曾一次报 70 个 `CS8137/CS8179`）。
- `Array.Empty<T>()`（4.6+）→ 8 文件 13 处统一改 `new T[0]`（脚本 `scripts\\la_fix_array_empty.py`）。对 net48/net8 也无害。
- `HostApplicationServices.UserRegistryProductRootKey`（2013+）→ 2012 只有 `RegistryProductRootKey`（`AutoloadManager.cs` 内 `#if ACAD2012` 分流）。
- `VisualTreeHelper.GetDpi`（4.6.2+）→ `PresentationSource.FromVisual(this)?.CompositionTarget.TransformToDevice.M11`。
- `FormattedText(..., double pixelsPerDip)`（4.6.2+）→ net45 该位置是 `NumberSubstitution`（报 `CS1503 参数 7`）；把 `SettingsForm.xaml.cs` 两处构造收敛成 `CreatePreviewText(...)` 辅助方法，内部 `#if` 决定重载（脚本 `scripts\\la_fix_formattedtext.py`）。
- `Docnet.Core`（netstandard2.0，需 4.6.1+）→ 2012 项目 `Compile Remove` 掉 `PdfRasterExport.cs`，改用项目内 `PdfRasterExportStub.cs`；两个面板的输出格式下拉用 `#if !ACAD2012` 摘掉 PNG/JPG（2012 只剩 PDF/DWF/DWG）。
- `GenerateResourceUsePreserializedResources=false`（net45 无 `System.Resources.Extensions`）。

**顺手加固**：`AutoloadManager.NormalizeHkcuRelativePath` 由"只剥 `HKEY_CURRENT_USER\\`"改为"剥任意 `HKEY_*\\` 前缀"（2012 的 `RegistryProductRootKey` 可能带 hive 前缀）。已核实 AutoCAD 查找 DemandLoad 项**先 HKCU 再 HKLM**，写 HKCU 对 2010-2012 同样有效。

**编译与校验**：
- `dotnet build src\\AcadBatchPlot2012\\AcadBatchPlot2012.csproj -t:Rebuild` → **0 错误 0 警告**；`bin-acad2012\\` 内只有 `AcadBatchPlot2012.dll`(804352B) + PianNoCN/PdfSharp/Newtonsoft/ValueTuple/SharpZipLib，**没有 acmgd/acdbmgd/Docnet**（Private=false 生效）。
- 新增可复用校验脚本 **`scripts\\verify-acad2012.ps1`**（`-Dll` 可换路径）：PE x64/PE32+/DLL、程序集名与版本、TFM=v4.5、引用 `Acmgd`+`Acdbmgd` 且不含 `accoremgd`/`AcCoreMgd`/`Docnet.Core`/`System.Resources.Extensions`、含中文「图幅/文件命名/增加图幅」→ **全 PASS**。
- **回归**：`AcadBatchPlot`(net48) 与 `AcadBatchPlot.Core`(net8) 用 `-o %TEMP%\\la_verify_out\\...` 重定向输出重编 → 仍 0 错误 0 警告（绕开被 AutoCAD 2020 锁住的 `bin-acad\\`）。
- 引用清单对照（反射 `ReflectionOnlyLoadFrom`）：2012 = `Acmgd 18.2 + Acdbmgd 18.2 + System.ValueTuple`，无 `accoremgd`；net48 = `acmgd/acdbmgd/accoremgd 20.0 + Docnet.Core`。

**打包**：`scripts\\package-release.ps1` 新增 `-Legacy2012AcadOutput`（默认 `bin-acad2012`）与第 4 个包 **`AutoCAD2010-2012`**（`LA批打印-AutoCAD2010-2012-v$Version.zip`，主 DLL `AcadBatchPlot2012.dll`，说明用新增的 `installer_acad2012\\使用说明.txt`，已写明 x64 与不支持 PNG/JPG）。

**坑（新）**：
- **仓库里有 3 个 GBK 无 BOM 的 .cs 文件**（`BatchPlotHostProgress.cs`、`Services\\Scanning\\CadEntGet.cs`、`Services\\Scanning\\TianzhengTextReader.cs`）→ 批量改源码的 Python 脚本用 `utf-8-sig` 硬读会 `UnicodeDecodeError: ... byte 0xc5`，必须 utf-8 失败回退 gbk 并**原样写回原编码**（`scripts\\la_fix_array_empty.py` 已内置）。
- **`[Reflection.AssemblyName]::GetAssemblyName()` / `ReflectionOnlyLoadFrom()` 不被沙箱拦**（只有 `LoadFile` 拦）—— 从此校验程序集引用有了准确手段，不必再裸字节猜。
- PowerShell 里做"字节含 UTF-8 中文"判断要用 `[Text.Encoding]::GetEncoding(28591)` 映射字节；**用 `UTF8.GetString(UTF8.GetBytes(s))` 得到的是码点不是字节，永远匹配不上**（本次先误判「增加图幅缺失」，就是这个原因）。
- PowerShell 5.1 读无 BOM 的 .ps1 按 ANSI 解码 → 脚本里要么带 BOM，要么用码点构造中文串（`New-FromCodePoints`）。

**待办**：`bin\\` / `bin-acad\\` / `bin-acad2025-2027\\` 因本轮改了共享源码（`Common\\Views\\SettingsForm.xaml.cs` 等）已过期，需关掉本机 AutoCAD 2020 后整解决方案 `-t:Rebuild` 再重打 `release\\v1.15.7.6`（把 2010-2012 包并进去）。
""")
save(DAILY, d, denc)
print("已写回 2026-09-22.md (%d bytes, enc=%s)" % (len(d.encode("utf-8")), denc))
print("ALL DONE")
