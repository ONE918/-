# -*- coding: utf-8 -*-
"""把 src 下所有 Array.Empty<T>()（.NET 4.6+）改成 new T[0]（net45 可用）。

注意：本仓库存在 GBK 无 BOM 的源文件（中文 locale 下 csc 按系统默认代码页读），
所以读写都要探测编码并原样保留，否则会破坏文件。
"""
import io, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATTERN = re.compile(r"(?:System\.)?Array\.Empty<([^>]+)>\(\)")

def load(full):
    raw = open(full, "rb").read()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig"), "utf-8-sig"
    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        pass
    try:
        return raw.decode("gbk"), "gbk"
    except UnicodeDecodeError as e:
        print("FAIL 无法解码 [%s] %s" % (full, e))
        sys.exit(1)

def save(full, s, enc):
    with io.open(full, "w", encoding=enc, newline="") as f:
        f.write(s)

fixed = []
for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, "src")):
    dirnames[:] = [d for d in dirnames if d.lower() not in ("obj", "bin")]
    for name in filenames:
        if not name.endswith(".cs"):
            continue
        full = os.path.join(dirpath, name)
        rel = os.path.relpath(full, ROOT)
        s, enc = load(full)
        n = len(PATTERN.findall(s))
        if not n:
            continue
        s2 = PATTERN.sub(lambda m: "new %s[0]" % m.group(1).strip(), s)
        if PATTERN.search(s2):
            print("FAIL [%s] 替换后仍残留 Array.Empty" % rel)
            sys.exit(1)
        save(full, s2, enc)
        fixed.append((rel, n, enc))
        print("OK   [%s] Array.Empty x%d -> new T[0]  (enc=%s)" % (rel, n, enc))

print("\n处理文件数 = %d，共 %d 处" % (len(fixed), sum(n for _, n, _ in fixed)))
print("ALL DONE")
