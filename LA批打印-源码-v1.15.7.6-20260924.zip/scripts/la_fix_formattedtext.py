# -*- coding: utf-8 -*-
"""修 SettingsForm.xaml.cs 里 FormattedText 的 net45 兼容问题。

FormattedText 带 pixelsPerDip 的重载是 .NET 4.6.2 才有的；net45 下第 7 个参数是
NumberSubstitution，不能传 double。把两处构造收敛到带 #if 的辅助方法 CreatePreviewText。
"""
import io, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REL = r"src\Common\Views\SettingsForm.xaml.cs"
FULL = os.path.join(ROOT, REL)

raw = open(FULL, "rb").read()
if raw.startswith(b"\xef\xbb\xbf"):
    s, enc = raw.decode("utf-8-sig"), "utf-8-sig"
else:
    s, enc = raw.decode("utf-8"), "utf-8"

def sub(old, new, must=None, gone=None, tag=""):
    global s
    n = s.count(old)
    if n != 1:
        print("FAIL [%s] 期望命中 1 次，实际 %d 次：\n%s" % (tag, n, old[:300]))
        sys.exit(1)
    s = s.replace(old, new, 1)
    for m in (must or []):
        if m not in s:
            print("FAIL [%s] 缺少: %s" % (tag, m)); sys.exit(1)
    for g in (gone or []):
        if g in s:
            print("FAIL [%s] 仍存在: %s" % (tag, g)); sys.exit(1)
    print("OK   [%s]" % tag)


# ── A. 删掉 pixelsPerDip 局部块（改由 CreatePreviewText 内部按平台决定）──
sub(
    """#if ACAD2012
        // VisualTreeHelper.GetDpi 是 .NET 4.6.2 才有的；net45 下用显示设备的缩放比换算。
        var compositionTarget = PresentationSource.FromVisual(this)?.CompositionTarget;
        var pixelsPerDip = compositionTarget != null ? compositionTarget.TransformToDevice.M11 : 1.0;
#else
        var pixelsPerDip = VisualTreeHelper.GetDpi(this).PixelsPerDip;
#endif
        if (_columns.Count == 0)""",
    """        if (_columns.Count == 0)""",
    must=["if (_columns.Count == 0)"],
    gone=["var pixelsPerDip"],
    tag="A 删除 pixelsPerDip 局部块",
)

# ── B. 提示文字改用辅助方法 ──
sub(
    """            var hint = new FormattedText(
                "请勾选需要生成的目录列",
                CultureInfo.CurrentCulture,
                System.Windows.FlowDirection.LeftToRight,
                new Typeface("Microsoft YaHei UI"),
                12d,
                Brushes.DimGray,
                pixelsPerDip);""",
    """            var hint = CreatePreviewText(
                "请勾选需要生成的目录列",
                new Typeface("Microsoft YaHei UI"),
                12d,
                Brushes.DimGray);""",
    must=["var hint = CreatePreviewText("],
    tag="B 提示文字",
)

# ── C. 列头文字改用辅助方法 ──
sub(
    """            var text = new FormattedText(
                column.Header,
                CultureInfo.CurrentCulture,
                System.Windows.FlowDirection.LeftToRight,
                typeface,
                Math.Max(1, fontPixels),
                Brushes.Black,
                pixelsPerDip);""",
    """            var text = CreatePreviewText(
                column.Header,
                typeface,
                Math.Max(1, fontPixels),
                Brushes.Black);""",
    must=["var text = CreatePreviewText("],
    gone=["pixelsPerDip", "new FormattedText("],
    tag="C 列头文字",
)

# ── D. 新增 CreatePreviewText 辅助方法 ──
sub(
    """    private static Typeface CreateTypeface(string fontName)
    {
        try
        {
            return new Typeface(new FontFamily(fontName), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        }
        catch
        {
            return new Typeface(new FontFamily("Microsoft YaHei UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        }
    }
}""",
    """    private static Typeface CreateTypeface(string fontName)
    {
        try
        {
            return new Typeface(new FontFamily(fontName), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        }
        catch
        {
            return new Typeface(new FontFamily("Microsoft YaHei UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        }
    }

    /// <summary>
    /// 构造目录预览用的 <see cref="FormattedText"/>。
    /// 带 pixelsPerDip 的重载是 .NET 4.6.2 才有的（net45 下该位置是 NumberSubstitution），
    /// 所以 AutoCAD 2010-2012 构建（net45）走不带该参数的传统重载。
    /// </summary>
    private FormattedText CreatePreviewText(string text, Typeface typeface, double emSize, Brush brush)
    {
#if ACAD2012
        return new FormattedText(
            text,
            CultureInfo.CurrentCulture,
            System.Windows.FlowDirection.LeftToRight,
            typeface,
            emSize,
            brush);
#else
        return new FormattedText(
            text,
            CultureInfo.CurrentCulture,
            System.Windows.FlowDirection.LeftToRight,
            typeface,
            emSize,
            brush,
            VisualTreeHelper.GetDpi(this).PixelsPerDip);
#endif
    }
}""",
    must=["private FormattedText CreatePreviewText(string text, Typeface typeface, double emSize, Brush brush)",
          "VisualTreeHelper.GetDpi(this).PixelsPerDip"],
    tag="D 新增 CreatePreviewText",
)

with io.open(FULL, "w", encoding=enc, newline="") as f:
    f.write(s)
print("\n已写回 %s (enc=%s)" % (REL, enc))
print("ALL DONE")
