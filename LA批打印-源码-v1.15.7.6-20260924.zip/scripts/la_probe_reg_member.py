# -*- coding: utf-8 -*-
"""探针：在 ObjectARX 2012 (18.2) 上确认 HostApplicationServices 的注册表产品根路径成员名。
   编译器会逐个报错，没被报错的那一行就是正确成员。"""
import io, os, shutil, subprocess

tmp = os.path.join(os.environ["TEMP"], "la_probe_reg")
shutil.rmtree(tmp, ignore_errors=True)
os.makedirs(tmp)

arx = os.path.join(os.environ["TEMP"], "la_acad2012", "lib")

def w(name, text):
    with io.open(os.path.join(tmp, name), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text)

w("probe.csproj", """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net45</TargetFramework>
    <LangVersion>latest</LangVersion>
    <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
    <PlatformTarget>x64</PlatformTarget>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="Probe.cs" />
    <Reference Include="acmgd"><HintPath>{arx}\\acmgd.dll</HintPath><Private>false</Private></Reference>
    <Reference Include="acdbmgd"><HintPath>{arx}\\acdbmgd.dll</HintPath><Private>false</Private></Reference>
  </ItemGroup>
</Project>
""".format(arx=arx))

candidates = [
    ("A", "Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.RegistryProductRootKey"),
    ("B", "Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.ProductRootKey"),
    ("C", "Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.UserRegistryProductRootKey"),
    ("D", "Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.RegistryKey"),
]

body = ["using System;", "namespace ProbeNs", "{", "    internal static class Probe", "    {", "        public static void Run()", "        {"]
lines = []
for tag, expr in candidates:
    lines.append("            var %s = %s;   // <<%s>>" % (tag.lower(), expr, tag))
body += lines
body += ["            Console.WriteLine(\"\" + a + b + c + d);", "        }", "    }", "}", ""]
w("Probe.cs", "\n".join(body))

dotnet = r"C:\Users\T490\.workbuddy\binaries\dotnet-sdk\dotnet.exe"
env = dict(os.environ)
env["DOTNET_CLI_UI_LANGUAGE"] = "en"
r = subprocess.run([dotnet, "build", "probe.csproj", "-t:Rebuild", "--nologo", "-v:q"],
                   cwd=tmp, env=env, capture_output=True, text=True, errors="ignore")
out = (r.stdout or "") + (r.stderr or "")
print("exit =", r.returncode)
for line in out.splitlines():
    if "error" in line.lower():
        # 只打印 行号 + 错误码 + 消息
        print("   ", line.strip()[:220])

print("\n== 结论：没有报错的行 = 可用成员 ==")
print("A = RegistryProductRootKey")
print("B = ProductRootKey")
print("C = UserRegistryProductRootKey")
print("D = RegistryKey")
