"""校验三套产物 DLL 是否带上了「点中哪个属性文字就取哪个」的新逻辑。"""
import hashlib
import os

ROOT = r"d:\00YPL内部环境V1.0\03-插件合集\LA打印\batchPrintZWCAD-1.15.7.6"

DLLS = [
    ("ZWCAD", os.path.join(ROOT, r"bin\BatchPlotter.dll")),
    ("ACAD2015-2024", os.path.join(ROOT, r"bin-acad\AcadBatchPlot.dll")),
    ("ACAD2025-2027", os.path.join(ROOT, r"bin-acad2025-2027\AcadBatchPlot.Core.dll")),
]

# C# 方法名等 ASCII 元数据串
ASCII_NEEDLES = [
    "GetNestedEntity",
    "PromptNestedEntityOptions",
    "PromptNestedEntityResult",
    "AllowNone",
    "PickByWindow",
    "ResolvePickedAttribute",
    "FindAttributeAtPickPoint",
    "DistanceToAttribute",
    "EstimateTextWidth",
    "DescribeValue",
    "AttributeCandidate",
]

# 新增的中文提示串（#US 堆里是 UTF-16LE，偏移不定）
CN_NEEDLES = [
    "点中要作为文件名的属性文字",
    "回车=改用框选",
    "只取点中的属性文字",
    "这里不是属性文字",
    "框选要作为文件名的属性文字",
]

# 确认已移除的旧提示（不该再出现在新产物里）
GONE_CN = [
    "框选要作为文件名的属性文字(第",
]

for label, path in DLLS:
    if not os.path.isfile(path):
        print("[MISS] %s -> %s" % (label, path))
        continue
    with open(path, "rb") as handle:
        data = handle.read()
    digest = hashlib.sha256(data).hexdigest()
    print("\n=== %s ===" % label)
    print("  size=%d  sha256=%s" % (len(data), digest))

    bad = [n for n in ASCII_NEEDLES if n.encode("ascii") not in data]
    print("  ascii  %d/%d %s" % (len(ASCII_NEEDLES) - len(bad), len(ASCII_NEEDLES),
                                 ("MISSING: " + ",".join(bad)) if bad else "OK"))

    text0 = data.decode("utf-16-le", errors="ignore")
    text1 = data[1:].decode("utf-16-le", errors="ignore")
    miss_cn = []
    for needle in CN_NEEDLES:
        if needle not in text0 and needle not in text1:
            miss_cn.append(needle)
    print("  cn     %d/%d %s" % (len(CN_NEEDLES) - len(miss_cn), len(CN_NEEDLES),
                                 ("MISSING: " + ",".join(miss_cn)) if miss_cn else "OK"))

    leftovers = [n for n in GONE_CN if n in text0 or n in text1]
    print("  old-text leftover: %s" % (leftovers if leftovers else "none"))
