"""探测三套 CAD 引用程序集里与「精确点选属性文字」相关的 API 是否可用。

只做裸字节检索（ASCII 元数据串），用于初步判断；最终以编译结果为准。
"""
import os

NUGET = r"C:\Users\T490\.nuget\packages"

TARGETS = [
    ("ZWCAD  (ZwManaged)", os.path.join(NUGET, r"zwcad.net.2025\1.0.0\lib\net47\ZwManaged.dll")),
    ("ZWCAD  (ZwDatabaseMgd)", os.path.join(NUGET, r"zwcad.net.2025\1.0.0\lib\net47\ZwDatabaseMgd.dll")),
    ("ACAD20 (AcMgd)", os.path.join(NUGET, r"autocad.net\20.0.1\lib\45\AcMgd.dll")),
    ("ACAD20 (AcCoreMgd)", os.path.join(NUGET, r"autocad.net.core\20.0.1\lib\45\AcCoreMgd.dll")),
    ("ACAD25 (AcMgd)", os.path.join(NUGET, r"autocad.net\25.0.1\lib\net8.0\AcMgd.dll")),
    ("ACAD25 (AcCoreMgd)", os.path.join(NUGET, r"autocad.net.core\25.0.0\lib\net8.0\AcCoreMgd.dll")),
]

KEYWORDS = [
    "PromptSelectionResult",
    "PickPoint",
    "PromptNestedEntityOptions",
    "PromptNestedEntityResult",
    "GetNestedEntity",
    "PromptSelectionOptions",
    "GetSelection",
    "SingleOnly",
    "PromptEntityResult",
    "GetObjectIds",
    "SelectionSet",
    "AttributeReference",
    "GeometricExtents",
]

for label, path in TARGETS:
    if not os.path.isfile(path):
        print(f"[MISS] {label}: {path}")
        continue
    with open(path, "rb") as handle:
        data = handle.read()
    size = len(data)
    print(f"\n=== {label}  ({size} bytes) ===")
    for word in KEYWORDS:
        hits = data.count(word.encode("ascii"))
        hits16 = data.count(word.encode("utf-16-le"))
        mark = "OK " if (hits or hits16) else "-- "
        print(f"  {mark}{word:<28} ascii={hits} utf16={hits16}")
