"""Batch-rename user-facing wording in RectangleBatchPlotForm.xaml.cs
from '框选' (rubber-band only) to '拾取' (pick: click or window)."""
import io
import sys

PATH = (r"d:\00YPL内部环境V1.0\03-插件合集\LA打印\batchPrintZWCAD-1.15.7.6"
        r"\src\Common\Views\RectangleBatchPlotForm.xaml.cs")

REPLACEMENTS = [
    ("本次会话框选到的示例值（字段 → 框选时的属性值）",
     "本次会话拾取到的示例值（字段 → 拾取时的属性值）"),
    ("最后一次框选命中的属性位置（世界坐标，NaN = 本次会话还没框选过）",
     "最后一次拾取命中的属性位置（世界坐标，NaN = 本次会话还没拾取过）"),
    ("取不到值时是否退回本次框选到的文字",
     "取不到值时是否退回本次拾取到的文字"),
    ("优先用**框选时框到的那张图**（框哪张图就显示哪张图上的文字），\n    /// 还没框选过时退回清单第一张要打印的图纸；那张图取不到该字段时退回本次框选到的值。",
     "优先用**拾取时点/框到的那张图**（点/框哪张图就显示哪张图上的文字），\n    /// 还没拾取过时退回清单第一张要打印的图纸；那张图取不到该字段时退回本次拾取到的值。"),
    ("优先用框选时框到的那张图（框哪张图就显示哪张图上的文字）",
     "优先用拾取时点/框到的那张图（点/框哪张图就显示哪张图上的文字）"),
    ("框选过但那张图不在清单里则返回 null（直接用框选到的文字，不退回第一张图的取值）。",
     "拾取过但那张图不在清单里则返回 null（直接用拾取到的文字，不退回第一张图的取值）。"),
    ("框选到的属性落在哪张图框里",
     "拾取到的属性落在哪张图框里"),
    ("当前布局名（框选发生在当前空间，用于把框到的属性位置对应到清单里的图）。",
     "当前布局名（拾取发生在当前空间，用于把拾取到的属性位置对应到清单里的图）。"),
    ("尚未设置文件名字段：点「文件命名」框选属性文字，或右键「增加横线 / 添加字段」。",
     "尚未设置文件名字段：点「文件命名」拾取属性文字，或右键「增加横线 / 添加字段」。"),
]

with io.open(PATH, "r", encoding="utf-8", newline="") as handle:
    text = handle.read()

missing = []
for old, new in REPLACEMENTS:
    if old not in text:
        missing.append(old[:40])
        continue
    text = text.replace(old, new)

with io.open(PATH, "w", encoding="utf-8", newline="") as handle:
    handle.write(text)

print("replaced: %d/%d" % (len(REPLACEMENTS) - len(missing), len(REPLACEMENTS)))
for item in missing:
    print("MISSING: " + item.encode("unicode_escape").decode("ascii"))
