# -*- coding: utf-8 -*-
"""在临时目录建一个最小 net40 探针工程：
  1) 验证 .NET 9 SDK 能不能构建 net40（需要 NuGet 引用程序集）；
  2) 验证 C# 12 的泛型 using 别名能否把 IReadOnlyList/Dictionary 零改动映射到 IList/IDictionary；
  3) 验证 UseWpf + net40 能否编译。
"""
import io, os, subprocess, sys

tmp = os.path.join(os.environ["TEMP"], "la_probe_net40")
if os.path.isdir(tmp):
    import shutil
    shutil.rmtree(tmp, ignore_errors=True)
os.makedirs(tmp)

def w(name, text):
    with io.open(os.path.join(tmp, name), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(text)

w("probe.csproj", """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net40</TargetFramework>
    <LangVersion>latest</LangVersion>
    <UseWpf>true</UseWpf>
    <PlatformTarget>x64</PlatformTarget>
    <Nullable>enable</Nullable>
    <GenerateResourceUsePreserializedResources>false</GenerateResourceUsePreserializedResources>
    <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
    <EnableDefaultPageItems>false</EnableDefaultPageItems>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="Aliases.cs" />
    <Compile Include="Probe.cs" />
    <Compile Include="ProbeForm.xaml.cs" />
    <Page Include="ProbeForm.xaml">
      <Generator>MSBuild:Compile</Generator>
      <SubType>Designer</SubType>
    </Page>
  </ItemGroup>
</Project>
""")

# 泛型别名（C# 12）
w("Aliases.cs", """#if ACAD2012
global using IReadOnlyList<T> = System.Collections.Generic.IList<T>;
global using IReadOnlyDictionary<TKey, TValue> = System.Collections.Generic.IDictionary<TKey, TValue>;
global using IReadOnlyCollection<T> = System.Collections.Generic.ICollection<T>;
#endif

// .NET 4.0 没有 CallerMemberNameAttribute，自己补一个
#if ACAD2012
namespace System.Runtime.CompilerServices
{
    [AttributeUsage(AttributeTargets.Parameter, Inherited = false)]
    internal sealed class CallerMemberNameAttribute : Attribute
    {
        public CallerMemberNameAttribute() { }
    }
}
#endif
""")

w("Probe.cs", """using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ProbeNs
{
    internal sealed class Probe : INotifyPropertyChanged
    {
        private readonly List<string> _items = new List<string> { "a", "b" };

        // 别名生效的话，这里会解析成 IList<string>
        public IReadOnlyList<string> Items => _items;

        public IReadOnlyDictionary<string, string> Map =>
            new Dictionary<string, string> { ["k"] = "v" };

        public event PropertyChangedEventHandler? PropertyChanged;

        private void Raise([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        public string Info()
        {
            var parts = new List<string>();
            parts.Add(Items.Count.ToString());
            parts.Add(Array.Empty<string>().Length.ToString());
            return string.Join(",", parts);
        }
    }
}
""")

w("ProbeForm.xaml", """<Window x:Class="ProbeNs.ProbeForm"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="probe" Height="120" Width="200">
    <Grid>
        <TextBlock Text="hello" />
    </Grid>
</Window>
""")

w("ProbeForm.xaml.cs", """namespace ProbeNs
{
    public partial class ProbeForm : System.Windows.Window
    {
        public ProbeForm()
        {
            InitializeComponent();
        }
    }
}
""")

dotnet = r"C:\Users\T490\.workbuddy\binaries\dotnet-sdk\dotnet.exe"
env = dict(os.environ)
env["DOTNET_CLI_UI_LANGUAGE"] = "en"

# 先不带 ACAD2012 跑一次：应当因 IReadOnlyList / CallerMemberName / Array.Empty 报错
for define in ("", "ACAD2012"):
    args = [dotnet, "build", "probe.csproj", "-t:Rebuild", "--nologo", "-v:q"]
    if define:
        args.append("-p:DefineConstants=" + define)
    r = subprocess.run(args, cwd=tmp, env=env, capture_output=True, text=True, errors="ignore")
    print("=" * 60)
    print("DefineConstants=%r  exit=%d" % (define or "(none)", r.returncode))
    out = (r.stdout or "") + (r.stderr or "")
    for line in out.splitlines():
        if ("error" in line.lower()) or ("warning CS" in line) or ("Build succeeded" in line) or ("Build FAILED" in line):
            print("   " + line.strip())
    if r.returncode == 0:
        dll = os.path.join(tmp, "bin", "Debug", "net40", "probe.dll")
        print("   OUTPUT:", dll, os.path.exists(dll))
