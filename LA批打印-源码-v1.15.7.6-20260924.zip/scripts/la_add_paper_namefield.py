# -*- coding: utf-8 -*-
"""给通用型批量打印「文件命名」增加保留字段「图幅」（按各图纸识别出的图幅取值）。"""
import io, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def read(p):
    with io.open(p, "r", encoding="utf-8-sig") as f:
        return f.read()

def write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)

def sub(path, pairs, must_after=None, gone=None):
    p = os.path.join(ROOT, path)
    s = read(p)
    for old, new in pairs:
        if old not in s:
            print("MISS  [%s] old not found:\n%s" % (path, old[:200]))
            sys.exit(1)
        if s.count(old) != 1:
            print("AMBIG [%s] old appears %d times:\n%s" % (path, s.count(old), old[:200]))
            sys.exit(1)
        s = s.replace(old, new, 1)
    for m in (must_after or []):
        if m not in s:
            print("VERIFY-FAIL [%s] missing: %s" % (path, m))
            sys.exit(1)
    for g in (gone or []):
        if g in s:
            print("VERIFY-FAIL [%s] should be gone: %s" % (path, g))
            sys.exit(1)
    write(p, s)
    print("OK    [%s]" % path)


# ─────────────────────────── 1. 面板取值：图幅字段 ───────────────────────────
sub(
    r"src\Common\Views\RectangleBatchPlotForm.xaml.cs",
    [
        (
            """    /// <summary>
    /// 取某字段在指定图框作业里的文字；<paramref name="found"/> 表示是否取到非空值。
    /// 字段为「块名|属性名」时只认该属性块，为纯属性名时取任意属性块里的命中；
    /// 固定文本项（横线等）不取值，交给 <see cref="BuildNameFieldSegments"/> 原样输出。
    /// </summary>
    private static string ResolveFieldValue(PlotJob? job, string field, out bool found)
    {
        found = false;
        if (job == null || FileNameFieldSpec.IsLiteral(field))
        {
            return "";
        }

        FileNameFieldSpec.Parse(field, out var blockName, out var tag);""",
            """    /// <summary>
    /// 取某字段在指定图框作业里的文字；<paramref name="found"/> 表示是否取到非空值。
    /// 字段为「块名|属性名」时只认该属性块，为纯属性名时取任意属性块里的命中；
    /// 字段为保留名「图幅」时取该图纸<b>识别出的图幅</b>（与图框块面板文件名占位符 T 同口径）；
    /// 固定文本项（横线等）不取值，交给 <see cref="BuildNameFieldSegments"/> 原样输出。
    /// </summary>
    private string ResolveFieldValue(PlotJob? job, string field, out bool found)
    {
        found = false;
        if (job == null || FileNameFieldSpec.IsLiteral(field))
        {
            return "";
        }

        if (FileNameFieldSpec.IsPaperField(field))
        {
            // 「图幅」保留字段：按该图纸识别出的图幅取值（A2、A1+1∕2 等），
            // 加长图名格式沿用「设置窗 - 文件名页」里的配置，与占位符 T 完全一致。
            var paper = FileNameSanitizer.NormalizeLongPaperFraction(
                OutputPaperNameResolver.Resolve(job, _settings.LongPaperSnapToleranceMm),
                _settings.LongPaperNameFormat);
            if (string.IsNullOrWhiteSpace(paper))
            {
                return "";
            }

            found = true;
            return paper.Trim();
        }

        FileNameFieldSpec.Parse(field, out var blockName, out var tag);""",
        ),
    ],
    must_after=[
        "private string ResolveFieldValue(PlotJob? job, string field, out bool found)",
        "FileNameFieldSpec.IsPaperField(field)",
        "OutputPaperNameResolver.Resolve(job, _settings.LongPaperSnapToleranceMm)",
        "_settings.LongPaperNameFormat)",
    ],
    gone=["private static string ResolveFieldValue"],
)

# ─────────────────────────── 2. 右键「增加图幅」 ───────────────────────────
sub(
    r"src\Common\Views\RectangleBatchPlotForm.xaml.cs",
    [
        (
            """    private void AddNameFieldDash_Click(object sender, RoutedEventArgs e)
        => InsertNameFieldLiteral(FileNameFieldSpec.DefaultLiteral, ResolveNameFieldEntry(sender));""",
            """    private void AddNameFieldDash_Click(object sender, RoutedEventArgs e)
        => InsertNameFieldLiteral(FileNameFieldSpec.DefaultLiteral, ResolveNameFieldEntry(sender));

    /// <summary>
    /// 右键「增加图幅」：在点中的字段之后（在空白处右键时追加到末尾）插入保留字段「图幅」，
    /// 每张图纸各取自己识别出的图幅（A2、A1+1∕2 等），与图框块面板文件名占位符 T 同口径。
    /// </summary>
    private void AddNameFieldPaper_Click(object sender, RoutedEventArgs e)
        => InsertNameFieldPaper(ResolveNameFieldEntry(sender));

    /// <summary>插入「图幅」保留字段；列表中已有该项时只提示，不重复添加。</summary>
    private void InsertNameFieldPaper(NameFieldEntry? after)
    {
        var field = FileNameFieldSpec.PaperFieldName;
        if (_nameFieldTags.Contains(field, StringComparer.OrdinalIgnoreCase))
        {
            _status.Text = $"文件命名：「{field}」已在列表中（每张图纸各取自己识别出的图幅，无需重复添加）。";
            return;
        }

        var index = _nameFieldTags.Count;
        if (after != null)
        {
            var entryIndex = _nameFieldEntries.IndexOf(after);
            if (entryIndex >= 0)
            {
                index = entryIndex + 1;
            }
        }

        _nameFieldTags.Insert(Math.Max(0, Math.Min(index, _nameFieldTags.Count)), field);
        // 字段集合变了，PersistNameFields 里的 RefreshNameFieldList 会按新顺序重建列表项。
        PersistNameFields();
        _status.Text = $"文件命名：已插入「{field}」（按各图纸识别出的图幅取值，"
                       + "加长图按设置窗里的图幅名格式输出；右键可前移 / 后移 / 删除）。";
    }""",
        ),
    ],
    must_after=[
        "private void AddNameFieldPaper_Click(object sender, RoutedEventArgs e)",
        "private void InsertNameFieldPaper(NameFieldEntry? after)",
        "FileNameFieldSpec.PaperFieldName",
    ],
)

# ─────────────────────────── 3. 手动添加字段的提示语 ───────────────────────────
sub(
    r"src\Common\Views\RectangleBatchPlotForm.xaml.cs",
    [
        (
            """        _status.Text = "文件命名：输入属性名后回车即可（与图纸中属性块的属性名一致，不区分大小写）；"
                       + "只输入横线、斜杠这类符号则按固定文本拼进文件名。";""",
            """        _status.Text = "文件命名：输入属性名后回车即可（与图纸中属性块的属性名一致，不区分大小写）；"
                       + "输入「图幅」取该图纸识别出的图幅；只输入横线、斜杠这类符号则按固定文本拼进文件名。";""",
        ),
    ],
    must_after=["输入「图幅」取该图纸识别出的图幅"],
)

# ─────────────────────────── 4. XAML：菜单项 / 提示语 ───────────────────────────
sub(
    r"src\Common\Views\RectangleBatchPlotForm.xaml",
    [
        (
            """                        <MenuItem Header="增加横线（-）" Click="AddNameFieldDash_Click" />
                        <MenuItem Header="添加字段" Click="AddNameField_Click" />""",
            """                        <MenuItem Header="增加图幅" Click="AddNameFieldPaper_Click" />
                        <MenuItem Header="增加横线（-）" Click="AddNameFieldDash_Click" />
                        <MenuItem Header="添加字段" Click="AddNameField_Click" />""",
        ),
        (
            """                                                    <MenuItem Header="增加横线（-）" Click="AddNameFieldDash_Click" />""",
            """                                                    <MenuItem Header="增加图幅" Click="AddNameFieldPaper_Click" />
                                                    <MenuItem Header="增加横线（-）" Click="AddNameFieldDash_Click" />""",
        ),
        (
            """                               Text="（未设置：点「文件命名」拾取属性文字，或右键增加横线 / 添加字段）\"""",
            """                               Text="（未设置：点「文件命名」拾取属性文字，或右键增加图幅 / 增加横线 / 添加字段）\"""",
        ),
        (
            """右键可前移 / 后移 / 增加横线 / 删除。 -->""",
            """右键可前移 / 后移 / 增加图幅 / 增加横线 / 删除。 -->""",
        ),
        (
            """按列表顺序用连接符拼成文件名。点某一段可编辑字段，右键可前移 / 后移 / 增加横线 / 删除。">""",
            """按列表顺序用连接符拼成文件名。点某一段可编辑字段，右键可前移 / 后移 / 增加图幅 / 增加横线 / 删除。">""",
        ),
        (
            """                 灰色 = 那张图没取到该字段的值。点某一段可编辑该字段（属性名 / 块名|属性名 / 横线等固定文本），""",
            """                 灰色 = 那张图没取到该字段的值。「图幅」是保留字段，取该图纸识别出的图幅（A2、A1+1∕2）。
                 点某一段可编辑该字段（属性名 / 块名|属性名 / 图幅 / 横线等固定文本），""",
        ),
    ],
    must_after=[
        'Header="增加图幅" Click="AddNameFieldPaper_Click"',
        "增加图幅 / 增加横线 / 添加字段",
        "右键可前移 / 后移 / 增加图幅 / 增加横线 / 删除。",
        "「图幅」是保留字段",
    ],
)

# ─────────────────────────── 5. 列表项悬停提示：图幅专用文案 ───────────────────────────
sub(
    r"src\Common\Views\NameFieldEntry.cs",
    [
        (
            """            FileNameFieldSpec.Parse(_tag, out var blockName, out var tag);""",
            """            if (FileNameFieldSpec.IsPaperField(_tag))
            {
                var effect = _hasValue
                    ? $"取值（来自拾取时点/框到的那张图）：{_preview}"
                    : "拾取时点/框到的那张图还没识别出图幅（该段不参与文件名，显示为灰色）。";
                return $"{effect}\\n字段：{_tag}（保留名，取该图纸识别出的图幅，与图框块面板占位符 T 同口径）\\n"
                       + "要取属性块里名为「图幅」的属性，请写成「块名|图幅」。\\n"
                       + "右键：前移 / 后移 / 增加横线 / 删除该字段 / 清空字段。";
            }

            FileNameFieldSpec.Parse(_tag, out var blockName, out var tag);""",
        ),
        (
            """    /// 字段名（= 取值依据）：属性名，或「块名|属性名」（同名属性分属不同属性块时靠它区分）；
    /// 不含汉字/字母/数字时是固定文本项（横线等），原样拼进文件名。""",
            """    /// 字段名（= 取值依据）：属性名，或「块名|属性名」（同名属性分属不同属性块时靠它区分）；
    /// 整项为保留名「图幅」时取该图纸识别出的图幅；
    /// 不含汉字/字母/数字时是固定文本项（横线等），原样拼进文件名。""",
        ),
    ],
    must_after=[
        "FileNameFieldSpec.IsPaperField(_tag)",
        "与图框块面板占位符 T 同口径",
        "整项为保留名「图幅」时取该图纸识别出的图幅",
    ],
)

print("\nALL DONE")
