$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$plotterRoot = Join-Path $repoRoot "resources\zwcad\Plotters"
$pmpDir = Join-Path $plotterRoot "PMP Files"
New-Item -ItemType Directory -Force -Path $pmpDir | Out-Null

$papers = @(
    @{ Name = "A4"; W = 297.0; H = 210.0 },
    @{ Name = "A4_1.25L"; W = 371.0; H = 210.0 },
    @{ Name = "A4_1.50L"; W = 446.0; H = 210.0 },
    @{ Name = "A4_1.75L"; W = 520.0; H = 210.0 },
    @{ Name = "A4_2L"; W = 594.0; H = 210.0 },
    @{ Name = "A4_2.25L"; W = 668.0; H = 210.0 },
    @{ Name = "A4_2.50L"; W = 743.0; H = 210.0 },
    @{ Name = "A4_2.75L"; W = 817.0; H = 210.0 },
    @{ Name = "A4_3L"; W = 891.0; H = 210.0 },
    @{ Name = "A4_3.25L"; W = 965.0; H = 210.0 },
    @{ Name = "A4_3.50L"; W = 1040.0; H = 210.0 },
    @{ Name = "A4_3.75L"; W = 1114.0; H = 210.0 },
    @{ Name = "A4_4L"; W = 1188.0; H = 210.0 },
    @{ Name = "A3"; W = 420.0; H = 297.0 },
    @{ Name = "A3_1.25L"; W = 525.0; H = 297.0 },
    @{ Name = "A3_1.50L"; W = 630.0; H = 297.0 },
    @{ Name = "A3_1.75L"; W = 735.0; H = 297.0 },
    @{ Name = "A3_2L"; W = 840.0; H = 297.0 },
    @{ Name = "A3_2.25L"; W = 945.0; H = 297.0 },
    @{ Name = "A3_2.50L"; W = 1050.0; H = 297.0 },
    @{ Name = "A3_2.75L"; W = 1155.0; H = 297.0 },
    @{ Name = "A3_3L"; W = 1260.0; H = 297.0 },
    @{ Name = "A3_3.25L"; W = 1365.0; H = 297.0 },
    @{ Name = "A3_3.50L"; W = 1470.0; H = 297.0 },
    @{ Name = "A3_3.75L"; W = 1575.0; H = 297.0 },
    @{ Name = "A3_4L"; W = 1680.0; H = 297.0 },
    @{ Name = "A2"; W = 594.0; H = 420.0 },
    @{ Name = "A2_1.25L"; W = 743.0; H = 420.0 },
    @{ Name = "A2_1.50L"; W = 891.0; H = 420.0 },
    @{ Name = "A2_1.75L"; W = 1040.0; H = 420.0 },
    @{ Name = "A2_2L"; W = 1188.0; H = 420.0 },
    @{ Name = "A2_2.25L"; W = 1337.0; H = 420.0 },
    @{ Name = "A2_2.50L"; W = 1485.0; H = 420.0 },
    @{ Name = "A2_2.75L"; W = 1634.0; H = 420.0 },
    @{ Name = "A2_3L"; W = 1782.0; H = 420.0 },
    @{ Name = "A2_3.25L"; W = 1931.0; H = 420.0 },
    @{ Name = "A2_3.50L"; W = 2079.0; H = 420.0 },
    @{ Name = "A2_3.75L"; W = 2228.0; H = 420.0 },
    @{ Name = "A2_4L"; W = 2376.0; H = 420.0 },
    @{ Name = "A1"; W = 841.0; H = 594.0 },
    @{ Name = "A1_1.25L"; W = 1051.0; H = 594.0 },
    @{ Name = "A1_1.50L"; W = 1262.0; H = 594.0 },
    @{ Name = "A1_1.75L"; W = 1472.0; H = 594.0 },
    @{ Name = "A1_2L"; W = 1682.0; H = 594.0 },
    @{ Name = "A1_2.25L"; W = 1892.0; H = 594.0 },
    @{ Name = "A1_2.50L"; W = 2103.0; H = 594.0 },
    @{ Name = "A1_2.75L"; W = 2313.0; H = 594.0 },
    @{ Name = "A1_3L"; W = 2523.0; H = 594.0 },
    @{ Name = "A1_3.25L"; W = 2733.0; H = 594.0 },
    @{ Name = "A1_3.50L"; W = 2944.0; H = 594.0 },
    @{ Name = "A1_3.75L"; W = 3154.0; H = 594.0 },
    @{ Name = "A1_4L"; W = 3364.0; H = 594.0 },
    @{ Name = "A0"; W = 1189.0; H = 841.0 },
    @{ Name = "A0_1.25L"; W = 1486.0; H = 841.0 },
    @{ Name = "A0_1.50L"; W = 1784.0; H = 841.0 },
    @{ Name = "A0_1.75L"; W = 2081.0; H = 841.0 },
    @{ Name = "A0_2L"; W = 2378.0; H = 841.0 },
    @{ Name = "A0_2.25L"; W = 2675.0; H = 841.0 },
    @{ Name = "A0_2.50L"; W = 2973.0; H = 841.0 },
    @{ Name = "A0_2.75L"; W = 3270.0; H = 841.0 },
    @{ Name = "A0_3L"; W = 3567.0; H = 841.0 },
    @{ Name = "A0_3.25L"; W = 3864.0; H = 841.0 },
    @{ Name = "A0_3.50L"; W = 4162.0; H = 841.0 },
    @{ Name = "A0_3.75L"; W = 4459.0; H = 841.0 },
    @{ Name = "A0_4L"; W = 4756.0; H = 841.0 }
)

function F([double]$value) {
    return $value.ToString("0.000000", [Globalization.CultureInfo]::InvariantCulture)
}

function Area([double]$w, [double]$h) {
    return F ($w * $h)
}

function PaperName($paper) {
    return "UserDefinedMetric ($((F $paper.W)) x $((F $paper.H)) 毫米)"
}

$pmp = New-Object System.Collections.Generic.List[string]
$pmp.Add("[Meta]")
$pmp.Add("pmpfilepath=")
$pmp.Add("driver_path=")
$pmp.Add("calibration_x=1.000000")
$pmp.Add("calibration_y=1.000000")
$pmp.Add("mod_num=0")
$pmp.Add("del_num=0")
$pmp.Add("userdef_num=$($papers.Count)")
$pmp.Add("hide_num=0")
$pmp.Add("[user]")
for ($i = 0; $i -lt $papers.Count; $i++) {
    $paper = $papers[$i]
    $w = [double]$paper.W
    $h = [double]$paper.H
    $pmp.Add("paper_name$i=$(PaperName $paper)")
    $pmp.Add("paper_local_name$i=LA_$($paper.Name)")
    $pmp.Add("size_x$i=$(F $w)")
    $pmp.Add("size_y$i=$(F $h)")
    $pmp.Add("llx$i=0.000000")
    $pmp.Add("lly$i=0.000000")
    $pmp.Add("urx$i=$(F $w)")
    $pmp.Add("ury$i=$(F $h)")
    $pmp.Add("actual_x$i=$(F $w)")
    $pmp.Add("actual_y$i=$(F $h)")
    $pmp.Add("area$i=$(Area $w $h)")
    $pmp.Add("Unit$i=1")
}

$default = $papers | Where-Object { $_.Name -eq "A2" } | Select-Object -First 1
$pc5 = @"
[Meta]
PrinterType=2
Source=
source_entry=
pmp_filepath={PMP_PATH}
default_source=0
paper_name=$(PaperName $default)
paper_size_x=$(F ([double]$default.W))
paper_size_y=$(F ([double]$default.H))
actual_printable_bounds_llx=0.000000
actual_printable_bounds_lly=0.000000
actual_printable_bounds_urx=$(F ([double]$default.W))
actual_printable_bounds_ury=$(F ([double]$default.H))
physical_offsetx=0.000000
physical_offsety=0.000000
actual_x=$(F ([double]$default.W))
actual_y=$(F ([double]$default.H))
actual_area=$(Area ([double]$default.W) ([double]$default.H))
paper_unit=1
destination_name=
duplexing_mode=0
config_description=
[res_color_mem]
dm_color=32
color_depth=16777216
resolution_x=600
resolution_y=600
color_system=2
color_device=1
ism_max=6
ole_max=6
preference=50
dm_ICMIntent=0
dm_ICMMethod=0
truetype_as_text=1
dm_TTOption=0
lines_overwrite=1
[Standard]
DeviceName=PDF
DevicePath=
DriverVersion=1.0.0.0.0.0 [p001-1]
DriverName=DWG to PDF
DriverPath=ZwPDFDriver.dll
DriverCfgPath=PDF.ini
PortName=FILE:
DeviceComment=
ServerName=
LocationName=LA_pdf
[Port]
plot_to_file=1
config_autospool=0
dmDriverExtra=0
privatedata=
[Retain]
dmorientation=1
dmcopies=1
dccopies=1
dmscale=0
dmprintquality=100
mediatype=0
pre_init=0
post_init=0
termination=
layerinclude=1
autoopenfile=0
createbookmark=0
plotprecise=1
[Caps]
definepapersize_caps=1
"@

$gbk = [System.Text.Encoding]::GetEncoding(936)
[IO.File]::WriteAllText((Join-Path $plotterRoot "LA_pdf.pc5"), $pc5.Replace("`n", "`r`n"), $gbk)
[IO.File]::WriteAllText((Join-Path $pmpDir "LA_pdf.pmp"), (($pmp -join "`r`n") + "`r`n"), $gbk)

Write-Host "Generated $plotterRoot"
