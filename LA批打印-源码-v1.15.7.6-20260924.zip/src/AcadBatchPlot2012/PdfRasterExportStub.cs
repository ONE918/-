using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
#if AUTOCAD
using Autodesk.AutoCAD.ApplicationServices;
#else
using ZwSoft.ZwCAD.ApplicationServices;
#endif

namespace ZwcadBatchPlot;

/**
 * @file PdfRasterExportStub.cs
 * @description AutoCAD 2010-2012 版（net45）的 PNG/JPG 转图替代实现。
 *
 * 原实现（Common\Services\Plotting\PdfRasterExport.cs）先出临时 PDF 再用 Docnet.Core
 * 渲染成位图，而 Docnet.Core 只提供 netstandard2.0，最低要 .NET 4.6.1，这几版 AutoCAD
 * 的宿主环境（CLR 4.0）用不了。因此本构建：
 * - 不编译 PdfRasterExport.cs，改用本文件；
 * - 不向界面提供 PNG/JPG 输出格式（见两处 LoadPlotOptions 里的 #if !ACAD2012）；
 * - PlotMany 原样转发给 PlotterService.PlotMany，只能出 PDF/DWF/DWG。
 *
 * RasterExportSettings 的常量与规范化逻辑与正式实现保持一致，
 * 因为 AppSettingsStore 与 SettingsForm 会直接引用它们（配置文件结构不变）。
 */

/// <summary>PNG/JPG 转图参数。2012 版不提供转图，这里只为保持配置结构兼容。</summary>
public static class RasterExportSettings
{
    /// <summary>PNG/JPG 转图默认分辨率（DPI）。</summary>
    public const int DefaultDpi = 150;

    /// <summary>允许设置的最低 DPI。低于该值时回落到 <see cref="DefaultDpi"/>。</summary>
    public const int MinDpi = 72;

    /// <summary>允许设置的最高 DPI。高于该值时回落到 <see cref="DefaultDpi"/>。</summary>
    public const int MaxDpi = 600;

    /// <summary>JPG 默认质量（1–100）。</summary>
    public const int DefaultJpegQuality = 90;

    /// <summary>允许设置的最低 JPG 质量。</summary>
    public const int MinJpegQuality = 1;

    /// <summary>允许设置的最高 JPG 质量。</summary>
    public const int MaxJpegQuality = 100;

    /// <summary>把配置中的 DPI 规范到合法范围。</summary>
    public static int NormalizeDpi(int dpi)
        => dpi < MinDpi || dpi > MaxDpi ? DefaultDpi : dpi;

    /// <summary>把配置中的 JPG 质量规范到 1–100。</summary>
    public static int NormalizeJpegQuality(int quality)
        => quality < MinJpegQuality || quality > MaxJpegQuality ? DefaultJpegQuality : quality;
}

/// <summary>
/// AutoCAD 2010-2012 版（net45）的打印入口：直接走 <see cref="PlotterService.PlotMany"/>。
/// 与正式版的区别仅在于不处理 PNG/JPG 转图。
/// </summary>
public static class PdfRasterExport
{
    /// <summary>批量出图。2012 版不做 PDF→位图转换，全部交给 <see cref="PlotterService.PlotMany"/>。</summary>
    public static List<PlotterService.PlotJobResult> PlotMany(
        IReadOnlyList<PlotJob> jobs,
        string deviceName,
        string styleSheet,
        Document currentDocument,
        AppSettings settings,
        Action<PlotJob>? beforeJob = null,
        CancellationToken cancellationToken = default)
    {
        var list = jobs ?? new List<PlotJob>();
        foreach (var job in list)
        {
            if (IsRasterOutputPath(job?.OutputPath))
            {
                // 界面已不提供 PNG/JPG（见 LoadPlotOptions 的 #if !ACAD2012），正常走不到这里。
                throw new NotSupportedException(
                    "AutoCAD 2010-2012 版（.NET 4.5）不支持 PNG/JPG 转图输出，请改用 PDF / DWF / DWG。");
            }
        }

        return PlotterService.PlotMany(
            list,
            deviceName,
            styleSheet,
            currentDocument,
            settings,
            beforeJob,
            cancellationToken);
    }

    /// <summary>最终输出路径是否为 PNG/JPG。</summary>
    public static bool IsRasterOutputPath(string? path)
    {
        var extension = Path.GetExtension(path ?? "");
        return extension.Equals(".png", StringComparison.OrdinalIgnoreCase)
               || extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase)
               || extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase);
    }
}
