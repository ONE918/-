using System;
using System.Threading;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Threading;
#if AUTOCAD
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
#if ACAD_CORE
using CadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;
#else
using CadApp = Autodesk.AutoCAD.ApplicationServices.Application;
#endif
#else
using ZwSoft.ZwCAD.ApplicationServices;
using ZwSoft.ZwCAD.DatabaseServices;
using ZwSoft.ZwCAD.EditorInput;
using ZwSoft.ZwCAD.Geometry;
using CadApp = ZwSoft.ZwCAD.ApplicationServices.Application;
#endif

namespace ZwcadBatchPlot;

/// <summary>
/// 通用型批量打印面板（WPF 版，非模态窗口；由 BatchPlotCommands 通过 CadDialog.ShowModeless 显示）。
/// </summary>
public sealed partial class RectangleBatchPlotForm : Window
{
    private sealed class MarginOption
    {
        public double Value { get; set; }
        public override string ToString() => Value > 0
            ? $"+ {Value:0.#} mm"
            : $"- {Math.Abs(Value):0.#} mm";
    }

    private sealed class Row : INotifyPropertyChanged
    {
        private string _fileName = "";
        private string _paperChoice = "";

        public event PropertyChangedEventHandler? PropertyChanged;

        public PlotJob Job { get; set; } = new();
        public IReadOnlyList<PaperDetection> Options { get; set; } = new PaperDetection[0];

        /// <summary>纸张下拉候选（原 DataGridViewComboBoxCell.DataSource 语义）。</summary>
        public IReadOnlyList<string> PaperOptions =>
            Options.Select(PaperSizeDetector.FormatOption).ToList();

        public bool Selected
        {
            get => Job.Selected;
            set
            {
                if (Job.Selected == value) return;
                Job.Selected = value;
                OnPropertyChanged(nameof(Selected));
            }
        }

        public string FileName
        {
            get => _fileName;
            set
            {
                if (string.Equals(_fileName, value, StringComparison.Ordinal)) return;
                _fileName = value;
                OnPropertyChanged(nameof(FileName));
            }
        }

        /// <summary>用户在清单里手动改过文件名后为真；刷新命名时跳过该行走自动命名，保留手动名。</summary>
        public bool ManualFileName { get; set; }

        /// <summary>扫描识别到的图号；无属性识别时为空。</summary>
        public string DrawingNumber => Job.DrawingNumber ?? "";

        /// <summary>扫描识别到的图名；无属性识别时为空或不显示列。</summary>
        public string Title => Job.Title ?? "";

        public string PaperChoice
        {
            get => _paperChoice;
            set
            {
                if (string.Equals(_paperChoice, value, StringComparison.Ordinal)) return;
                _paperChoice = value;
                OnPropertyChanged(nameof(PaperChoice));
            }
        }

        public string Scale { get; private set; } = "";

        /// <summary>编号列显示文本（1 基，随视图顺序刷新）。</summary>
        public string Number { get; private set; } = "";

        public void RefreshFromJob()
        {
            Scale = Job.ScaleText;
            OnPropertyChanged(nameof(Scale));
            OnPropertyChanged(nameof(DrawingNumber));
            OnPropertyChanged(nameof(Title));
        }

        public void SetNumber(int index)
        {
            var text = index.ToString();
            if (string.Equals(Number, text, StringComparison.Ordinal)) return;
            Number = text;
            OnPropertyChanged(nameof(Number));
        }

        private void OnPropertyChanged(string propertyName)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    private readonly Document _document;
    private readonly AppSettings _settings;
    private readonly TemporarySequenceOverlay _overlay;
    private int _highlightedJobIndex = -1;
    private int _overlayScheduleGeneration;
    private readonly BindingList<Row> _rows = new();
    private readonly BindingList<Row> _displayRows = new();
    private CancellationTokenSource? _printCts;
    private List<ObjectId>? _scanSelectionIds;
    private TitleBlockScanScope? _lastScanScope;
    private bool _updating;
    private bool _updatingPrintSelection;
    private bool _viewSortedByHeader;
    private bool _outputDirectoryIsCustom;
    private bool _outputDirectoryModified;
    private bool _suppressTextEvents;
    private bool _suppressComboEvents;
    private bool _suppressPaperEvents;
    private string _sortMemberPath = "";
    private List<Row>? _pendingPrintToggleRows;
    private string _dwfPlotDevice = "";
    private bool _styleSelectionReady;
    /// <summary>本批是否识别到至少一张图号或图名属性；决定是否显示列并走设置文件名规则。</summary>
    private bool _hasAttributeIdentity;
    /// <summary>「文件命名」字段集合，顺序即输出文件名中各段的排列顺序（空表示沿用默认文件名规则）。</summary>
    private readonly List<string> _nameFieldTags = new();
    /// <summary>本次会话拾取到的示例值（字段 → 拾取时的属性值），仅用于列表提示，不持久化。</summary>
    private readonly Dictionary<string, string> _nameFieldSamples = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>字段集合的共享实现（取值 / 命名效果 / 拾取加入）；与图框块面板、设置窗的入口同源。</summary>
    private GenericFileNameFieldSet? _nameFieldSet;

    private GenericFileNameFieldSet NameFields
        => _nameFieldSet ??= new GenericFileNameFieldSet(_settings, _nameFieldTags, _nameFieldSamples);
    /// <summary>「文件命名」对话框（非模态；见 <see cref="OpenFileNameFieldDialog"/>）；关闭后置空。</summary>
    private FileNameFieldForm? _fileNameFieldDialog;
    /// <summary>面板正在关闭：此时不再把焦点抢回面板，避免关闭顺序造成的闪烁。</summary>
    private bool _closingPanel;
    /// <summary>
    /// 最后一次拾取命中的属性位置（世界坐标，NaN = 本次会话还没拾取过）：
    /// 「命名效果」据此每次刷新时重新定位到"我框的那张图"，清单重扫后也能自动跟上。
    /// </summary>
    private double _nameFieldPreviewPickX = double.NaN;
    private double _nameFieldPreviewPickY = double.NaN;
    private List<(PlotJob Job, string DrawingNumber)>? _lastOverlayRebuildKey;
    private bool _overlayPainted;
    /// <summary>多文件批打进列表后禁止 CAD 临时红框/序号，直至再次扫描当前图、框选或清空清单。</summary>
    private bool _suppressSequenceOverlayFromMultiFile;
    /// <summary>程序化重建「打印图幅」下拉时为 true，避免把内部重选当成用户操作触发保存。</summary>
    private bool _updatingPrintPaperOptions;

    public RectangleBatchPlotForm(Document document)
    {
        _document = document;
        _settings = AppSettingsStore.Load();
        _overlay = new TemporarySequenceOverlay(document);
        InitializeComponent();
        InitializeGrid();
        InitMarginCombo(_marginInput, _settings.PaperMarginMm);
        _marginInput.IsEnabled = _leaveMargin.IsChecked == true;
        _leaveMargin.IsChecked = _settings.LeavePaperMargin;
        _mergePdf.IsChecked = _settings.MergePdf;
        // 先恢复上次选择的打印图幅：此后 LoadPlotOptions 重建候选列表时会按名称保留该项，
        // 反过来会把刚恢复的选择重置为默认图幅。
        RefreshPrintPaperOptions(_settings.PrintPaperName);
        LoadPlotOptions();
        LoadNameFields();
        Closing += (_, _) =>
        {
            // 关闭时若仍在打印，先请求取消，避免后台继续跑。
            _printCts?.Cancel();
            // 「文件命名」是非模态子窗，面板关闭时一并关掉，避免留下无主的窗口。
            _closingPanel = true;
            _fileNameFieldDialog?.Close();
        };
    }

    private void InitializeGrid()
    {
        _grid.ItemsSource = _displayRows;
    }

    protected override void OnClosed(EventArgs e)
    {
        _overlayScheduleGeneration++;
        // 关闭窗口时只清理临时红框和序号，不再退订或接管 CAD 删除命令。
        _overlay.Dispose();
        base.OnClosed(e);
    }

    /// <summary>兼容原 WinForms 调用方 form.Dispose() 的清理入口。</summary>
    public void Dispose() => Close();

    // ── 事件处理（XAML 绑定） ──

    private void ScanCurrentDrawing_Click(object sender, RoutedEventArgs e) => ScanCurrentDrawing();

    private void ScanSelectedObjects_Click(object sender, RoutedEventArgs e) => ScanSelectedObjects();

    private void AddDwgFiles_Click(object sender, RoutedEventArgs e) => AddDwgFiles();

    private void AddDwgFolder_Click(object sender, RoutedEventArgs e) => AddDwgFolder();

    private void ReloadFrames_Click(object sender, RoutedEventArgs e) => ReloadFrames();

    private void ClearRows_Click(object sender, RoutedEventArgs e) => ClearRows();

    private void ClearRows()
    {
        _suppressSequenceOverlayFromMultiFile = false;
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        if (_rows.Count == 0 && _displayRows.Count == 0)
        {
            return;
        }

        if (MessageBox.Show("确定清空当前矩形框清单吗？", Title, MessageBoxButton.OKCancel, MessageBoxImage.Question) != MessageBoxResult.OK)
        {
            return;
        }

        ReplaceBindingListContents(_rows, new Row[0]);
        ReplaceBindingListContents(_displayRows, new Row[0]);
        _scanSelectionIds = null;
        _lastScanScope = null;
        _hasAttributeIdentity = false;
        UpdateAttributeIdentityColumns();
        _viewSortedByHeader = false;
        _sortMemberPath = "";
        try
        {
            _overlay.Clear();
        }
        catch
        {
        }
    }

    private void BrowseOutputDirectory_Click(object sender, RoutedEventArgs e) => ChooseOutputDirectory();

    private void OutputDirectory_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suppressTextEvents)
        {
            return;
        }

        // 对应原 TextBox.Modified：用户手动输入时置位。
        _outputDirectoryModified = true;
        RefreshOutputPaths();
    }

    private void OutputDirectory_LostFocus(object sender, RoutedEventArgs e)
        => ApplyManuallyEnteredOutputDirectory();

    private void SavePathMode_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboEvents)
        {
            return;
        }

        ApplySelectedSavePathMode();
    }

    private void OutputFormat_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboEvents)
        {
            return;
        }

        UpdateOutputFormatUi();
    }

    private void Style_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        _styleSettingsButton.IsEnabled = _style.SelectedIndex >= 0 && !IsDwgOutput;
        if (_styleSelectionReady)
        {
            SaveCurrentPlotOptions();
        }
    }

    private void StyleSettings_Click(object sender, RoutedEventArgs e)
        => PlotStyleManager.EditSelectedStyle(this, _style.SelectedItem?.ToString());

    private void LeaveMargin_CheckedChanged(object sender, RoutedEventArgs e)
        => _marginInput.IsEnabled = SupportsLeaveMargin && _leaveMargin.IsChecked == true;

    private void PrintOrStop_Click(object sender, RoutedEventArgs e) => PrintOrStop();

    private void SortSettings_Click(object sender, RoutedEventArgs e) => ShowSortSettings();

    private void ScaleSettings_Click(object sender, RoutedEventArgs e) => ShowSettingsAtTab(3);

    private void GeneralSettings_Click(object sender, RoutedEventArgs e) => ShowSettingsAtTab(0);

    private void JobFilterSettings_Click(object sender, RoutedEventArgs e) => ShowJobFilterDialog();

    /// <summary>
    /// 打开「过滤图纸」对话框（已从「常规设置」独立出来，按钮位于「常规设置」左侧）。
    /// 关闭后只回拷过滤两项设置并刷新清单：只显示匹配的矩形框，打印/拆图也只处理匹配项。
    /// 编号仍按完整清单的位置计算，因此过滤后可见行会跳号。
    /// </summary>
    private void ShowJobFilterDialog()
    {
        // 通用型清单的“文件名”列绑定的是 Row.FileName，故传入取值器让文本列表与打印窗口一致。
        var dialog = new JobFilterForm(
            _rows.Select(row => row.Job).ToList(),
            job => _rows.FirstOrDefault(row => ReferenceEquals(row.Job, job))?.FileName);
        if (ShowChildModalKeepingListVisible(dialog) != true)
        {
            return;
        }

        var updated = AppSettingsStore.Load();
        _settings.FilterKeyword = updated.FilterKeyword;
        _settings.FilterScope = updated.FilterScope;

        if (_viewSortedByHeader && !string.IsNullOrWhiteSpace(_sortMemberPath))
        {
            // 清单正按列头排序：过滤变更后仍按原列排序重建显示行。
            ApplyActiveHeaderSort();
        }
        else
        {
            RefreshDisplayRows();
            UpdateVisuals();
        }

        _status.Text = string.IsNullOrWhiteSpace(_settings.FilterKeyword)
            ? "已清除图纸过滤，恢复显示全部矩形框。"
            : $"已应用图纸过滤：{_settings.FilterKeyword}（只显示并只打印匹配的矩形框）。";
    }

    private void FileNameSettings_Click(object sender, RoutedEventArgs e) => OpenFileNameFieldDialog();

    /// <summary>
    /// 打开「文件命名」对话框（非模态：对话框里的「拾取属性文字」需要隐藏窗口回到图面取点，
    /// 模态窗在 CAD 里取点会受限）。已打开时只把已有窗口拉到前台。
    /// </summary>
    internal void OpenFileNameFieldDialog()
    {
        if (_fileNameFieldDialog is { IsVisible: true } existing)
        {
            existing.Activate();
            return;
        }

        var dialog = new FileNameFieldForm(
            _nameFieldTags,
            _nameFieldSamples,
            BuildNameFieldPreviews,
            PickNameFields,
            NameFieldsChangedFromDialog,
            SetStatusText);
        dialog.Closed += (_, _) =>
        {
            _fileNameFieldDialog = null;
            if (!_closingPanel)
            {
                // 关掉子窗后把面板拉回前台，别让焦点落到别的进程。
                CadWindowFocus.RestoreDialog(this);
            }

            UpdateVisuals();
        };
        _fileNameFieldDialog = dialog;
        CadDialog.ShowModeless(dialog);
    }

    /// <summary>把「文件命名」对话框里的状态文字同步到面板状态栏（关掉子窗后也能看到）。</summary>
    internal void SetStatusText(string text) => _status.Text = text;

    /// <summary>
    /// 在 CAD 里拾取属性文字（供「文件命名」对话框调用）：点中某个属性文字只取该文字；
    /// 拉窗口框选则把范围内所有属性按位置顺序（从上到下、从左到右）加入文件名字段列表，
    /// 可反复拾取逐次追加。拾取必须在 CAD 命令上下文进行，故先隐藏面板（对话框自己也会隐藏），
    /// 结束后恢复。返回状态文字（空串 = 没有拾取到任何东西）。
    /// <para>
    /// <paramref name="rowIndex"/>：&lt;0 = 本次拾取到的属性<b>按所属属性块分行</b>（一个块一行，
    /// 同块的多个属性各占一段、都拼进文件名）；&gt;=0 = 第一个块的属性追加进该行，其余块仍各自新建一行。
    /// </para>
    /// </summary>
    internal string PickNameFields(int rowIndex)
    {
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        int skipped;
        List<PickedAttributeName> picked;
        CadWindowFocus.HideForCadInput(this);
        try
        {
            picked = AttributeNameFieldPicker.Pick(_document, out skipped);
        }
        catch (Exception ex)
        {
            MessageBox.Show("拾取属性文字失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
            return "";
        }
        finally
        {
            CadWindowFocus.RestoreDialog(this);
        }

        // 一个属性块 = 一行：本次拾取到的属性按所属块分组，同块的多个属性放在一行、各占一段都拼进文件名，
        // 不同块各自成行；「拾取到本行」时第一个块写进指定行。
        var added = NameFields.AddPickedByBlock(picked, rowIndex);

        if (picked.Count > 0)
        {
            // 「命名效果」跟着我拾取的那张图：记下最后一次拾取到的属性位置，
            // 刷新时据此在清单里定位到那张图（点/框哪张图就显示哪张图上的文字）。
            var last = picked[picked.Count - 1];
            _nameFieldPreviewPickX = last.PickedX;
            _nameFieldPreviewPickY = last.PickedY;
        }

        if (picked.Count == 0 && skipped == 0)
        {
            // 直接回车/ESC 结束且没有拾取到任何东西：保持原状态提示，不刷掉用户看到的清单信息。
            return "";
        }

        var reusedHint = picked.Count > added ? $"，{picked.Count - added} 个已在列表中" : "";
        var skippedHint = skipped > 0 ? $"，跳过 {skipped} 次空拾取" : "";
        var status = _nameFieldTags.Count == 0
            ? $"文件命名：未拾取到属性字段{skippedHint}"
            : $"文件命名：{FormatNameFieldPreviewSummary()}（本次新增 {added} 个字段{reusedHint}{skippedHint}） | 文件名已按字段刷新";
        _status.Text = status;
        return status;
    }

    /// <summary>
    /// 「文件命名」对话框改了字段后的收尾：持久化 → 重算文件名 → 面板状态。
    /// （对话框是字段列表的唯一入口，字段集合也由它按引用直接改，这里只负责落盘与刷新。）
    /// </summary>
    private void NameFieldsChangedFromDialog()
    {
        _settings.RectangleFileNameFields = _nameFieldTags.ToList();
        SaveCurrentPlotOptions();
        RefreshFileNames();
        UpdateVisuals();
    }

    /// <summary>从设置恢复「文件命名」字段列表（保留本次会话已有字段的示例值）。</summary>
    private void LoadNameFields() => NameFields.Load(_settings.RectangleFileNameFields);

    /// <summary>
    /// 加入一个文件名字段；已存在时只更新示例值并返回 false。
    /// 字段文本为「属性名」或「块名|属性名」（同名属性来自不同属性块时各自成一项）。
    /// </summary>
    private bool AddNameField(PickedAttributeName field) => NameFields.AddPicked(field);

    /// <summary>
    /// 按「文件命名」列表顺序解析各段，命名效果预览与真正的文件名共用这一份，保证"看到什么就打出什么"：
    /// 固定文本项（手动插入的横线等）原样参与文件名、并且充当它与后面一段之间的分隔；
    /// 属性字段依次到该图纸上取值，取不到的段不参与文件名。
    /// 解析规则在 <c>GenericFileNameFieldSet.Build</c> 里（图框块面板、设置窗的命名入口共用同一份）。
    /// </summary>
    private List<NameFieldSegment> BuildNameFieldSegments(PlotJob? job, bool allowSampleFallback)
        => NameFields.Build(job, allowSampleFallback);

    /// <summary>
    /// 交给「文件命名」对话框的当前命名效果：每个字段一段（取值 / 是否取到 / 前面的连接符）。
    /// 与真正的文件名同源（都走 <see cref="BuildNameFieldSegments"/>），保证"对话框里看到什么就打出什么"。
    /// 显示哪张图：优先用**拾取时点/框到的那张图**，还没拾取过时退回清单第一张要打印的图纸。
    /// </summary>
    internal List<NameFieldPreview> BuildNameFieldPreviews() => NameFields.BuildPreviews(FindPreviewJob());

    /// <summary>
    /// 命名效果预览用哪张图纸：优先用拾取时点/框到的那张图（点/框哪张图就显示哪张图上的文字），
    /// 其次清单里第一张要打印的框（没有勾选时取第一行）；
    /// 拾取过但那张图不在清单里则返回 null（直接用拾取到的文字，不退回第一张图的取值）。
    /// </summary>
    private PlotJob? FindPreviewJob()
    {
        if (!double.IsNaN(_nameFieldPreviewPickX))
        {
            var key = MatchNameFieldPreviewKey(_nameFieldPreviewPickX, _nameFieldPreviewPickY);
            if (key.Length > 0)
            {
                foreach (var row in _rows)
                {
                    if (string.Equals(PlotJobIdentityKey(row.Job), key, StringComparison.Ordinal))
                    {
                        return row.Job;
                    }
                }
            }

            return null;
        }

        PlotJob? first = null;
        foreach (var row in _rows)
        {
            first ??= row.Job;
            if (row.Selected)
            {
                return row.Job;
            }
        }

        return first;
    }

    /// <summary>
    /// 拾取到的属性落在哪张图框里：按"属性位置是否落在图框矩形内"匹配，
    /// 同时要求源文件与空间一致，避免多文件批打时命中别的图纸。
    /// 命中的多个框取面积最小的那个（相邻/嵌套框更精确）；都没命中返回空串。
    /// </summary>
    private string MatchNameFieldPreviewKey(double x, double y)
    {
        var file = _document.Database.Filename ?? "";
        var space = GetCurrentLayoutName();
        PlotJob? best = null;
        var bestArea = double.MaxValue;
        foreach (var row in _rows)
        {
            var job = row.Job;
            if (x < job.MinX || x > job.MaxX || y < job.MinY || y > job.MaxY)
            {
                continue;
            }

            if (file.Length > 0 && !string.Equals(job.SourceFile, file, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (space.Length > 0 && !string.Equals(job.SpaceName, space, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var area = Math.Abs(job.MaxX - job.MinX) * Math.Abs(job.MaxY - job.MinY);
            if (area < bestArea)
            {
                bestArea = area;
                best = job;
            }
        }

        return best == null ? "" : PlotJobIdentityKey(best);
    }

    /// <summary>当前布局名（拾取发生在当前空间，用于把拾取到的属性位置对应到清单里的图）。</summary>
    private string GetCurrentLayoutName()
    {
        try
        {
            return LayoutManager.Current.CurrentLayout ?? "";
        }
        catch
        {
            return "";
        }
    }


    /// <summary>命名效果摘要（如 IN-1-01_平面布置_A2），用于状态栏；还没取到值时退回字段名列表。</summary>
    internal string FormatNameFieldPreviewSummary() => NameFields.EffectSummary(FindPreviewJob());

    /// <summary>文件名字段摘要，用于状态栏。</summary>
    private string FormatNameFieldSummary() => NameFields.FieldSummary();

        private void Grid_Sorting(object sender, DataGridSortingEventArgs e)
    {
        // 原列头点击排序（Programmatic SortMode）。模板列在部分宿主下不触发本事件，见 PreviewMouse 兜底。
        e.Handled = true;
        ApplyHeaderSort(e.Column);
    }

    /// <summary>文件名列双击改名的提交：标记 ManualFileName，刷新命名时不再覆盖；随后按新名更新输出路径。</summary>
    private void Grid_CellEditEnding(object? sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.Row?.Item is not Row row)
        {
            return;
        }

        if (e.Column is DataGridTextColumn { } col && col == _fileNameColumn)
        {
            row.ManualFileName = true;
            RefreshOutputPaths();
            UpdateVisuals();
        }
    }

    /// <summary>双击文件名单元格进入编辑（与图框块面板一致的双击重命名手感）。</summary>
    private void Grid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        var cell = FindAncestor<DataGridCell>(e.OriginalSource as DependencyObject);
        if (cell?.Column is DataGridTextColumn { } col && col == _fileNameColumn && cell.DataContext is Row)
        {
            _grid.CurrentCell = new DataGridCellInfo(cell.DataContext, col);
            _grid.BeginEdit();
            e.Handled = true;
        }
    }

    /// <summary>
    /// 模板列表头点击兜底：WPF DataGridTemplateColumn 有时不触发 Sorting，点「纸张尺寸 / 比例」会无反应。
    /// </summary>
    private bool TryHandleColumnHeaderSortClick(DependencyObject? source)
    {
        var header = FindAncestor<DataGridColumnHeader>(source);
        if (header?.Column == null)
        {
            return false;
        }

        ApplyHeaderSort(header.Column);
        return true;
    }

    private void ApplyHeaderSort(DataGridColumn column)
    {
        var columnIndex = _grid.Columns.IndexOf(column);
        if (columnIndex < 0 || columnIndex >= _grid.Columns.Count)
        {
            return;
        }

        var memberPath = column.SortMemberPath ?? "";
        if (_viewSortedByHeader && _sortMemberPath == memberPath)
        {
            _viewSortedByHeader = false;
            _sortMemberPath = "";
            RefreshDisplayRows();
            UpdateVisuals();
            return;
        }

        _viewSortedByHeader = true;
        _sortMemberPath = memberPath;
        ApplyActiveHeaderSort();
    }

    /// <summary>
    /// 按当前列头排序（_sortMemberPath）叠加图纸过滤重建显示行；
    /// 供列头点击排序与「过滤图纸」对话框关闭后（排序仍在时）共用。
    /// </summary>
    private void ApplyActiveHeaderSort()
    {
        var sorted = _rows
            .Where(row => JobFilter.IsMatch(_settings, row.Job, row.FileName))
            .OrderBy(row => GetHeaderSortValue(row, _sortMemberPath), NaturalStringComparer.Instance)
            .ToList();
        var wasUpdating = _updating;
        _updating = true;
        try
        {
            ReplaceBindingListContents(_displayRows, sorted);
        }
        finally
        {
            _updating = wasUpdating;
        }

        UpdateDisplayIndexes();
        UpdateVisuals();
    }

    private static T? FindAncestor<T>(DependencyObject? source)
        where T : DependencyObject
    {
        var current = source;
        while (current != null)
        {
            if (current is T match)
            {
                return match;
            }

            current = current is System.Windows.Media.Visual || current is System.Windows.Media.Media3D.Visual3D
                ? System.Windows.Media.VisualTreeHelper.GetParent(current)
                : LogicalTreeHelper.GetParent(current);
        }

        return null;
    }

    private string GetHeaderSortValue(Row row, string memberPath)
    {
        switch (memberPath)
        {
            case nameof(Row.Selected):
                return row.Selected ? "1" : "0";
            case nameof(Row.FileName):
                return row.FileName;
            case nameof(Row.DrawingNumber):
                return row.DrawingNumber;
            case nameof(Row.Title):
                return row.Title;
            case nameof(Row.PaperChoice):
                return row.PaperChoice;
            case nameof(Row.Scale):
                return row.Scale;
        }

        // 编号列按真实打印顺序排序；预览按钮列保持原始顺序。
        return _rows.IndexOf(row).ToString("D8");
    }

    private void Grid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (TryHandleColumnHeaderSortClick(e.OriginalSource as DependencyObject))
        {
            e.Handled = true;
            return;
        }

        var row = HitTestRow(e.OriginalSource as DependencyObject)?.Item as Row;
        if (row == null)
        {
            return;
        }

        if (e.OriginalSource is System.Windows.Controls.CheckBox
            && _grid.SelectedItems.Count > 1)
        {
            // 先记住点击前的多选行；点击复选框时可能会先改当前选择，后续统一同步这些行。
            var highlightedRows = HighlightedRows();
            _pendingPrintToggleRows = highlightedRows.Contains(row) ? highlightedRows : null;
        }

        // 原 CellClick：点击行时在 CAD 中高亮对应矩形框。
        _highlightedJobIndex = _rows.IndexOf(row);
        _overlay.SetHighlight(row.Job);
    }

    private void Grid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
        var container = HitTestRow(e.OriginalSource as DependencyObject);
        if (container?.Item is not Row row)
        {
            return;
        }

        if (!_grid.SelectedItems.Contains(row))
        {
            if (_grid.SelectedItems.Count <= 1)
            {
                _grid.UnselectAll();
            }
            // 已经 Shift/Ctrl 多选后，即使鼠标移到其它行右键，也保留原多选集合用于批量操作。
            container.IsSelected = true;
        }

        if (_grid.SelectedItems.Contains(row))
        {
            _grid.CurrentItem = row;
        }
    }

    private static DataGridRow? HitTestRow(DependencyObject? source)
    {
        while (source != null && source is not DataGridRow)
        {
            source = System.Windows.Media.VisualTreeHelper.GetParent(source);
        }
        return source as DataGridRow;
    }

    private void Grid_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
        // 候选完全一致，或均可按同一套长宽比图幅名解释时，允许批量改纸。
        _changePaperItem.IsEnabled = CanBatchChangePaper(HighlightedRows());
    }

    private void PrintCheck_Click(object sender, RoutedEventArgs e)
    {
        if (_updating || _updatingPrintSelection)
        {
            return;
        }

        if (((System.Windows.Controls.CheckBox)sender).DataContext is not Row row)
        {
            return;
        }

        // 对应原 GridCellValueChanged 的 Selected 分支：取消勾选仅置 Selected=false，保留行（不再移除）。
        ApplyPrintSelectionToHighlightedRows(row);
        RefreshFileNames();
        RefreshOutputPaths();
        UpdateVisuals();
    }

    private void PaperChoice_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_updating || _updatingPrintSelection || _suppressPaperEvents)
        {
            return;
        }

        if (((ComboBox)sender).DataContext is not Row row)
        {
            return;
        }

        // 对应原 GridCellValueChanged 的 PaperChoice 分支。
        var value = row.PaperChoice;
        var option = row.Options.FirstOrDefault(candidate => string.Equals(PaperSizeDetector.FormatOption(candidate), value, StringComparison.Ordinal));
        if (option != null)
        {
            ApplyPaper(row.Job, option);
            row.RefreshFromJob();
            RefreshFileNames();
            RefreshOutputPaths();
            UpdateVisuals();
        }
    }

    private void PreviewButton_Click(object sender, RoutedEventArgs e)
    {
        if (((Button)sender).DataContext is not Row row)
        {
            return;
        }

        if (IsDwgOutput)
        {
            MessageBox.Show("DWG 输出为拆图操作，不提供打印预览。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        // 预览与正式输出使用同一绘图器，避免不同格式之间出现纸张或旋转差异。
        var device = SelectedDevice();
        if (string.IsNullOrWhiteSpace(device))
        {
            MessageBox.Show($"未找到可用的 {SelectedOutputFormat} 输出设备。", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // 红框/序号在不打印层，预览不必取消表格选中或改 CAD 高亮。
        // 非模态按钮处于应用上下文；PlotEngine 交互预览必须进命令上下文，否则会「假启动」。
        // 统一图幅为本次预览设置，预览结束（或失败）后立即还原识别结果。
        var paperBackups = new Dictionary<PlotJob, PrintPaperBackup>();
        CadWindowFocus.HideForCadInput(this);
        try
        {
            SaveCurrentPlotOptions();
            row.Job.LeavePaperMargin = SupportsLeaveMargin && _leaveMargin.IsChecked == true;
            row.Job.PaperMarginMm = ReadMarginValue(_marginInput);
            // 预览当前行时同时准备已勾选图纸的全部任意尺寸；当前行未勾选也不能漏掉。
            var previewJobs = _rows
                .Where(candidate => candidate.Selected || ReferenceEquals(candidate, row))
                .Select(candidate => candidate.Job)
                .ToList();
            // 统一图幅与留白都必须在纸张注册前写入，保证预览效果与打印一致。
            ApplyPrintPaperOverrides(previewJobs, paperBackups);
            // 同步留白设置到所有准备作业，保证扩大/缩比例模式即时生效。
            ApplyLeaveMarginSelection(previewJobs);
            CustomPaperBatchPreparer.Prepare(previewJobs, device);

            PendingPlotPreview.Start(new PendingPlotPreview.Request
            {
                Job = row.Job,
                DeviceName = device,
                StyleSheet = PlotStyleManager.ResolveJobStyle(row.Job, SelectedStyle()),
                Document = _document,
                OnFinally = () =>
                {
                    RestorePrintPapers(paperBackups);
                    CadWindowFocus.RestoreDialog(this);
                },
                OnError = ex => MessageBox.Show(
                    "打印预览失败: " + ex.Message,
                    Title,
                    MessageBoxButton.OK,
                    MessageBoxImage.Error)
            }, Dispatcher);
        }
        catch (Exception ex)
        {
            PendingPlotPreview.Take();
            RestorePrintPapers(paperBackups);
            MessageBox.Show("打印预览失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
            CadWindowFocus.RestoreDialog(this);
        }
    }

    private void BatchChangePaper_Click(object sender, RoutedEventArgs e) => BatchChangeHighlightedPaper();

    private void MarkNotPrint_Click(object sender, RoutedEventArgs e) => MarkHighlightedNotPrint();

    private void DeleteHighlighted_Click(object sender, RoutedEventArgs e) => DeleteHighlighted();

    // ── 数据加载 ──

    private void LoadRows(IReadOnlyList<RectangleFrameScanner.Result> results, bool append = false)
    {
        var rows = new List<Row>(results.Count);
        foreach (var result in results)
        {
            var option = result.PaperOptions[0];
            rows.Add(new Row
            {
                Job = result.Job,
                Options = result.PaperOptions,
                PaperChoice = PaperSizeDetector.FormatOption(option)
            });
        }

        if (append)
        {
            var existingKeys = new HashSet<string>(_rows.Select(row => PlotJobIdentityKey(row.Job)), StringComparer.OrdinalIgnoreCase);
            var merged = _rows.ToList();
            foreach (var row in rows)
            {
                if (existingKeys.Add(PlotJobIdentityKey(row.Job)))
                {
                    merged.Add(row);
                }
            }

            rows = merged;
        }

        _hasAttributeIdentity = rows.Any(row =>
            !string.IsNullOrWhiteSpace(row.Job.CadDrawingNumber)
            || !string.IsNullOrWhiteSpace(row.Job.CadTitle));
        if (_hasAttributeIdentity)
        {
            // 进入属性命名模式后，图号/图名只保留识别结果，避免文件名规则混入 DWG 名或序号。
            foreach (var row in rows)
            {
                row.Job.DrawingNumber = row.Job.CadDrawingNumber ?? "";
                row.Job.Title = row.Job.CadTitle ?? "";
            }
        }

        UpdateAttributeIdentityColumns();
        ReplaceBindingListContents(_rows, rows);
        _viewSortedByHeader = false;
        _sortMemberPath = "";
        SortRows();
    }

    private static string PlotJobIdentityKey(PlotJob job)
    {
        if (!string.IsNullOrWhiteSpace(job.BlockHandle))
        {
            return $"H|{job.SourceFile}|{job.SpaceName}|{job.BlockHandle}";
        }

        return $"G|{job.SourceFile}|{job.SpaceName}|{job.MinX:0.###}|{job.MinY:0.###}|{job.MaxX:0.###}|{job.MaxY:0.###}";
    }

    /// <summary>有识别结果时显示图号/图名列，否则保持原有列布局。</summary>
    private void UpdateAttributeIdentityColumns()
    {
        var visibility = _hasAttributeIdentity
            ? System.Windows.Visibility.Visible
            : System.Windows.Visibility.Collapsed;
        _drawingNumberColumn.Visibility = visibility;
        _titleColumn.Visibility = visibility;
    }

    private void RefreshFileNames()
    {
        // 「文件命名」对话框里的效果显示与文件名同源：重算文件名时顺手让对话框也刷新一遍。
        _fileNameFieldDialog?.RefreshPreview();

        // 「文件命名」设置了字段时以字段为准（通用型的自定义命名），其次才走属性识别规则。
        if (_nameFieldTags.Count > 0)
        {
            RefreshPickedFieldFileNames();
            return;
        }

        if (_hasAttributeIdentity)
        {
            RefreshAttributeIdentityFileNames();
            return;
        }

        var fallbackStem = GetDocumentFileStem();
        var digits = Math.Max(1, Math.Min(10, _settings.FileNameSequenceDigits));
        var printIndex = 0;
        for (var i = 0; i < _rows.Count; i++)
        {
            if (!_rows[i].Selected)
            {
                continue;
            }

            if (_rows[i].ManualFileName)
            {
                // 保留手动文件名：仅刷新 CAD 反写字段，不重算 FileName / 序号。
                _rows[i].RefreshFromJob();
                continue;
            }

            printIndex++;
            var stem = GetJobFileStem(_rows[i].Job, fallbackStem);
            _rows[i].Job.DrawingNumber = printIndex.ToString($"D{digits}");
            _rows[i].FileName = $"{stem}{printIndex.ToString($"D{digits}")}{SelectedOutputExtension}";
            _rows[i].RefreshFromJob();
        }

        RefreshOutputPaths();
    }

    /// <summary>
    /// 本批有属性识别时：有图号/图名的行走设置文件名规则；
    /// 无属性的行仍按原规则 {DWG名}{序号}，避免出现「_.pdf」这类空占位结果。
    /// </summary>
    private void RefreshAttributeIdentityFileNames()
    {
        var stem = GetDocumentFileStem();
        var legacyDigits = Math.Max(1, Math.Min(10, _settings.FileNameSequenceDigits));
        var selectedCount = _rows.Count(row => row.Selected);
        var patternDigits = FileNameSanitizer.ResolveSequenceDigits(
            _settings.AutoFileNameSequenceDigits,
            _settings.FileNameSequenceDigits,
            _settings.FileNameSequenceStartNumber,
            selectedCount);
        var reservedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var directory = _outputDirectory.Text.Trim();
        var selectedIndex = 0;
        var printIndex = 0;
        foreach (var row in _rows)
        {
            if (!row.Selected)
            {
                continue;
            }

            if (row.ManualFileName)
            {
                row.RefreshFromJob();
                continue;
            }

            var sequenceNumber = _settings.FileNameSequenceStartNumber + selectedIndex;
            selectedIndex++;
            printIndex++;

            string baseName;
            if (RowHasAttributeIdentity(row))
            {
                baseName = FileNameSanitizer.FormatFileNamePattern(
                    _settings.PdfFileNamePattern,
                    row.Job,
                    sequenceNumber,
                    patternDigits,
                    _settings.LongPaperNameFormat,
                    _settings.LongPaperSnapToleranceMm);
            }
            else
            {
                // 该框未识别到图号/图名：与整批无属性时一致，用 DWG 名 + 勾选序号。
                var jobStem = GetJobFileStem(row.Job, stem);
                baseName = $"{jobStem}{printIndex.ToString($"D{legacyDigits}")}";
            }

            var fullPath = FileNameSanitizer.MakeUnique(
                string.IsNullOrWhiteSpace(directory) ? "." : directory,
                baseName,
                reservedPaths,
                _settings.AddSequenceWhenPdfExists,
                SelectedOutputExtension,
                createDirectory: false);
            reservedPaths.Add(fullPath);
            row.FileName = Path.GetFileName(fullPath);
            row.RefreshFromJob();
        }

        RefreshOutputPaths();
    }

    /// <summary>
    /// 「文件命名」设置了字段时的命名：文件名 = 各段按列表顺序用连接符拼接
    /// （字段取该图纸上的属性值，手动插入的固定文本如横线原样写上并充当分隔）。
    /// 某个框缺失全部字段值时，退回「DWG 名 + 勾选序号」，避免出现空名字或只剩分隔符。
    /// </summary>
    private void RefreshPickedFieldFileNames()
    {
        var stem = GetDocumentFileStem();
        var legacyDigits = Math.Max(1, Math.Min(10, _settings.FileNameSequenceDigits));
        var reservedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var directory = _outputDirectory.Text.Trim();
        var printIndex = 0;
        foreach (var row in _rows)
        {
            if (!row.Selected)
            {
                continue;
            }

            if (row.ManualFileName)
            {
                row.RefreshFromJob();
                continue;
            }

            printIndex++;
            var baseName = BuildPickedFieldBaseName(row.Job);
            if (string.IsNullOrWhiteSpace(baseName))
            {
                var jobStem = GetJobFileStem(row.Job, stem);
                baseName = $"{jobStem}{printIndex.ToString($"D{legacyDigits}")}";
            }

            var fullPath = FileNameSanitizer.MakeUnique(
                string.IsNullOrWhiteSpace(directory) ? "." : directory,
                baseName,
                reservedPaths,
                _settings.AddSequenceWhenPdfExists,
                SelectedOutputExtension,
                createDirectory: false);
            reservedPaths.Add(fullPath);
            row.FileName = Path.GetFileName(fullPath);
            row.RefreshFromJob();
        }

        RefreshOutputPaths();
    }

    /// <summary>
    /// 按「文件命名」列表顺序拼接该框的各段文字；无任何非空段时返回空串由调用方兜底。
    /// 字段为「块名|属性名」时只取该属性块里的属性值，为纯属性名时取任意块的最近命中；
    /// 手动插入的固定文本（横线等）原样拼上，并充当它后面一段的分隔。
    /// </summary>
    private string BuildPickedFieldBaseName(PlotJob job)
    {
        if (_nameFieldTags.Count == 0)
        {
            return "";
        }

        var builder = new StringBuilder();
        foreach (var segment in BuildNameFieldSegments(job, allowSampleFallback: false))
        {
            if (!segment.HasValue)
            {
                continue;
            }

            builder.Append(segment.LeadingSeparator).Append(segment.Value);
        }

        return builder.ToString();
    }

    /// <summary>当前文档用于默认文件名的主文件名（无扩展名）。</summary>
    private string GetDocumentFileStem()
    {
        var stem = Path.GetFileNameWithoutExtension(_document.Database.Filename);
        if (string.IsNullOrWhiteSpace(stem))
        {
            stem = Path.GetFileNameWithoutExtension(_document.Name);
        }

        return stem ?? "";
    }

    /// <summary>多文件批打时优先用任务 SourceFile 作为文件名主干。</summary>
    private static string GetJobFileStem(PlotJob job, string fallbackStem)
    {
        if (!string.IsNullOrWhiteSpace(job.SourceFile))
        {
            var stem = Path.GetFileNameWithoutExtension(job.SourceFile);
            if (!string.IsNullOrWhiteSpace(stem))
            {
                return stem;
            }
        }

        return fallbackStem ?? "";
    }

    /// <summary>该行是否识别到非空图号或图名属性。</summary>
    private static bool RowHasAttributeIdentity(Row row)
        => !string.IsNullOrWhiteSpace(row.Job.CadDrawingNumber)
           || !string.IsNullOrWhiteSpace(row.Job.CadTitle);

    private void ReloadFrames()
    {
        _suppressSequenceOverlayFromMultiFile = false;
        try
        {
            List<RectangleFrameScanner.Result> results;
            if (_lastScanScope.HasValue)
            {
                results = ScanScopeWithProgress(_lastScanScope.Value);
            }
            else if (_scanSelectionIds != null)
            {
                results = ScanSelectionWithProgress(_scanSelectionIds);
            }
            else
            {
                return;
            }

            if (results.Count == 0)
            {
                // 设置关闭四线矩形识别后，旧列表中仅由四线组成的图框不能继续残留。
                LoadRows(results);
                MessageBox.Show("重新识别后没有找到矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            TransformResultsToDcs(results);
            LoadRows(results);
        }
        catch (OperationCanceledException)
        {
            MessageBox.Show("已取消识别。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("重新识别矩形框失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private TitleBlockScanScope? PromptScanScope() => BatchPlotCommands.PromptScanScope(this);

    /// <summary>
    /// 扫描失败时把完整异常给用户看（弹窗 + 剪贴板 + 日志），避免只剩 eNotApplicable 无法反馈。
    /// </summary>
    private void ShowScanFailure(string action, Exception ex)
    {
        var detail = ex.ToString();
        try
        {
            _document.Editor.WriteMessage("\n" + action + "\n" + detail + "\n");
        }
        catch
        {
        }

        var logPath = "";
        try
        {
            Directory.CreateDirectory(BatchPlotLogger.LogDirectory);
            logPath = Path.Combine(
                BatchPlotLogger.LogDirectory,
                "ScanError_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".log");
            File.WriteAllText(logPath, action + Environment.NewLine + detail, Encoding.UTF8);
        }
        catch
        {
            logPath = "";
        }

        try
        {
            System.Windows.Clipboard.SetText(detail);
        }
        catch
        {
        }

        var body = action + "\n\n" + detail;
        body += string.IsNullOrWhiteSpace(logPath)
            ? "\n\n完整内容已尝试复制到剪贴板。"
            : "\n\n完整内容已复制到剪贴板，并写入日志:\n" + logPath;

        const int maxChars = 6000;
        if (body.Length > maxChars)
        {
            body = body.Substring(0, maxChars) + "\n…(已截断，完整内容见剪贴板/日志)";
        }

        MessageBox.Show(body, Title, MessageBoxButton.OK, MessageBoxImage.Error);
    }

    private void AddDwgFiles()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "DWG 文件 (*.dwg)|*.dwg",
            Multiselect = true,
            Title = "选择要批量打印的 DWG"
        };

        if (dialog.ShowDialog() != true)
        {
            return;
        }

        var files = dialog.FileNames
            .Select(Path.GetFullPath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        AddDwgFilesCore(files);
    }

    private void AddDwgFolder()
    {
        // WPF 没有等价的目录选择对话框，保留 WinForms FolderBrowserDialog。
        using var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = "选择文件夹，自动识别其中及所有子文件夹里的 DWG 文件。",
            ShowNewFolderButton = false
        };
        if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
        {
            return;
        }

        var root = dialog.SelectedPath;
        List<string> files;
        try
        {
            files = Directory.EnumerateFiles(root, "*.dwg", SearchOption.AllDirectories)
                .Select(Path.GetFullPath)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(f => f, NaturalStringComparer.Instance)
                .ToList();
        }
        catch (Exception ex)
        {
            MessageBox.Show("枚举文件夹失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (files.Count == 0)
        {
            MessageBox.Show(
                "该文件夹及子文件夹中未找到 DWG 文件。",
                Title,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        AddDwgFilesCore(files);
    }

    /// <summary>多文件批打核心流程：枚举空间 → 勾选 → 扫描入表。files 由调用方收集（多选文件或文件夹递归）。</summary>
    private void AddDwgFilesCore(List<string> files)
    {
        if (files.Count == 0)
        {
            return;
        }

        var catalogErrors = new List<string>();
        var spaces = DwgSpaceCatalog.ListSpaces(files, catalogErrors);
        if (catalogErrors.Count > 0)
        {
            // 通用型无统一日志窗，失败详情放提示框。
        }

        if (spaces.Count == 0)
        {
            MessageBox.Show(
                catalogErrors.Count > 0
                    ? "未能枚举到可扫描的模型/布局。\n" + string.Join("\n", catalogErrors)
                    : "所选 DWG 中没有可扫描的模型或布局。",
                Title,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        var defaultStyle = SelectedStyle();
        var picker = new ScanSpacePickerDialog(
            spaces,
            defaultStyle,
            PlotStyleManager.GetAvailableCtbStyles());
        if (CadDialog.ShowModal(picker, this) != true)
        {
            return;
        }

        var selected = picker.SelectedSpaces;
        if (selected.Count == 0)
        {
            return;
        }

        // 确认后先清空清单，再只扫勾选空间。
        ReplaceBindingListContents(_rows, new Row[0]);
        ReplaceBindingListContents(_displayRows, new Row[0]);
        ClearSequenceOverlay();
        _lastScanScope = null;
        _scanSelectionIds = null;
        _hasAttributeIdentity = false;
        UpdateAttributeIdentityColumns();

        var allResults = new List<RectangleFrameScanner.Result>();
        var errors = new List<string>();
        string currentPath;
        try
        {
            currentPath = string.IsNullOrWhiteSpace(_document.Database.Filename)
                ? ""
                : Path.GetFullPath(_document.Database.Filename);
        }
        catch
        {
            currentPath = _document.Database.Filename ?? "";
        }

        foreach (var fileGroup in selected.GroupBy(s => s.FilePath, StringComparer.OrdinalIgnoreCase))
        {
            var file = fileGroup.Key;
            var allowed = new HashSet<string>(
                fileGroup.Select(s => s.LayoutName),
                StringComparer.OrdinalIgnoreCase);
            try
            {
                var isCurrent = !string.IsNullOrWhiteSpace(currentPath)
                    && string.Equals(Path.GetFullPath(file), currentPath, StringComparison.OrdinalIgnoreCase);
                List<RectangleFrameScanner.Result> results;
                if (isCurrent)
                {
                    results = RectangleFrameScanner.ScanScope(
                        _document,
                        TitleBlockScanScope.AllSpaces,
                        _settings.PaperMatchToleranceMm,
                        _settings.RecognizeFourLineRectangleFrames,
                        progress: null,
                        cancellationToken: default,
                        allowedLayoutNames: allowed);
                    TransformResultsToDcs(results);
                }
                else
                {
                    using var db = new Database(false, true);
                    db.ReadDwgFile(file, FileOpenMode.OpenForReadAndAllShare, true, "");
                    db.CloseInput(true);
                    results = RectangleFrameScanner.ScanDatabase(
                        db,
                        file,
                        TitleBlockScanScope.AllSpaces,
                        allowed,
                        _settings.PaperMatchToleranceMm,
                        _settings.RecognizeFourLineRectangleFrames);
                }

                var fileStyle = fileGroup.FirstOrDefault()?.StyleSheet ?? "";
                foreach (var result in results)
                {
                    result.Job.StyleSheet = fileStyle;
                }

                allResults.AddRange(results);
            }
            catch (Exception ex)
            {
                errors.Add($"{file}: {ex.Message}");
            }
        }

        if (allResults.Count == 0)
        {
            LoadRows(allResults);
            _suppressSequenceOverlayFromMultiFile = true;
            ClearSequenceOverlay();
            MessageBox.Show(
                errors.Count > 0
                    ? "扫描完成但未识别到矩形框。\n" + string.Join("\n", errors)
                    : "勾选空间内没有识别到符合常见纸张比例的矩形框。",
                Title,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        LoadRows(allResults);
        // 多文件批打识别结果一律不画临时红框和数字（即使勾选的是当前图）。
        _suppressSequenceOverlayFromMultiFile = true;
        ClearSequenceOverlay();

        if (errors.Count > 0)
        {
            MessageBox.Show(
                "部分 DWG 扫描失败:\n" + string.Join("\n", errors),
                Title,
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    private bool IsCurrentDocumentSource(string sourceFile)
    {
        if (string.IsNullOrWhiteSpace(sourceFile))
        {
            return false;
        }

        try
        {
            var current = _document.Database.Filename;
            if (string.IsNullOrWhiteSpace(current))
            {
                return string.Equals(sourceFile, _document.Name, StringComparison.OrdinalIgnoreCase);
            }

            return string.Equals(Path.GetFullPath(sourceFile), Path.GetFullPath(current), StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return string.Equals(sourceFile, _document.Name, StringComparison.OrdinalIgnoreCase);
        }
    }

    private void ClearSequenceOverlay()
    {
        _overlayScheduleGeneration++;
        _overlay.Clear(repaint: false);
        _overlayPainted = false;
        _lastOverlayRebuildKey = null;
    }

    /// <summary>
    /// 扫描当前图：弹出范围对话框后按所选空间识别矩形图框。
    /// </summary>
    private void ScanCurrentDrawing()
    {
        _suppressSequenceOverlayFromMultiFile = false;
        var scope = PromptScanScope();
        if (scope == null)
        {
            return;
        }

        try
        {
            var results = ScanScopeWithProgress(scope.Value);
            if (results.Count == 0)
            {
                MessageBox.Show("扫描范围内没有识别到符合常见纸张比例的矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            TransformResultsToDcs(results);
            _lastScanScope = scope;
            _scanSelectionIds = null;
            LoadRows(results);
        }
        catch (OperationCanceledException)
        {
            MessageBox.Show("已取消识别。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("扫描当前图失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /// <summary>
    /// 框选扫描：先按类型过滤选择对象，再识别选中矩形图框。
    /// 未拾取时右键弹出扫描范围菜单；框选与右键范围结果累加到现有清单（按几何/句柄去重）；取消选择时保持现有清单不变。
    /// </summary>
    private void ScanSelectedObjects()
    {
        _suppressSequenceOverlayFromMultiFile = false;
        CadWindowFocus.HideForCadInput(this);
        try
        {
            var prompt = ObjectSelectionPrompt.Prompt(
                _document.Editor,
                "\n选择要批量打印的矩形图框对象(右键选择扫描范围): ",
                ObjectSelectionPrompt.RectangleFrameFilter(_settings.RecognizeFourLineRectangleFrames));
            if (prompt.Cancelled)
            {
                return;
            }

            List<RectangleFrameScanner.Result> results;
            if (prompt.Scope is { } scope)
            {
                results = ScanScopeWithProgress(scope);
                if (results.Count == 0)
                {
                    MessageBox.Show("扫描范围内没有识别到符合常见纸张比例的矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                TransformResultsToDcs(results);
                _lastScanScope = null;
                _scanSelectionIds = null;
                LoadRows(results, append: true);
                return;
            }

            if (prompt.SelectedIds is not { Length: > 0 } selectedIds)
            {
                return;
            }

            results = ScanSelectionWithProgress(selectedIds);
            if (results.Count == 0)
            {
                MessageBox.Show("选中对象内没有识别到符合常见纸张比例的矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            TransformResultsToDcs(results);
            if (_scanSelectionIds == null)
            {
                _scanSelectionIds = selectedIds.ToList();
            }
            else
            {
                var known = new HashSet<ObjectId>(_scanSelectionIds);
                foreach (var id in selectedIds)
                {
                    if (known.Add(id))
                    {
                        _scanSelectionIds.Add(id);
                    }
                }
            }

            _lastScanScope = null;
            LoadRows(results, append: true);
        }
        catch (OperationCanceledException)
        {
            MessageBox.Show("已取消识别。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("框选扫描失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            CadWindowFocus.RestoreDialog(this);
        }
    }

    /// <summary>带进度窗执行范围扫描；用户取消时抛出 <see cref="OperationCanceledException"/>。</summary>
    private List<RectangleFrameScanner.Result> ScanScopeWithProgress(TitleBlockScanScope scope)
    {
        using var session = RectangleScanProgressSession.Start(this);
        return RectangleFrameScanner.ScanScope(
            _document,
            scope,
            _settings.PaperMatchToleranceMm,
            _settings.RecognizeFourLineRectangleFrames,
            session.Progress,
            session.Token);
    }

    /// <summary>带进度窗执行对象选择扫描。</summary>
    private List<RectangleFrameScanner.Result> ScanSelectionWithProgress(IEnumerable<ObjectId> selectedIds)
    {
        using var session = RectangleScanProgressSession.Start(this);
        return RectangleFrameScanner.ScanSelection(
            _document,
            selectedIds,
            _settings.PaperMatchToleranceMm,
            _settings.RecognizeFourLineRectangleFrames,
            session.Progress,
            session.Token);
    }

    private void TransformResultsToDcs(List<RectangleFrameScanner.Result> results)
    {
        try
        {
            var wcsToDcs = BatchPlotCommands.BuildWcsToDcsMatrix(_document.Editor);
            foreach (var result in results)
            {
                var job = result.Job;
                if (job.UsesUserCoordinateSystem)
                {
                    // UCS 模型任务必须等打印阶段对齐视图后再生成 DCS 窗口。
                    job.IsDcsWindow = false;
                    continue;
                }

                // 图纸空间打印窗口就是纸面坐标；禁止用模型空间当前视图矩阵污染布局图框。
                if (job.IsPaperSpace)
                {
                    if (result.CornerPoints != null)
                    {
                        job.CornerPoints = (double[])result.CornerPoints.Clone();
                    }

                    job.IsDcsWindow = true;
                    continue;
                }

                if (result.CornerPoints != null)
                {
                    // PlotJob 是打印与 DWG 拆图的共同载体。Min/Max 转为 DCS 前，必须保留 WCS 四角点。
                    job.CornerPoints = (double[])result.CornerPoints.Clone();
                    var corners = new[]
                    {
                        new Point3d(result.CornerPoints[0], result.CornerPoints[1], 0).TransformBy(wcsToDcs),
                        new Point3d(result.CornerPoints[2], result.CornerPoints[3], 0).TransformBy(wcsToDcs),
                        new Point3d(result.CornerPoints[4], result.CornerPoints[5], 0).TransformBy(wcsToDcs),
                        new Point3d(result.CornerPoints[6], result.CornerPoints[7], 0).TransformBy(wcsToDcs)
                    };
                    job.MinX = corners.Min(p => p.X);
                    job.MinY = corners.Min(p => p.Y);
                    job.MaxX = corners.Max(p => p.X);
                    job.MaxY = corners.Max(p => p.Y);
                }
                else
                {
                    BatchPlotCommands.TransformPlotWindow(job, wcsToDcs);
                }

                job.IsDcsWindow = true;
            }
        }
        catch (Exception ex)
        {
            _document.Editor.WriteMessage($"\n矩形框 WCS→DCS 变换失败，使用 WCS 坐标：{ex.Message}");
        }
    }

    private void SortRows()
    {
        if (_rows.Count == 0)
        {
            RefreshDisplayRows();
            UpdateVisuals();
            return;
        }

        _viewSortedByHeader = false;
        _sortMemberPath = "";

        var allRows = _rows.ToList();
        var sortedRows = SortRectangleRows(allRows);

        ReplaceBindingListContents(_rows, sortedRows);
        RefreshDisplayRows();
        RefreshFileNames();
        UpdateVisuals();
    }

    /// <summary>
    /// 通用型排序：多文件时先按文件名；同一文件内有识别图号则按图号，否则与单文件批打相同（布局 + 空间位置）。
    /// </summary>
    private List<Row> SortRectangleRows(IReadOnlyList<Row> rows)
    {
        var result = new List<Row>(rows.Count);
        var sourceGroups = rows
            .Select((row, index) => new { Row = row, Index = index })
            .GroupBy(item => GetSourceGroupKey(item.Row.Job.SourceFile), StringComparer.OrdinalIgnoreCase)
            .OrderBy(group => GetSourceFileSortName(group.Key), NaturalStringComparer.Instance)
            .ThenBy(group => group.Key, StringComparer.OrdinalIgnoreCase)
            .ThenBy(group => group.Min(item => item.Index));

        foreach (var sourceGroup in sourceGroups)
        {
            var fileRows = sourceGroup.Select(item => item.Row).ToList();
            result.AddRange(SortRowsWithinSourceFile(fileRows));
        }

        return result;
    }

    /// <summary>
    /// 单文件内排序：有识别图号（属性身份模式）时按图号自然序，同图号再用单文件空间序打断平局；
    /// 否则直接按单文件打印顺序（SpatialSorter.SortByLayout）。
    /// </summary>
    private List<Row> SortRowsWithinSourceFile(List<Row> fileRows)
    {
        if (fileRows.Count <= 1)
        {
            return fileRows;
        }

        var horizontalFirst = _settings.SortOrderHorizontalFirst;
        var jobToRow = fileRows.ToDictionary(row => row.Job, row => row);

        if (_hasAttributeIdentity)
        {
            var byDrawingNumber = fileRows
                .OrderBy(row => row.Job.DrawingNumber ?? "", NaturalStringComparer.Instance)
                .ThenBy(row => row.Job.Title ?? "", StringComparer.CurrentCultureIgnoreCase)
                .Select(row => row.Job)
                .ToList();

            return SpatiallyBreakTiesWithinFile(byDrawingNumber)
                .Select(job => jobToRow[job])
                .ToList();
        }

        return SpatialSorter.SortByLayout(fileRows.Select(row => row.Job).ToList(), horizontalFirst)
            .Select(job => jobToRow[job])
            .ToList();
    }

    /// <summary>
    /// 图号（及图名）完全相同的连续段内，按单文件空间顺序二次排序。
    /// </summary>
    private List<PlotJob> SpatiallyBreakTiesWithinFile(List<PlotJob> sortedJobs)
    {
        if (sortedJobs.Count <= 1)
        {
            return sortedJobs;
        }

        var horizontalFirst = _settings.SortOrderHorizontalFirst;
        var result = new List<PlotJob>(sortedJobs.Count);
        var i = 0;
        while (i < sortedJobs.Count)
        {
            var anchor = sortedJobs[i];
            var j = i + 1;
            while (j < sortedJobs.Count
                && NaturalStringComparer.Instance.Compare(sortedJobs[j].DrawingNumber, anchor.DrawingNumber) == 0
                && string.Equals(sortedJobs[j].Title, anchor.Title, StringComparison.CurrentCultureIgnoreCase))
            {
                j++;
            }

            var group = sortedJobs.GetRange(i, j - i);
            if (group.Count > 1)
            {
                group = SpatialSorter.SortByLayout(group, horizontalFirst);
            }

            result.AddRange(group);
            i = j;
        }

        return result;
    }

    private static string GetSourceGroupKey(string? sourceFile)
    {
        if (string.IsNullOrWhiteSpace(sourceFile))
        {
            return "";
        }

        try
        {
            return Path.GetFullPath(sourceFile);
        }
        catch
        {
            return sourceFile!.Trim();
        }
    }

    private static string GetSourceFileSortName(string sourceFileKey)
    {
        if (string.IsNullOrWhiteSpace(sourceFileKey))
        {
            return "";
        }

        try
        {
            return Path.GetFileName(sourceFileKey);
        }
        catch
        {
            return sourceFileKey;
        }
    }

    private void RefreshDisplayRows()
    {
        var wasUpdating = _updating;
        _updating = true;
        try
        {
            var visibleRows = _rows
                .Where(row => JobFilter.IsMatch(_settings, row.Job, row.FileName))
                .ToList();
            ReplaceBindingListContents(_displayRows, visibleRows);
        }
        finally
        {
            _updating = wasUpdating;
        }

        UpdateDisplayIndexes();
    }

    /// <summary>
    /// 一次性替换绑定列表内容，只在结束时发送一次 Reset。
    /// 大图纸有数百个矩形框时，逐行 Add 会重复触发整表刷新，形成明显的 O(n²) 界面卡顿。
    /// </summary>
    private static void ReplaceBindingListContents<T>(BindingList<T> target, IEnumerable<T> values)
    {
        target.RaiseListChangedEvents = false;
        try
        {
            target.Clear();
            foreach (var value in values)
            {
                target.Add(value);
            }
        }
        finally
        {
            target.RaiseListChangedEvents = true;
            target.ResetBindings();
        }
    }

    private void UpdateDisplayIndexes()
    {
        // 序号始终按真实清单 _rows 顺序，表头临时排序只改显示，不改号（方便同纸张 Shift 多选）。
        for (var i = 0; i < _rows.Count; i++)
        {
            _rows[i].SetNumber(i + 1);
        }
    }

    private void RefreshOutputPaths()
    {
        if (_updating)
        {
            return;
        }

        // 清单变化后同步「打印图幅」候选：把本次新识别到的图幅并入列表，并保留当前选择。
        RefreshPrintPaperOptions();

        var directory = _outputDirectory.Text.Trim();
        foreach (var row in _rows)
        {
            row.Job.OutputPath = Path.Combine(directory, row.FileName);
        }
    }

    private void ApplyPrintSelectionToHighlightedRows(Row changedRow)
    {
        var targetRows = _pendingPrintToggleRows ?? HighlightedRows();
        _pendingPrintToggleRows = null;
        if (targetRows.Count <= 1 || !targetRows.Contains(changedRow))
        {
            return;
        }

        try
        {
            _updatingPrintSelection = true;
            // 多行高亮后点击“打印”勾选框时，以当前行状态为准批量同步，支持 Shift/Ctrl 选中后一次切换。
            foreach (var row in targetRows)
            {
                row.Selected = changedRow.Selected;
            }
        }
        finally
        {
            _updatingPrintSelection = false;
        }
    }

    private List<Row> HighlightedRows()
    {
        var rows = _grid.SelectedItems.OfType<Row>().Distinct().ToList();
        if (rows.Count == 0 && _grid.CurrentItem is Row current)
        {
            rows.Add(current);
        }
        return rows;
    }

    private void MarkHighlightedNotPrint()
    {
        foreach (var row in HighlightedRows())
        {
            row.Selected = false;
        }
        // 右键“不打印”仅置 Selected=false，保留行（不再从清单移除）；灰显由行样式处理。
        RefreshFileNames();
        RefreshOutputPaths();
        UpdateVisuals();
    }

    private void BatchChangeHighlightedPaper()
    {
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        var rows = HighlightedRows();
        if (TryGetCommonPaperOptions(rows, out var identicalOptions))
        {
            ApplyBatchPaperFromSharedOptions(rows, identicalOptions);
            return;
        }

        if (TryGetCommonAspectRatioPaperOptions(rows, out var aspectOptions))
        {
            ApplyBatchPaperByAspectRatioName(rows, aspectOptions);
            return;
        }

        MessageBox.Show(
            "所选矩形框没有完全相同的候选纸张，且无法用同一套标准/加长图幅（长宽比）统一改纸。",
            Title,
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    /// <summary>候选列表完全一致时：直接套用同一条纸张检测结果。</summary>

    /// <summary>
    /// 从非模态批打窗弹出子对话框。不要把批打窗设为 Owner：部分 CAD（如中望）会把属主藏掉，
    /// 看起来像「选择纸张时批打界面消失」。顶层模态结束后再把批打窗拉回前台。
    /// </summary>
    private bool? ShowChildModalKeepingListVisible(Window dialog)
    {
        var result = CadDialog.ShowModal(dialog);
        CadWindowFocus.RestoreDialog(this);
        return result;
    }

    private void ApplyBatchPaperFromSharedOptions(IReadOnlyList<Row> rows, IReadOnlyList<PaperDetection> options)
    {
        var dialog = new SinglePlotPaperSelectionForm(options);
        if (ShowChildModalKeepingListVisible(dialog) != true)
        {
            return;
        }

        var selectedPaper = dialog.SelectedPaper;
        var paperChoice = PaperSizeDetector.FormatOption(selectedPaper);
        _suppressPaperEvents = true;
        try
        {
            foreach (var row in rows)
            {
                row.PaperChoice = paperChoice;
                ApplyPaper(row.Job, selectedPaper);
                row.RefreshFromJob();
            }
        }
        finally
        {
            _suppressPaperEvents = false;
        }

        RefreshFileNames();
        RefreshOutputPaths();
        UpdateVisuals();
    }

    /// <summary>
    /// 任意比例场景：用户选图幅名后，按各框自身尺寸重算比例并写入。
    /// </summary>
    private void ApplyBatchPaperByAspectRatioName(IReadOnlyList<Row> rows, IReadOnlyList<PaperDetection> aspectNameOptions)
    {
        var dialog = new SinglePlotPaperSelectionForm(aspectNameOptions);
        if (ShowChildModalKeepingListVisible(dialog) != true)
        {
            return;
        }

        var selectedName = dialog.SelectedPaper.PaperName;
        _suppressPaperEvents = true;
        try
        {
            foreach (var row in rows)
            {
                if (!TryGetJobDrawingSize(row.Job, out var width, out var height))
                {
                    continue;
                }

                var aspectOptions = PaperSizeDetector.DetectRectangleBatchAspectRatioCandidates(
                    width,
                    height);
                var match = aspectOptions.FirstOrDefault(paper =>
                    string.Equals(paper.PaperName, selectedName, StringComparison.OrdinalIgnoreCase));
                if (match == null)
                {
                    continue;
                }

                // 下拉改为该框完整长宽比候选，便于后续单行再改。
                row.Options = aspectOptions;
                row.PaperChoice = PaperSizeDetector.FormatOption(match);
                ApplyPaper(row.Job, match);
                row.RefreshFromJob();
            }
        }
        finally
        {
            _suppressPaperEvents = false;
        }

        RefreshFileNames();
        RefreshOutputPaths();
        UpdateVisuals();
    }

    private static bool CanBatchChangePaper(IReadOnlyList<Row> rows)
        => TryGetCommonPaperOptions(rows, out _)
           || TryGetCommonAspectRatioPaperOptions(rows, out _);

    private static bool TryGetCommonPaperOptions(IReadOnlyList<Row> rows, out IReadOnlyList<PaperDetection> options)
    {
        options = new PaperDetection[0];
        if (rows.Count == 0 || rows[0].Options.Count == 0)
        {
            return false;
        }

        var first = rows[0].Options;
        // 候选列表按下拉顺序逐项比较，保证用户选中的第 N 项对每个矩形框含义一致。
        foreach (var row in rows.Skip(1))
        {
            if (!HasSamePaperOptions(first, row.Options))
            {
                return false;
            }
        }

        options = first;
        return true;
    }

    /// <summary>
    /// 各框尺寸不同导致候选比例不一致时，若都能按长宽比解释为同一批标准/加长图幅名，则允许按图幅名批量改纸。
    /// </summary>
    private static bool TryGetCommonAspectRatioPaperOptions(
        IReadOnlyList<Row> rows,
        out IReadOnlyList<PaperDetection> options)
    {
        options = new PaperDetection[0];
        if (rows.Count == 0)
        {
            return false;
        }

        HashSet<string>? commonNames = null;
        IReadOnlyList<PaperDetection>? firstAspect = null;
        foreach (var row in rows)
        {
            if (!TryGetJobDrawingSize(row.Job, out var width, out var height))
            {
                return false;
            }

            var aspect = PaperSizeDetector.DetectRectangleBatchAspectRatioCandidates(
                width,
                height);
            if (aspect.Count == 0)
            {
                return false;
            }

            firstAspect ??= aspect;
            var names = new HashSet<string>(
                aspect.Select(paper => paper.PaperName),
                StringComparer.OrdinalIgnoreCase);
            commonNames = commonNames == null
                ? names
                : new HashSet<string>(commonNames.Where(names.Contains), StringComparer.OrdinalIgnoreCase);
            if (commonNames.Count == 0)
            {
                return false;
            }
        }

        if (firstAspect == null || commonNames == null || commonNames.Count == 0)
        {
            return false;
        }

        // 展示用条目取自首框；真正应用时按各框尺寸重算比例。
        options = firstAspect
            .Where(paper => commonNames.Contains(paper.PaperName))
            .GroupBy(paper => paper.PaperName, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.First())
            .ToList();
        return options.Count > 0;
    }

    /// <summary>读取作业对应的图面宽高（用于按长宽比重算纸张/比例）。</summary>
    private static bool TryGetJobDrawingSize(PlotJob job, out double width, out double height)
    {
        width = 0;
        height = 0;
        if (job.UsesUserCoordinateSystem)
        {
            width = Math.Abs(job.UcsMaxX - job.UcsMinX);
            height = Math.Abs(job.UcsMaxY - job.UcsMinY);
            if (width > 1e-9d && height > 1e-9d)
            {
                return true;
            }
        }

        if (job.CornerPoints is { Length: >= 8 } points)
        {
            width = Math.Sqrt(
                (points[2] - points[0]) * (points[2] - points[0])
                + (points[3] - points[1]) * (points[3] - points[1]));
            height = Math.Sqrt(
                (points[4] - points[2]) * (points[4] - points[2])
                + (points[5] - points[3]) * (points[5] - points[3]));
            if (width > 1e-9d && height > 1e-9d)
            {
                return true;
            }
        }

        width = Math.Abs(job.MaxX - job.MinX);
        height = Math.Abs(job.MaxY - job.MinY);
        return width > 1e-9d && height > 1e-9d;
    }

    private static bool HasSamePaperOptions(IReadOnlyList<PaperDetection> first, IReadOnlyList<PaperDetection> second)
    {
        if (first.Count != second.Count)
        {
            return false;
        }

        for (var i = 0; i < first.Count; i++)
        {
            if (!IsSamePaperOption(first[i], second[i]))
            {
                return false;
            }
        }

        return true;
    }

    private static bool IsSamePaperOption(PaperDetection first, PaperDetection second)
    {
        const double tolerance = 0.001;
        return string.Equals(first.PaperName, second.PaperName, StringComparison.Ordinal)
            && string.Equals(first.ScaleText, second.ScaleText, StringComparison.Ordinal)
            && Math.Abs(first.PaperWidthMm - second.PaperWidthMm) <= tolerance
            && Math.Abs(first.PaperHeightMm - second.PaperHeightMm) <= tolerance
            && Math.Abs(first.ScaleValue - second.ScaleValue) <= tolerance
            && first.IsLong == second.IsLong
            && first.RequiresCustomPaper == second.RequiresCustomPaper;
    }

    private void DeleteHighlighted()
    {
        foreach (var row in HighlightedRows())
        {
            _rows.Remove(row);
        }
        RefreshDisplayRows();
        RefreshFileNames();
        UpdateVisuals();
    }

    private void PrintOrStop()
    {
        if (_printCts != null)
        {
            // 正在打印中 → 停止
            _printCts.Cancel();
            return;
        }

        Print();
    }

    private void Print()
    {
        _grid.CommitEdit(DataGridEditingUnit.Row, true);
        RefreshOutputPaths();
        if (IsDwgOutput)
        {
            SplitDwgs();
            return;
        }

        var selected = _rows
            .Where(row => row.Selected && JobFilter.IsMatch(_settings, row.Job, row.FileName))
            .Select(row => row.Job)
            .ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("没有勾选任何矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var directory = _outputDirectory.Text.Trim();
        if (string.IsNullOrWhiteSpace(directory))
        {
            MessageBox.Show("请选择输出路径。", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var device = SelectedDevice();
        if (string.IsNullOrWhiteSpace(device))
        {
            MessageBox.Show($"未找到可用的 {SelectedOutputFormat} 输出设备。", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        Directory.CreateDirectory(directory);
        SaveCurrentPlotOptions();
        // 统一图幅必须先于留白与纸张注册写入作业：留白扩大纸张和 PMP 注册都基于作业纸张尺寸。
        var paperBackups = new Dictionary<PlotJob, PrintPaperBackup>();
        ApplyPrintPaperOverrides(selected, paperBackups);
        ApplyLeaveMarginSelection(selected);
        var originalPaths = selected.ToDictionary(job => job, job => job.OutputPath);
        string? temporaryDirectory = null;
        var mergedOutput = Path.Combine(directory, SourceStem() + ".pdf");
        var mergePdf = IsPdfOutput && _mergePdf.IsChecked == true;
        var mergedOutputPaths = new List<string>();
        var completed = 0;
        var printLogLines = new List<string>();

        // 常规设置中的“生成打印日志”是全局日志总开关；关闭时只保留界面状态和错误提示，
        // 不在内存累计日志，也不触发日志目录或文件创建。
        void AppendPrintLog(string level, string message)
        {
            if (_settings.GeneratePrintLog)
            {
                printLogLines.Add(BatchPlotLogger.Format(level, message));
            }
        }

        string SavePrintLog()
        {
            return _settings.GeneratePrintLog
                ? BatchPlotLogger.SaveRunLog(printLogLines)
                : "";
        }

        static string BuildLogText(string path)
        {
            return string.IsNullOrWhiteSpace(path) ? "" : $"\n日志: {path}";
        }

        AppendPrintLog(
            "INFO",
            $"开始通用型批量打印；共={selected.Count}；格式={SelectedOutputFormat}；设备={device}；打印样式={SelectedStyle()}");
        var wasTopmost = Topmost;
        BatchPlotHostProgress.Begin();
        BatchPrintProgressSession? progress = null;
        try
        {
            // 切换按钮为"停止"状态
            _printCts = new CancellationTokenSource();
            _printButton.Content = "停止";
            _printButton.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(200, 40, 40));
            _printButton.BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(160, 30, 30));
            // 打印期间置顶并保持可见，方便点「停止」；同时抑制 CAD 引擎进度框盖窗。
            Visibility = System.Windows.Visibility.Visible;
            Topmost = true;
            Activate();
            progress = BatchPrintProgressSession.Start(
                this,
                selected.Count,
                () => _printCts?.Cancel());

            if (mergePdf && !_settings.KeepIndividualPdfsWhenMerging)
            {
                temporaryDirectory = Path.Combine(Path.GetTempPath(), "ZwcadBatchPlot", "RectangleMerge_" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temporaryDirectory);
                for (var i = 0; i < selected.Count; i++)
                {
                    selected[i].OutputPath = Path.Combine(temporaryDirectory, $"{i + 1:D5}.pdf");
                }
            }

            _status.Text = $"打印中... 0 / {selected.Count}";
            progress.Report(0, selected.Count, "准备自定义纸张与输出路径…");
            Pump();

            // 汇总本批所有任意加长尺寸后只更新一次实际 PMP，再进入连续打印。
            CustomPaperBatchPreparer.Prepare(selected, device);
            var results = PdfRasterExport.PlotMany(
                selected, device, SelectedStyle(), _document, _settings,
                beforeJob: job =>
                {
                    completed++;
                    _status.Text = $"打印中... {completed} / {selected.Count}";
                    var finalOutput = originalPaths.TryGetValue(job, out var path) ? path : job.OutputPath;
                    var detail =
                        $"第 {completed} / {selected.Count} 张\n" +
                        $"布局：{job.SpaceName}\n" +
                        $"输出：{System.IO.Path.GetFileName(finalOutput)}";
                    progress.Report(completed, selected.Count, detail);
                    AppendPrintLog(
                        "INFO",
                        $"开始打印 {completed}/{selected.Count}；源文件={job.SourceFile}；布局={job.SpaceName}；输出={finalOutput}");
                    Visibility = System.Windows.Visibility.Visible;
                    Activate();
                    Pump();
                },
                cancellationToken: _printCts.Token);

            foreach (var result in results)
            {
                var finalOutput = originalPaths.TryGetValue(result.Job, out var path)
                    ? path
                    : result.Job.OutputPath;
                AppendPrintLog(
                    result.Succeeded ? "INFO" : "ERROR",
                    result.Succeeded
                        ? $"打印成功；布局={result.Job.SpaceName}；输出={finalOutput}"
                        : $"打印失败；布局={result.Job.SpaceName}；输出={finalOutput}；错误={result.Error}");
            }

            var failures = results.Where(result => !result.Succeeded).ToList();
            if (failures.Count > 0)
            {
                throw new InvalidOperationException(string.Join("\n", failures.Select(result => result.Error?.Message)));
            }

            if (mergePdf)
            {
                _status.Text = "正在合并 PDF...";
                progress?.SetPhase("正在合并 PDF…", "请稍候，合并完成后会自动关闭进度窗口。");
                Pump();
                var mergeInputs = selected.Select(job => new PdfMergeInput(
                    job.OutputPath,
                    Path.GetFileNameWithoutExtension(originalPaths[job]),
                    OutputPaperNameResolver.Resolve(
                        job,
                        _settings.LongPaperSnapToleranceMm),
                    job.PaperWidthMm,
                    job.PaperHeightMm)).ToList();
                var mergePlans = PdfDocumentService.PlanMerges(
                    mergeInputs,
                    mergedOutput,
                    _settings.MergePdfByPaperSize,
                    _settings.AddSequenceWhenPdfExists);
                foreach (var mergePlan in mergePlans)
                {
                    PdfDocumentService.Merge(
                        mergePlan.Inputs,
                        mergePlan.OutputPath,
                        _settings.UseFileNameAsPdfBookmark);
                    mergedOutputPaths.Add(mergePlan.OutputPath);
                    AppendPrintLog("INFO", $"合并 PDF 成功；输出={mergePlan.OutputPath}");
                }
            }

            if (mergePdf && _settings.OpenMergedPdfAfterMerge)
            {
                OpenMergedPdfFiles(mergedOutputPaths);
            }
            else if (!mergePdf && _settings.OpenOutputDirectoryAfterBatchPrint)
            {
                RevealOutput(null, directory);
            }
            _status.Text = $"完成，共 {selected.Count} 张";
            AppendPrintLog("INFO", $"通用型批量打印完成；成功={selected.Count}；失败=0");
            var printLogPath = SavePrintLog();
            var printLogText = BuildLogText(printLogPath);
            MessageBox.Show(
                mergePdf
                    ? $"打印并合并完成，共 {selected.Count} 张，生成 {mergedOutputPaths.Count} 个 PDF。\n{string.Join("\n", mergedOutputPaths)}{printLogText}"
                    : $"打印完成，共 {selected.Count} 张。\n{directory}{printLogText}",
                Title,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (OperationCanceledException)
        {
            _status.Text = $"已停止（已完成 {completed} / {selected.Count}）";
            AppendPrintLog("INFO", $"用户取消打印；已开始={completed}/{selected.Count}");
            var printLogPath = SavePrintLog();
            MessageBox.Show($"打印已停止。\n已完成 {completed} / {selected.Count} 张。{BuildLogText(printLogPath)}", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            _status.Text = "打印失败";
            AppendPrintLog("ERROR", "通用型批量打印失败: " + ex);
            var printLogPath = SavePrintLog();
            MessageBox.Show("通用型批量打印失败: " + ex.Message + BuildLogText(printLogPath), Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _printCts?.Dispose();
            _printCts = null;
            // 恢复按钮
            _printButton.Content = "开始打印";
            _printButton.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 120, 215));
            _printButton.BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 95, 170));
            Topmost = wasTopmost;
            progress?.Dispose();
            progress = null;
            BatchPlotHostProgress.End();

            foreach (var pair in originalPaths)
            {
                pair.Key.OutputPath = pair.Value;
            }
            // 统一图幅只是本次打印设置，打印结束立即还原识别出的图幅。
            RestorePrintPapers(paperBackups);
            if (!string.IsNullOrWhiteSpace(temporaryDirectory))
            {
                try { Directory.Delete(temporaryDirectory, true); } catch { }
            }
            UpdateVisuals();
        }
    }

    private void SplitDwgs()
    {
        var selected = _rows
            .Where(row => row.Selected && JobFilter.IsMatch(_settings, row.Job, row.FileName))
            .Select(row => row.Job)
            .ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("没有勾选任何矩形框。", Title, MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var directory = _outputDirectory.Text.Trim();
        if (string.IsNullOrWhiteSpace(directory))
        {
            MessageBox.Show("请选择输出路径。", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var confirm = MessageBox.Show(
            $"将按当前矩形框拆出 {selected.Count} 个 DWG 文件。\n\n输出位置：{directory}\n\n是否继续？",
            "通用型批量拆图",
            MessageBoxButton.OKCancel,
            MessageBoxImage.Question);
        if (confirm != MessageBoxResult.OK)
        {
            return;
        }

        Directory.CreateDirectory(directory);
        SaveCurrentPlotOptions();
        Cursor = Cursors.Wait;
        IsEnabled = false;
        try
        {
            _status.Text = $"拆图中... 0 / {selected.Count}";
            var completed = 0;
            var explicitPaths = selected.ToDictionary(job => job, job => job.OutputPath);
            var results = DwgSplitService.SplitMany(
                selected,
                _document,
                _settings,
                beforeJob: _ =>
                {
                    completed++;
                    _status.Text = $"拆图中... {completed} / {selected.Count}";
                    Pump();
                },
                explicitOutputPaths: explicitPaths);

            var failures = results.Where(result => result.Error != null).ToList();
            if (failures.Count > 0)
            {
                throw new InvalidOperationException(string.Join("\n", failures.Select(result => result.Error?.Message)));
            }

            foreach (var result in results)
            {
                result.Job.OutputPath = result.OutputPath;
            }
                if (_settings.OpenOutputDirectoryAfterBatchPrint)
            {
                RevealOutput(null, directory);
            }
            _status.Text = $"拆图完成，共 {selected.Count} 张";
            MessageBox.Show($"DWG 拆图完成，共 {selected.Count} 张。\n{directory}", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            _status.Text = "拆图失败";
            MessageBox.Show("通用型批量拆图失败: " + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsEnabled = true;
            Cursor = Cursors.Arrow;
            UpdateVisuals();
        }
    }

    // ── 打印图幅（统一出图） ──

    /// <summary>「打印图幅」下拉项：默认图幅表示保留每张图纸自身识别出的图幅与比例。</summary>
    private sealed class PrintPaperOption
    {
        public string Name { get; set; } = "";
        public bool IsDefault { get; set; }
        public override string ToString() => Name;
    }

    /// <summary>「打印图幅」默认项文本：保留每张图纸自身识别出的图幅与比例。</summary>
    private const string DefaultPrintPaperName = "默认图幅";

    /// <summary>下拉中始终提供的标准图幅，顺序 A0→A4（A0 最大）。</summary>
    private static readonly string[] StandardPrintPaperNames = { "A0", "A1", "A2", "A3", "A4" };

    /// <summary>统一改纸前备份的作业纸张字段（打印/预览结束立即还原，绝不回写识别数据）。</summary>
    private sealed class PrintPaperBackup
    {
        public string PaperName { get; set; } = "";
        public double PaperWidthMm { get; set; }
        public double PaperHeightMm { get; set; }
        public string PaperSizeText { get; set; } = "";
        public bool DetectedRequiresCustomPaperRegistration { get; set; }
    }

    /// <summary>DWG 拆图不经过绘图器，图幅设置不生效。</summary>
    private bool SupportsPrintPaper => !IsDwgOutput;

    /// <summary>当前选中的「打印图幅」；空字符串表示默认图幅（每张图纸按自身识别结果打印）。</summary>
    private string SelectedPrintPaperName
        => _printPaperCombo.SelectedItem is PrintPaperOption option && !option.IsDefault
            ? option.Name
            : "";

    /// <summary>
    /// 重建「打印图幅」下拉：默认图幅 → 清单中识别到的图幅（含加长图，按 A0→A4 排序）→ 其余标准图幅。
    /// 重建时按名称保留当前选择，避免清单刷新后选择被重置。
    /// </summary>
    private void RefreshPrintPaperOptions(string? preferredName = null)
    {
        var keep = preferredName ?? SelectedPrintPaperName;
        var names = new List<string>();
        foreach (var name in _rows
                     .Select(row => row.Job.PaperName?.Trim() ?? "")
                     // 「自定义」按实测尺寸出图，无法作为统一规格，不进入候选。
                     .Where(name => name.Length > 0
                                    && !string.Equals(name, PaperSizeDetector.CustomPaperName, StringComparison.OrdinalIgnoreCase))
                     .Distinct(StringComparer.OrdinalIgnoreCase)
                     .OrderBy(GetPrintPaperSortRank)
                     .ThenBy(name => name, StringComparer.OrdinalIgnoreCase))
        {
            names.Add(name);
        }

        foreach (var standard in StandardPrintPaperNames)
        {
            if (!names.Contains(standard, StringComparer.OrdinalIgnoreCase))
            {
                names.Add(standard);
            }
        }

        // 整个重建过程（含 Items.Clear 触发的选择丢失）都要抑制，否则会被当成用户切换而反复保存。
        _updatingPrintPaperOptions = true;
        try
        {
            _printPaperCombo.Items.Clear();
            _printPaperCombo.Items.Add(new PrintPaperOption { Name = DefaultPrintPaperName, IsDefault = true });
            foreach (var name in names)
            {
                _printPaperCombo.Items.Add(new PrintPaperOption { Name = name });
            }

            var selectedIndex = 0;
            if (!string.IsNullOrWhiteSpace(keep))
            {
                for (var index = 1; index < _printPaperCombo.Items.Count; index++)
                {
                    if (_printPaperCombo.Items[index] is PrintPaperOption option
                        && string.Equals(option.Name, keep, StringComparison.OrdinalIgnoreCase))
                    {
                        selectedIndex = index;
                        break;
                    }
                }
            }

            _printPaperCombo.SelectedIndex = selectedIndex;
        }
        finally
        {
            _updatingPrintPaperOptions = false;
        }
    }

    /// <summary>图幅排序键：A0 最小（最前），加长图排在同号标准图之后，非标准图幅排在最后。</summary>
    private static int GetPrintPaperSortRank(string name)
    {
        var plusIndex = name.IndexOf('+');
        var baseName = plusIndex > 0 ? name.Substring(0, plusIndex) : name;
        var rank = Array.FindIndex(
            StandardPrintPaperNames,
            standard => string.Equals(standard, baseName, StringComparison.OrdinalIgnoreCase));
        return rank < 0 ? StandardPrintPaperNames.Length + 1 : rank;
    }

    /// <summary>
    /// 「打印图幅」统一出图：把选中图幅临时写入本批作业（方向沿用图纸当前纸张方向），
    /// 使本次打印/预览的所有图纸按同一规格出图。识别数据本身不变，
    /// 结束后必须调用 <see cref="RestorePrintPapers"/> 还原，避免影响文件名、图纸目录等输出。
    /// </summary>
    private void ApplyPrintPaperOverrides(
        IReadOnlyList<PlotJob> jobs,
        Dictionary<PlotJob, PrintPaperBackup> backups)
    {
        var target = SupportsPrintPaper ? SelectedPrintPaperName : "";
        if (string.IsNullOrWhiteSpace(target) || jobs.Count == 0)
        {
            return;
        }

        foreach (var job in jobs)
        {
            if (!backups.ContainsKey(job))
            {
                backups[job] = new PrintPaperBackup
                {
                    PaperName = job.PaperName,
                    PaperWidthMm = job.PaperWidthMm,
                    PaperHeightMm = job.PaperHeightMm,
                    PaperSizeText = job.PaperSizeText,
                    DetectedRequiresCustomPaperRegistration = job.DetectedRequiresCustomPaperRegistration
                };
            }

            // 短边取所选图幅的标准短边，长边按本图纸自身长宽比推导，避免非 1:1 出图时图纸被拉伸变形。
            var target0 = PaperSizeDetector.ResolveUniformPaperTarget(target, job.PaperWidthMm, job.PaperHeightMm);
            job.PaperName = target0.Name;
            job.PaperWidthMm = target0.Width;
            job.PaperHeightMm = target0.Height;
            job.PaperSizeText = $"{target0.Width:0.##} x {target0.Height:0.##} mm";
            // 长边随图纸后若偏离该图幅标准尺寸，须按自定义/加长纸张注册后再精确打印；正留白扩纸由留白逻辑重新标记。
            job.DetectedRequiresCustomPaperRegistration = target0.NeedsCustomPaper;
            job.RequiresCustomPaperRegistration = target0.NeedsCustomPaper;
        }
    }

    /// <summary>还原统一改纸前的作业纸张字段（可重复调用，幂等）。</summary>
    private static void RestorePrintPapers(IReadOnlyDictionary<PlotJob, PrintPaperBackup> backups)
    {
        foreach (var pair in backups)
        {
            var job = pair.Key;
            var backup = pair.Value;
            job.PaperName = backup.PaperName;
            job.PaperWidthMm = backup.PaperWidthMm;
            job.PaperHeightMm = backup.PaperHeightMm;
            job.PaperSizeText = backup.PaperSizeText;
            job.DetectedRequiresCustomPaperRegistration = backup.DetectedRequiresCustomPaperRegistration;
            job.RequiresCustomPaperRegistration = backup.DetectedRequiresCustomPaperRegistration;
        }
    }

    private void PrintPaper_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboEvents || _updatingPrintPaperOptions)
        {
            return;
        }

        // 统一图幅只在打印/预览时临时生效，切换后同步状态栏提示并记住选择。
        UpdateVisuals();
        SaveCurrentPlotOptions();
    }

    private void ApplyLeaveMarginSelection(IEnumerable<PlotJob> jobs)
    {
        // PNG/JPG 先出 PDF 再转图，留白与 PDF 相同，按当前勾选写入作业。
        var leaveMargin = SupportsLeaveMargin && _leaveMargin.IsChecked == true;
        var marginMm = ReadMarginValue(_marginInput);
        foreach (var job in jobs)
        {
            // 留白是本次输出选项，预览和正式打印都写入同一个 PlotJob，保证效果一致。
            job.LeavePaperMargin = leaveMargin;
            job.PaperMarginMm = marginMm;
            // 负留白只缩比例，不能把图框扫描得到的任意纸张注册要求一并清除。
            job.RequiresCustomPaperRegistration =
                job.DetectedRequiresCustomPaperRegistration || (leaveMargin && marginMm > 0);
            if (!leaveMargin || marginMm <= 0)
            {
                job.EffectivePaperWidthMm = 0;
                job.EffectivePaperHeightMm = 0;
                job.RequireExactPaperSize = false;
                job.UseExactWindowScale = false;
                job.CustomPaperWasAdded = false;
            }
        }
    }

    private void LoadPlotOptions()
    {
        _suppressComboEvents = true;
        _outputFormatCombo.Items.Clear();
        _outputFormatCombo.Items.Add("PDF");
#if !ACAD2012
        // 同 BatchPlotForm：2012 构建没有 Docnet.Core，不提供 PNG/JPG 转图格式。
        _outputFormatCombo.Items.Add("PNG");
        _outputFormatCombo.Items.Add("JPG");
#endif
        _outputFormatCombo.Items.Add("DWF");
        _outputFormatCombo.Items.Add("DWG");
        _outputFormatCombo.SelectedIndex = 0;
        RefreshSavePathModeOptions(preserveSelection: false);

        var pdfInstall = AcadPlotterInstaller.InstallBundledPlotter();
        var pngInstall = AcadPlotterInstaller.InstallPngPlotter();
        var jpgInstall = AcadPlotterInstaller.InstallJpgPlotter();
        var dwfInstall = AcadPlotterInstaller.InstallDwfPlotter();
        AcadPlotterInstaller.RefreshPlotterDevicesIfNeeded(
            pdfInstall.Written || pngInstall.Written || jpgInstall.Written || dwfInstall.Written);
        var validator = PlotSettingsValidator.Current;
        var devices = validator.GetPlotDeviceList()
            .Cast<object>()
            .Select(item => item?.ToString() ?? "")
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .ToList();
        _dwfPlotDevice = FindPlotDevice(
            devices,
            dwfInstall.DeviceName,
            value => value.IndexOf("DWF", StringComparison.OrdinalIgnoreCase) >= 0
                     && value.IndexOf("DWFx", StringComparison.OrdinalIgnoreCase) < 0,
            AcadPlotterInstaller.PreferredDwfPlotter,
            "DWF6 ePlot.pc3",
            "DWF6 ePlot.pc5",
            "ZWPLOT_DWF.pc5",
            "M_DWF.pc5");
        foreach (var style in PlotStyleManager.GetAvailableCtbStyles())
        {
            _style.Items.Add(style);
        }
        PlotStyleManager.RestoreSavedStyle(_style, _settings.LastStyleSheet);
        // 上次样式在当前 CAD 不可用时已回退；立刻写回设置，避免下次仍记住失效 CTB。
        SaveCurrentPlotOptions();
        UpdateOutputFormatUi();
        _suppressComboEvents = false;
        _styleSelectionReady = true;
    }

    private static string FindPlotDevice(
        IReadOnlyList<string> devices,
        string installedPlotter,
        Func<string, bool> fallbackPredicate,
        params string[] preferred)
    {
        foreach (var expected in new[] { installedPlotter }
                     .Concat(preferred)
                     .Where(value => !string.IsNullOrWhiteSpace(value)))
        {
            var match = devices.FirstOrDefault(value => string.Equals(value, expected, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(match))
            {
                return match;
            }
        }

        // 只能返回 CAD 当前会话已经枚举到的设备；磁盘上刚生成但未刷新到会话的名称不可直接用于 PlotSettings。
        return devices.FirstOrDefault(fallbackPredicate) ?? "";
    }

    private void SetAll(bool selected)
    {
        foreach (var row in _rows)
        {
            row.Selected = selected;
        }
        RefreshFileNames();
        UpdateVisuals();
    }

    private void UpdateVisuals()
    {
        var selected = _rows.Count(row => row.Selected);
        var order = _settings.SortOrderHorizontalFirst ? "左→右、上→下" : "上→下、左→右";
        var paperHint = string.IsNullOrWhiteSpace(SelectedPrintPaperName)
            ? ""
            : $"  |  打印图幅：{SelectedPrintPaperName}";
        var nameHint = _nameFieldTags.Count == 0
            ? ""
            : $"  |  文件命名：{FormatNameFieldPreviewSummary()}";
        _status.Text = $"识别 {_rows.Count} 个矩形框  |  已选 {selected} 个  |  格式：{SelectedOutputFormat}{paperHint}{nameHint}  |  顺序：{order}  |  输出：{_outputDirectory.Text}";
        ScheduleOverlayIfRebuildNeeded();
    }

    /// <summary>
    /// 当前会画到 CAD 上的清单快照：顺序代表打印序号。
    /// </summary>
    private List<(PlotJob Job, string DrawingNumber)> CaptureOverlayRebuildKey()
    {
        var keys = new List<(PlotJob Job, string DrawingNumber)>();
        foreach (var row in _displayRows)
        {
            if (!row.Selected)
            {
                continue;
            }

            keys.Add((row.Job, row.Job.DrawingNumber ?? ""));
        }

        return keys;
    }

    /// <summary>
    /// 打印顺序（同一 Job 引用的先后）或图号任一变化，才需要整批 Show 红框。
    /// </summary>
    private static bool OverlayRebuildKeysEqual(
        IReadOnlyList<(PlotJob Job, string DrawingNumber)>? left,
        IReadOnlyList<(PlotJob Job, string DrawingNumber)>? right)
    {
        if (left == null || right == null)
        {
            return left == null && right == null;
        }

        if (left.Count != right.Count)
        {
            return false;
        }

        for (var i = 0; i < left.Count; i++)
        {
            if (!ReferenceEquals(left[i].Job, right[i].Job)
                || !string.Equals(left[i].DrawingNumber, right[i].DrawingNumber, StringComparison.Ordinal))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// 改纸张、切格式、刷状态栏时不要重建红框；只有框集合或序号变了才 Show。
    /// </summary>
    private void ScheduleOverlayIfRebuildNeeded()
    {
        var key = CaptureOverlayRebuildKey();
        if (_overlayPainted && OverlayRebuildKeysEqual(_lastOverlayRebuildKey, key))
        {
            return;
        }

        ScheduleOverlayRefresh();
    }

    /// <summary>
    /// 表格先刷新完，下一帧再画 CAD 红框，避免识别结果和 Regen 挤在同一次 UI 消息里卡住窗口。
    /// </summary>
    private void ScheduleOverlayRefresh()
    {
        if (_suppressSequenceOverlayFromMultiFile)
        {
            ClearSequenceOverlay();
            return;
        }

        if (!IsLoaded)
        {
            return;
        }

        var generation = ++_overlayScheduleGeneration;
        Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            if (!IsLoaded || generation != _overlayScheduleGeneration)
            {
                return;
            }

            ShowOverlayNow();
        }));
    }

    private void ShowOverlayNow()
    {
        try
        {
            var selectedJobs = _displayRows.Where(row => row.Selected).Select(row => row.Job).ToList();
            var highlightJob = (_highlightedJobIndex >= 0 && _highlightedJobIndex < _rows.Count)
                ? _rows[_highlightedJobIndex].Job
                : null;
            _overlay.Show(selectedJobs, highlightJob);
            _lastOverlayRebuildKey = CaptureOverlayRebuildKey();
            _overlayPainted = true;
        }
        catch
        {
            _overlay.Clear(repaint: false);
            _lastOverlayRebuildKey = null;
            _overlayPainted = false;
        }
    }

    private void ChooseOutputDirectory()
    {
        // FolderBrowserDialog 保留 WinForms 版（WPF 没有等价物）。
        using var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = "选择输出目录",
            SelectedPath = _outputDirectory.Text
        };
        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            _outputDirectoryIsCustom = true;
            SetOutputDirectoryText(dialog.SelectedPath);
            SaveCurrentPlotOptions();
            RefreshOutputPaths();
        }
    }

    private void ApplyManuallyEnteredOutputDirectory()
    {
        if (!_outputDirectoryModified)
        {
            return;
        }

        _outputDirectoryModified = false;
        var directory = _outputDirectory.Text.Trim();
        if (string.IsNullOrWhiteSpace(directory))
        {
            _outputDirectoryIsCustom = false;
            UpdateAutomaticOutputDirectory();
        }
        else
        {
            _outputDirectoryIsCustom = true;
            SetOutputDirectoryText(directory);
        }

        SaveCurrentPlotOptions();
        RefreshOutputPaths();
    }

    private void RefreshSavePathModeOptions(bool preserveSelection)
    {
        var selectedIndex = preserveSelection && _savePathModeCombo.SelectedIndex >= 0
            ? Math.Min(_savePathModeCombo.SelectedIndex, 1)
            : 0;
        var format = SelectedOutputFormat;
        var formatPathText = string.IsNullOrWhiteSpace(format)
            ? "源文件路径/输出格式"
            : "源文件路径/" + format;

        var wasSuppressing = _suppressComboEvents;
        _suppressComboEvents = true;
        try
        {
            _savePathModeCombo.Items.Clear();
            _savePathModeCombo.Items.Add("源文件路径");
            _savePathModeCombo.Items.Add(formatPathText);
            _savePathModeCombo.SelectedIndex = selectedIndex;
        }
        finally
        {
            _suppressComboEvents = wasSuppressing;
        }
    }

    private void ApplySelectedSavePathMode()
    {
        _outputDirectoryIsCustom = false;
        UpdateAutomaticOutputDirectory();
        SaveCurrentPlotOptions();
        RefreshOutputPaths();
        UpdateVisuals();
    }

    private void UpdateAutomaticOutputDirectory()
    {
        var subfolder = AutomaticOutputSubfolder;
        SetOutputDirectoryText(string.IsNullOrWhiteSpace(subfolder)
            ? SourceDirectory()
            : Path.Combine(SourceDirectory(), subfolder));
    }

    private void SetOutputDirectoryText(string text)
    {
        _suppressTextEvents = true;
        try
        {
            _outputDirectory.Text = text;
        }
        finally
        {
            _suppressTextEvents = false;
        }
        _outputDirectoryModified = false;
    }

    private void UpdateOutputFormatUi()
    {
        RefreshSavePathModeOptions(preserveSelection: true);
        if (!_outputDirectoryIsCustom)
        {
            UpdateAutomaticOutputDirectory();
        }

        var plotOutput = !IsDwgOutput;
        _style.IsEnabled = plotOutput;
        _styleSettingsButton.IsEnabled = plotOutput && _style.SelectedIndex >= 0;
        _leaveMargin.IsEnabled = SupportsLeaveMargin;
        _marginInput.IsEnabled = SupportsLeaveMargin && _leaveMargin.IsChecked == true;
        _printPaperCombo.IsEnabled = SupportsPrintPaper;
        _mergePdf.IsEnabled = IsPdfOutput;
        RefreshFileNames();
        SaveCurrentPlotOptions();
        UpdateVisuals();
    }

    private string SourceDirectory()
    {
        var file = _document.Database.Filename;
        return string.IsNullOrWhiteSpace(file)
            ? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            : Path.GetDirectoryName(file) ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
    }

    private string SourceStem()
    {
        var value = Path.GetFileNameWithoutExtension(_document.Database.Filename);
        return string.IsNullOrWhiteSpace(value) ? Path.GetFileNameWithoutExtension(_document.Name) : value;
    }

    private string SelectedOutputFormat => _outputFormatCombo.SelectedItem?.ToString()?.Trim() ?? "PDF";
    private string SelectedOutputExtension => "." + SelectedOutputFormat.ToLowerInvariant();
    private bool IsPdfOutput => string.Equals(SelectedOutputFormat, "PDF", StringComparison.OrdinalIgnoreCase);
    private bool IsDwgOutput => string.Equals(SelectedOutputFormat, "DWG", StringComparison.OrdinalIgnoreCase);
    private bool IsDwfOutput => string.Equals(SelectedOutputFormat, "DWF", StringComparison.OrdinalIgnoreCase);
    /// <summary>DWG 拆图不走留白；PNG/JPG 先出 PDF 再转图，留白语义与 PDF 相同。</summary>
    private bool SupportsLeaveMargin => !IsDwgOutput;
    private string? AutomaticOutputSubfolder => _savePathModeCombo.SelectedIndex == 1
        ? FileNameSanitizer.Clean(SelectedOutputFormat)
        : null;
    /// <summary>PNG/JPG 与 PDF 共用 PDF 绘图仪，打印后再按设置 DPI 转图。</summary>
    private string SelectedDevice() => IsDwfOutput
        ? _dwfPlotDevice
        : AcadPlotterInstaller.PreferredPdfPlotter;
    private string SelectedStyle() => _style.SelectedItem?.ToString() ?? "";

    private void SaveCurrentPlotOptions()
    {
        _settings.LastPlotDevice = AcadPlotterInstaller.PreferredPdfPlotter;
        var style = PlotStyleManager.NormalizeStyleName(SelectedStyle());
        if (!string.IsNullOrEmpty(style))
        {
            _settings.LastStyleSheet = style;
        }
        _settings.MergePdf = _mergePdf.IsChecked == true;
        _settings.LeavePaperMargin = _leaveMargin.IsChecked == true;
        _settings.PaperMarginMm = ReadMarginValue(_marginInput);
        _settings.PrintPaperName = SelectedPrintPaperName;
        AppSettingsStore.Save(_settings);
    }

    /// <summary>初始化留白下拉列表，正值=扩大纸张，负值=缩比例，整数1~10配对显示。</summary>
    private static void InitMarginCombo(ComboBox combo, double savedValue)
    {
        combo.Items.Clear();
        // 整数 1~10，每档先 + 再 -，共 20 项
        for (var n = 1; n <= 10; n++)
        {
            combo.Items.Add(new MarginOption { Value = n });
            combo.Items.Add(new MarginOption { Value = -n });
        }
        // 选中与保存值最接近的项
        var bestIdx = 0;
        var bestDiff = double.MaxValue;
        for (var i = 0; i < combo.Items.Count; i++)
        {
            if (combo.Items[i] is MarginOption opt)
            {
                var diff = Math.Abs(opt.Value - savedValue);
                if (diff < bestDiff) { bestDiff = diff; bestIdx = i; }
            }
        }
        combo.SelectedIndex = bestIdx;
    }

    /// <summary>读取留白下拉列表的选中值（毫米）。</summary>
    private static double ReadMarginValue(ComboBox combo)
        => combo.SelectedItem is MarginOption opt ? opt.Value : 1.0;

    private static void ApplyPaper(PlotJob job, PaperDetection paper)
    {
        job.PaperName = paper.PaperName;
        job.PaperWidthMm = paper.PaperWidthMm;
        job.PaperHeightMm = paper.PaperHeightMm;
        job.PaperSizeText = $"{paper.PaperWidthMm:0.##} x {paper.PaperHeightMm:0.##} mm";
        job.ScaleText = paper.ScaleText;
        job.DetectedRequiresCustomPaperRegistration = paper.RequiresCustomPaper;
        job.RequiresCustomPaperRegistration = paper.RequiresCustomPaper;
        // 用户从任意纸切回标准/模数纸时，立即清除上一次预览留下的严格动态纸张状态。
        if (!paper.RequiresCustomPaper)
        {
            job.RequireExactPaperSize = false;
            job.UseExactWindowScale = false;
            job.CustomPaperWasAdded = false;
        }
    }

    private static void RevealOutput(string? file, string directory)
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = !string.IsNullOrWhiteSpace(file) && File.Exists(file)
                    ? $"/select,\"{Path.GetFullPath(file)}\""
                    : $"\"{Path.GetFullPath(directory)}\"",
                UseShellExecute = true
            });
        }
        catch
        {
        }
    }

    private static void OpenMergedPdfFiles(IEnumerable<string> outputFiles)
    {
        foreach (var outputFile in outputFiles.Where(File.Exists))
        {
            try
            {
                // 分组后的每个合并 PDF 都直接打开，行为与单一合并文件保持一致。
                Process.Start(new ProcessStartInfo
                {
                    FileName = Path.GetFullPath(outputFile),
                    UseShellExecute = true
                });
            }
            catch
            {
            }
        }
    }

    private void ShowSortSettings()
    {
        // 矩形框没有图号/图名业务字段，始终只允许选择图纸位置的排列方向。
        var dialog = new SortOrderDialog(
            _settings.SortOrderHorizontalFirst,
            showSortBasis: false,
            sortMode: TitleBlockSortMode.Spatial);
        if (ShowChildModalKeepingListVisible(dialog) != true) return;
        _settings.SortOrderHorizontalFirst = dialog.HorizontalFirst;
        AppSettingsStore.Save(_settings);
        SortRows();
    }

    private void ShowSettingsAtTab(int tabIndex)
    {
        while (true)
        {
            SettingsForm.InitialTabIndex = tabIndex;
            // 通用型的文件名由面板上的「文件命名」对话框负责：设置窗的"文件名"页里不显示图框块那套 A/B/C 规则，
            // 只留「通用打印文件命名」入口（与面板上的按钮是同一个对话框、同一份字段列表）。
            var form = new SettingsForm(showTitleBlockFileNameSection: false);
            if (CadDialog.ShowModal(form) != true)
            {
                break;
            }

            // 重新加载相关设置
            var updated = AppSettingsStore.Load();
            var recognitionSettingsChanged =
                Math.Abs(_settings.PaperMatchToleranceMm - updated.PaperMatchToleranceMm) > 1e-9
                || _settings.RecognizeFourLineRectangleFrames
                != updated.RecognizeFourLineRectangleFrames
                || !ScalesEqual(_settings.CustomScales, updated.CustomScales);
            _settings.PaperMatchToleranceMm = updated.PaperMatchToleranceMm;
            _settings.RecognizeFourLineRectangleFrames = updated.RecognizeFourLineRectangleFrames;
            _settings.CustomScales = updated.CustomScales;
            _settings.HideFrameBoundaryWhenPlotting = updated.HideFrameBoundaryWhenPlotting;
            _settings.PlotTransparency = updated.PlotTransparency;
            _settings.GeneratePrintLog = updated.GeneratePrintLog;
            _settings.ConvertTextToGeometryWhenPlotting = updated.ConvertTextToGeometryWhenPlotting;
            _settings.LongPaperSnapToleranceMm = updated.LongPaperSnapToleranceMm;
            _settings.LongPaperNameFormat = updated.LongPaperNameFormat;
            _settings.SortOrderHorizontalFirst = updated.SortOrderHorizontalFirst;
            _settings.PdfFileNamePattern = updated.PdfFileNamePattern;
            _settings.AddSequenceWhenPdfExists = updated.AddSequenceWhenPdfExists;
            _settings.FileNameSequenceDigits = updated.FileNameSequenceDigits;
            _settings.AutoFileNameSequenceDigits = updated.AutoFileNameSequenceDigits;
            _settings.FileNameSequenceStartNumber = updated.FileNameSequenceStartNumber;
            _settings.PdfFileNameSeparator = updated.PdfFileNameSeparator;
            _settings.RectangleFileNameFields = updated.RectangleFileNameFields.ToList();
            _settings.FilterKeyword = updated.FilterKeyword;
            _settings.FilterScope = updated.FilterScope;
            LoadNameFields();
            // 重新应用「过滤图纸」：隐藏不匹配的行（_rows 保留全部数据，仅显示/打印命中的）。
            RefreshDisplayRows();

            if (form.RequestOpenGenericFileNameEditor)
            {
                // 与面板上的「文件命名」按钮完全一致：设置窗已保存并关闭，这里弹同一个对话框。
                OpenFileNameFieldDialog();
                return;
            }

            if (!form.RequestPickDirectoryRowHeight
                && !form.RequestPickDirectoryTextAppearance
                && !form.RequestPickScaleFromCad
                && !form.RequestOpenGenericFileNameEditor
                && string.IsNullOrWhiteSpace(form.RequestedDirectoryColumnKey))
            {
                if (recognitionSettingsChanged)
                {
                    // 开关或纸张容差变化后立即沿用上次扫描范围重扫，避免列表仍显示旧识别结果。
                    ReloadFrames();
                }
                else
                {
                    // 文件名规则或序号设置变更后刷新列表输出名。
                    RefreshFileNames();
                }
                return;
            }

            tabIndex = form.SelectedTabIndex;
            Hide();
            Pump();
            try
            {
                var document = GetActiveCadDocument();
                if (document == null)
                {
                    MessageBox.Show(
                        "当前没有可用的 CAD 图纸，请先打开图纸后重试。",
                        "批量打印设置",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                    continue;
                }

                var settings = AppSettingsStore.Load();
                bool ok;
                string message;
                if (form.RequestPickScaleFromCad)
                {
                    // 与目录「图中交互」同一套路：设置窗已关，回到 CAD 框选后再重开比例页。
                    // 只写入自定义比例，不自动重扫；需要新比例生效时由用户自行扫描。
                    ok = ScaleSettingsPicker.PromptScaleFromFrame(document, settings, out settings, out message);
                    _settings.CustomScales = settings.CustomScales;
                }
                else if (form.RequestPickDirectoryTextAppearance)
                {
                    ok = DirectoryTableGenerator.PromptTextAppearance(document, settings, out _, out message);
                }
                else if (form.RequestPickDirectoryRowHeight)
                {
                    ok = DirectoryTableGenerator.PromptRowHeight(document, settings, out _, out message);
                }
                else
                {
                    ok = DirectoryTableGenerator.PromptColumnSize(
                        document,
                        settings,
                        form.RequestedDirectoryColumnKey ?? "",
                        out _,
                        out message);
                }

                // 成功后设置页会重开并显示新值，不必再弹“已设置”；失败/取消仍提示。
                if (!ok)
                {
                    MessageBox.Show(message, "批量打印设置", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            finally
            {
                Show();
                Activate();
            }
        }
    }

    private static void Pump()
    {
        // 等价原 WinForms Application.DoEvents：在打印循环里刷新界面。
        Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.Background, new Action(() => { }));
    }

    /// <summary>比较自定义比例列表是否一致，用于判断是否需要重扫。</summary>
    private static bool ScalesEqual(IReadOnlyList<double> left, IReadOnlyList<double> right)
    {
        if (left.Count != right.Count)
        {
            return false;
        }

        for (var i = 0; i < left.Count; i++)
        {
            if (Math.Abs(left[i] - right[i]) > 1e-9)
            {
                return false;
            }
        }

        return true;
    }

    private static Document? GetActiveCadDocument()
    {
        try
        {
            return CadApp.DocumentManager.MdiActiveDocument;
        }
        catch
        {
            return null;
        }
    }
}
