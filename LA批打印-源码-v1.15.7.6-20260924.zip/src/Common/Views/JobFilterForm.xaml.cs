using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ZwcadBatchPlot;

/// <summary>
/// 「过滤图纸」对话框 —— 把原来嵌在「常规设置 → 常规页」右侧的图纸过滤独立成单独对话框，
/// 由批量打印面板底部快捷栏的「过滤图纸」按钮（位于「常规设置」左侧）直接打开。
/// <para>
/// 关键字支持多个值（逗号/分号，中英文均可），任一命中即通过（OR）；
/// 「匹配范围」决定关键字与文本列表针对图名 / 图号 / 文件名 / 全部。
/// 只有点「确定」才写回 <see cref="AppSettings.FilterKeyword"/> 与 <see cref="AppSettings.FilterScope"/>，
/// 「取消」不改动任何设置。过滤只影响清单显示与打印/拆图范围，编号仍按完整清单计算（会跳号）。
/// </para>
/// </summary>
public sealed partial class JobFilterForm : Window
{
    /// <summary>调用方传入的当前图纸清单，用于填充“文本列表”的去重候选值；为空时文本列表不可用。</summary>
    private readonly IReadOnlyList<PlotJob>? _jobs;

    /// <summary>
    /// 每个作业“实际文件名”的取值器。通用型面板清单显示的是 Row.FileName，而非 job.DisplayOutputFileName，
    /// 需由面板传入，文本列表才会与打印窗口里的文件名一致；图框块传 null（回退 job.DisplayOutputFileName）。
    /// </summary>
    private readonly Func<PlotJob, string?>? _fileNameSelector;

    /// <summary>防止关键字输入框与文本列表选择互相触发造成的死循环。</summary>
    private bool _suppressSync;

    /// <param name="jobs">当前批量打印清单（图框块传 _jobs，通用型传各 Row 的 Job），用于“文本列表”的去重候选值。</param>
    /// <param name="fileNameSelector">
    /// 取每个作业“实际文件名”的方法。通用型清单的“文件名”列绑定的是 Row.FileName，
    /// 传入该取值器后文本列表才与打印窗口里的文件名一致；图框块不传。
    /// </param>
    public JobFilterForm(IReadOnlyList<PlotJob>? jobs = null, Func<PlotJob, string?>? fileNameSelector = null)
    {
        InitializeComponent();
        _jobs = jobs;
        _fileNameSelector = fileNameSelector;

        LoadSettings();
    }

    /// <summary>用已保存的过滤设置初始化控件，并填充文本列表。</summary>
    private void LoadSettings()
    {
        var settings = AppSettingsStore.Load();

        _suppressSync = true;
        try
        {
            _filterScope.SelectedIndex = Math.Max(0, Math.Min(3, settings.FilterScope));
            _filterKeyword.Text = settings.FilterKeyword;
        }
        finally
        {
            _suppressSync = false;
        }

        PopulateFilterValueList();
    }

    /// <summary>按当前匹配范围重建文本列表，并按关键字同步高亮已选中的项。</summary>
    private void PopulateFilterValueList()
    {
        if (_filterValueList == null)
        {
            return;
        }

        var scope = _filterScope?.SelectedIndex ?? 0;
        var values = _jobs == null
            ? new List<string>()
            : JobFilter.CollectDistinctValues(_jobs, scope, _fileNameSelector);
        _filterValueList.ItemsSource = values;
        SyncFilterListSelection();
    }

    /// <summary>按当前关键字把文本列表中命中的项设为选中（供关键字输入/范围切换时同步高亮）。</summary>
    private void SyncFilterListSelection()
    {
        if (_filterValueList == null)
        {
            return;
        }

        _suppressSync = true;
        try
        {
            var tokens = new HashSet<string>(JobFilter.ParseKeywords(_filterKeyword?.Text), StringComparer.OrdinalIgnoreCase);
            _filterValueList.SelectedItems.Clear();
            foreach (var item in _filterValueList.Items.OfType<string>())
            {
                if (tokens.Contains(item))
                {
                    _filterValueList.SelectedItems.Add(item);
                }
            }
        }
        finally
        {
            _suppressSync = false;
        }
    }

    private void OnFilterScopeChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSync)
        {
            return;
        }

        PopulateFilterValueList();
    }

    private void OnFilterValueListSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSync || _filterValueList == null)
        {
            return;
        }

        _suppressSync = true;
        try
        {
            var selected = _filterValueList.SelectedItems.OfType<string>().ToList();
            _filterKeyword.Text = string.Join(",", selected);
        }
        finally
        {
            _suppressSync = false;
        }
    }

    private void OnFilterKeywordTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_suppressSync)
        {
            return;
        }

        SyncFilterListSelection();
    }

    private void OnClearFilterClick(object sender, RoutedEventArgs e)
    {
        _suppressSync = true;
        try
        {
            if (_filterKeyword != null)
            {
                _filterKeyword.Text = "";
            }
            if (_filterScope != null)
            {
                _filterScope.SelectedIndex = 0;
            }
            if (_filterValueList != null)
            {
                _filterValueList.SelectedItems.Clear();
            }
        }
        finally
        {
            _suppressSync = false;
        }

        PopulateFilterValueList();
    }

    private void OnOkClick(object sender, RoutedEventArgs e)
    {
        // 只回写过滤两项，其余设置原样保留（AppSettingsStore.Load 取到的是全量设置）。
        var settings = AppSettingsStore.Load();
        settings.FilterKeyword = _filterKeyword.Text.Trim();
        settings.FilterScope = Math.Max(0, Math.Min(3, _filterScope.SelectedIndex));
        AppSettingsStore.Save(settings);

        DialogResult = true;
        Close();
    }
}
