using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ZwcadBatchPlot;

/// <summary>
/// 通用型批量打印「文件命名」对话框表格中的一行（= 文件名中的一段）。
/// 表格三列：<b>序号</b>（在文件名中的先后位置）、<b>字段名</b>（取值依据，可直接改写）、
/// <b>文件名效果</b>（本行这个属性块自己拼出来的那几段文字；整串文件名在窗口底部单独显示）。
/// <para>
/// <b>一行 = 一个属性块</b>：拾取到的属性按所属块分行，同一块的多个属性放在同一行。
/// </para>
/// <para>
/// 字段文本为「属性名」或「块名|属性名」（同名属性分属不同属性块时靠块名区分）；
/// 整项为保留名「图幅」时取该图纸识别出的图幅；
/// 不含汉字/字母/数字时是固定文本项（横线等），原样拼进文件名并充当分隔。
/// </para>
/// <para>
/// <b>一行 = 一个属性块，可放多个字段</b>：界面上用「 / 」分隔显示，出图时<b>每个字段各占一段、
/// 都拼进文件名</b>（按行内顺序；本图取不到值的字段那一段不参与）。存储形态见
/// <c>FileNameFieldSpec.CandidateSeparator</c>，界面编辑形态见 <see cref="Editor"/>。
/// </para>
/// </summary>
internal sealed class NameFieldEntry : INotifyPropertyChanged
{
    private string _tag = "";
    private string _editor = "";
    private string _preview = "";
    private string _segment = "";
    private string _resolved = "";
    private string _leadingSeparator = "";
    private bool _hasValue;
    private bool _editing;
    private bool _selected;
    private int _index;

    public NameFieldEntry(string tag, string sample = "")
    {
        _tag = (tag ?? "").Trim();
        Sample = (sample ?? "").Trim();
        _editor = FileNameFieldSpec.DisplayRow(_tag);
    }

    /// <summary>字段名被编辑后触发：参数为本项与编辑前的旧字段名。</summary>
    public event Action<NameFieldEntry, string>? TagChanged;

    /// <summary>
    /// 字段名（= 取值依据）的<b>存储形态</b>：单个字段时是「属性名」或「块名|属性名」，
    /// 一行挂多个候选时用 <c>FileNameFieldSpec.CandidateSeparator</c>（「||」）连接。
    /// 整项为保留名「图幅」时取该图纸识别出的图幅；
    /// 不含汉字/字母/数字时是固定文本项（横线等），原样拼进文件名。
    /// </summary>
    public string Tag
    {
        get => _tag;
        set
        {
            var next = (value ?? "").Trim();
            if (string.Equals(next, _tag, StringComparison.Ordinal))
            {
                return;
            }

            var previous = _tag;
            _tag = next;
            Raise(nameof(Tag));
            Raise(nameof(Hint));
            TagChanged?.Invoke(this, previous);
        }
    }

    /// <summary>
    /// 输入框里显示的字段名（多个候选用「 / 」连接，可直接改写，按「/」拆分即成多个候选）。
    /// 只有调用 <see cref="CommitEditor"/> 后才会真正写回 <see cref="Tag"/>。
    /// </summary>
    public string Editor
    {
        get => _editor;
        set
        {
            var next = value ?? "";
            if (string.Equals(next, _editor, StringComparison.Ordinal))
            {
                return;
            }

            _editor = next;
            Raise(nameof(Editor));
        }
    }

    /// <summary>本次会话拾取到的属性值：清单还没识别出图纸时用它兜底显示，也用于悬停提示。</summary>
    public string Sample { get; private set; }

    /// <summary>序号（1 起）：即这一段在文件名中的第几段；由对话框在增删 / 排序后统一刷新。</summary>
    public int Index => _index;

    /// <summary>本行是否被选中：选中后「拾取到本行」会把新拾取的属性追加进这一行。</summary>
    public bool IsSelected => _selected;

    /// <summary>
    /// 「文件名效果」列显示的文字：<b>本行（该属性块）自己拼出来的那几段</b>（一行一个块，各行内容不同，
    /// 一眼看出是哪个块贡献了文件名）；本行一段都没取到值时显示「未取到」（灰）。
    /// 整串文件名在窗口底部单独显示一次，不在本列重复。
    /// </summary>
    public string EffectText => _preview.Length > 0 ? _preview : "未取到";

    /// <summary>该行在当前图纸里是否取到了非空值（决定效果列的颜色：灰色 = 本图没取到，不参与文件名）。</summary>
    public bool HasValue => _hasValue;

    /// <summary>真正取到值的那个候选字段（本行只挂一个时为空串也无所谓）；都没取到时为空。</summary>
    public string ResolvedField => _resolved;

    /// <summary>显示在本段前面的连接符（第一段、以及本图没取到值的段为空）。</summary>
    public string LeadingSeparator => _leadingSeparator;

    /// <summary>是否处于编辑状态（编辑状态下字段名输入框可写）。</summary>
    public bool IsEditing => _editing;

    /// <summary>非编辑状态下输入框只读：避免误改动字段名。</summary>
    public bool IsReadOnly => !_editing;

    /// <summary>重排行次 / 增删后由对话框刷新序号。</summary>
    public void SetIndex(int index)
    {
        if (_index == index)
        {
            return;
        }

        _index = index;
        Raise(nameof(Index));
    }

    /// <summary>切换"本行被选中"的高亮状态。</summary>
    public void SetSelected(bool selected)
    {
        if (_selected == selected)
        {
            return;
        }

        _selected = selected;
        Raise(nameof(IsSelected));
    }

    /// <summary>按存储形态的字段名刷新输入框显示文本（字段集合被外部改动后调用）。</summary>
    public void SyncDisplay(string? canonical = null)
    {
        var text = FileNameFieldSpec.DisplayRow(canonical ?? _tag);
        if (string.Equals(text, _editor, StringComparison.Ordinal))
        {
            return;
        }

        _editor = text;
        Raise(nameof(Editor));
    }

    /// <summary>
    /// 把输入框里的文字提交成字段名：按「/」拆成多个字段（各占一段，都拼进文件名），
    /// 再规整显示文本并写回 <see cref="Tag"/>（为空即视为删除本行）。
    /// </summary>
    public void CommitEditor()
    {
        var canonical = FileNameFieldSpec.JoinCandidates(FileNameFieldSpec.SplitDisplayCandidates(_editor));
        SyncDisplay(canonical);
        Tag = canonical;
    }

    /// <summary>进入编辑：允许改写字段名。</summary>
    public void BeginEdit()
    {
        if (_editing)
        {
            return;
        }

        _editing = true;
        Raise(nameof(IsEditing));
        Raise(nameof(IsReadOnly));
    }

    /// <summary>结束编辑：锁回只读。</summary>
    public void EndEdit()
    {
        if (!_editing)
        {
            return;
        }

        _editing = false;
        Raise(nameof(IsEditing));
        Raise(nameof(IsReadOnly));
    }

    /// <summary>
    /// 刷新「文件名效果」列（面板识别图纸、拾取字段、改名、改顺序后调用）。
    /// </summary>
    /// <param name="value">要显示的<b>本行文字</b>（本行这个属性块的各段按顺序拼出来的那部分）。</param>
    /// <param name="hasValue">本行是否取到了值（决定效果列的颜色）。</param>
    /// <param name="leadingSeparator">本行文字前面的连接符。</param>
    /// <param name="resolvedField">本行真正取到值的那些候选字段（多个时用「 / 」连接）。</param>
    /// <param name="segmentValue">同 <paramref name="value"/>（保留此参数只为悬停提示单独成句）。</param>
    public void SetPreview(string value, bool hasValue, string leadingSeparator, string resolvedField, string segmentValue = "")
    {
        var text = (value ?? "").Trim();
        var segment = (segmentValue ?? "").Trim();
        var separator = leadingSeparator ?? "";
        var resolved = (resolvedField ?? "").Trim();
        if (_hasValue == hasValue
            && string.Equals(_preview, text, StringComparison.Ordinal)
            && string.Equals(_segment, segment, StringComparison.Ordinal)
            && string.Equals(_leadingSeparator, separator, StringComparison.Ordinal)
            && string.Equals(_resolved, resolved, StringComparison.Ordinal))
        {
            return;
        }

        _preview = text;
        _segment = segment;
        _hasValue = hasValue;
        _leadingSeparator = separator;
        _resolved = resolved;
        Raise(nameof(EffectText));
        Raise(nameof(HasValue));
        Raise(nameof(LeadingSeparator));
        Raise(nameof(ResolvedField));
        Raise(nameof(Hint));
    }

    /// <summary>悬停提示：命名效果、字段本身、取值范围、可编辑说明。</summary>
    public string Hint
    {
        get
        {
            var candidates = FileNameFieldSpec.SplitCandidates(_tag);

            if (FileNameFieldSpec.IsLiteral(_tag))
            {
                return $"固定文本：{_tag}\n这一段不取值，直接原样写进文件名，并充当它后面一段的分隔。\n"
                       + "点一下可改成别的符号（任意不含汉字/字母/数字的符号都行，如 _ # . ~）；"
                       + "「/」会被当成同行多字段的分隔符、空格会被丢掉。\n"
                       + "右键：前移 / 后移 / 增加分隔文本 / 删除该字段 / 清空字段。";
            }

            if (candidates.Count > 1)
            {
                var used = _hasValue && _resolved.Length > 0
                    ? $"本行取到值的字段：{_resolved}；本行的这些段拼出来：{_segment}"
                    : "本行的这些字段在本图都没取到值（这些段不参与文件名，效果列显示为灰色）。";
                var order = string.Join(FileNameFieldSpec.CandidateDisplaySeparator, candidates);
                return $"{used}\n本行字段（各占一段，都拼进文件名）：{order}\n"
                       + "点一下可改写成多个字段，用「/」分隔（如 图号/图名）。\n"
                       + "右键：拾取更多属性追加到本行 / 拆成独立行 / 前移 / 后移 / 删除该字段 / 清空字段。";
            }

            if (FileNameFieldSpec.IsPaperField(_tag))
            {
                var paperEffect = _hasValue
                    ? $"本段取值（来自拾取时点/框到的那张图）：{_segment}（完整文件名见窗口底部）"
                    : "拾取时点/框到的那张图还没识别出图幅（该段不参与文件名，效果列显示为灰色）。";
                return $"{paperEffect}\n字段：{_tag}（保留名，取该图纸识别出的图幅，与图框块面板占位符 T 同口径）\n"
                       + "要取属性块里名为「图幅」的属性，请写成「块名|图幅」。\n"
                       + "右键：追加拾取到本行 / 前移 / 后移 / 增加分隔文本 / 删除该字段 / 清空字段。";
            }

            FileNameFieldSpec.Parse(_tag, out var blockName, out var tag);
            var scope = blockName.Length == 0
                ? $"取值范围：不限属性块，图框内任意属性块中名为「{tag}」的属性都算。"
                : $"取值范围：只取「{blockName}」这个属性块里的「{tag}」。";
            var effect = _hasValue
                ? $"本段取值（来自拾取时点/框到的那张图）：{_segment}（完整文件名见窗口底部）"
                : "拾取时点/框到的那张图没取到该字段的值（该段不参与文件名，效果列显示为灰色）。";
            var sample = !_hasValue && !string.IsNullOrWhiteSpace(Sample) ? $"\n拾取时取到过：{Sample}" : "";
            return $"{effect}{sample}\n字段：{_tag}\n{scope}\n"
                   + $"点一下可把字段改成「属性名」或「块名{FileNameFieldSpec.Separator}属性名」；"
                   + "用「/」分隔可放多个字段（各占一段，都拼进文件名）。\n"
                   + "右键：追加拾取到本行 / 前移 / 后移 / 增加分隔文本 / 删除该字段 / 清空字段。";
        }
    }

    public void SetSample(string sample)
    {
        var next = (sample ?? "").Trim();
        if (string.Equals(next, Sample, StringComparison.Ordinal))
        {
            return;
        }

        Sample = next;
        Raise(nameof(Hint));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void Raise([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
