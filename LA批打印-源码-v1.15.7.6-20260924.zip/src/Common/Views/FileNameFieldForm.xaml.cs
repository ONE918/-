using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Threading;

namespace ZwcadBatchPlot;

/// <summary>
/// 「文件命名」列表里<b>一行</b>的命名效果：由批量打印面板按当前图纸算好后交给对话框显示，
/// 与真正的文件名同源（保证对话框里看到的顺序和文字就是要打出来的文件名）。
/// 一行的多个属性各占一段，这里已按段序拼成该行的文字。
/// 不用 <c>readonly struct</c>：Common 源码还要编译进 net45 目标，用普通类最稳。
/// </summary>
public sealed class NameFieldPreview
{
    public NameFieldPreview(string? value, bool hasValue, string? leadingSeparator, string? resolvedField = "")
    {
        Value = (value ?? "").Trim();
        HasValue = hasValue;
        LeadingSeparator = leadingSeparator ?? "";
        ResolvedField = (resolvedField ?? "").Trim();
    }

    /// <summary>参与文件名的那段文字（固定文本项即其本身）。</summary>
    public string Value { get; }

    /// <summary>本段是否参与文件名（取到了值，或本身是固定文本）。</summary>
    public bool HasValue { get; }

    /// <summary>拼在本段前面的连接符；第一段、没取到值的段、紧跟在固定文本后的段为空。</summary>
    public string LeadingSeparator { get; }

    /// <summary>本行真正取到值的那些字段（一行多个字段时全部列出，用「 / 」连接）。</summary>
    public string ResolvedField { get; }
}

/// <summary>
/// 通用型批量打印「文件命名」对话框 —— 把原来贴在面板底部「文件命名」按钮右侧的命名效果列表
/// 独立成单独窗口：点面板上的「文件命名」按钮弹出，设置输出文件名由哪些段组成、顺序如何。
/// <para>
/// 字段集合按<b>引用共享</b>面板的那一份（<c>_nameFieldTags</c> / <c>_nameFieldSamples</c>），
/// 任何改动都即时持久化并重算文件名；底部「取消」只关闭本窗口（不回滚已生效的改动），「确认」再落盘一次并关闭。
/// 命名效果（每段在该图纸上取到的文字）由面板通过 <c>previewProvider</c> 现算，保证与真正写盘的文件名一致。
/// </para>
/// <para>
/// 主体是三列表格：<b>序号</b>（这一段在文件名中的第几段）、<b>字段名</b>（取值依据，可直接改写）、
/// <b>文件名效果</b>（这一段在预览图纸上取到的文字，取不到显示灰色「未取到」且不参与文件名）。
/// </para>
/// <para>
/// <b>一行 = 一个属性块</b>：拾取到的属性按<b>所属属性块</b>分行（框住几个块就建几行），
/// 行内同一块的多个字段<b>各占一段、都拼进文件名</b>，界面上用「 / 」分隔显示。
/// 先点一行选中它、再点「拾取到本行」（或右键「追加拾取到本行」）= 把新拾取的属性追加进该行
/// （第一个块进选中行，其余块各自新建一行）；右键「拆成独立行」可把一行的多个字段拆成各自一行。
/// </para>
/// <para>
/// 用<b>非模态</b>窗口：窗口里的「拾取属性文字」需要把自己（和面板）隐藏后回到图面取点，
/// 模态窗在 CAD 里取点会受限；这也与面板本身（非模态）的既有取点链路一致。
/// </para>
/// </summary>
public sealed partial class FileNameFieldForm : Window
{
    /// <summary>
    /// 是否显示「字段名」那一列（依赖属性，供列表行模板绑定列宽与可见性）。
    /// 默认 <b>false</b>：表格只显示「序号 + 文件名效果」，要改字段名时勾底部开关（右键「改字段名」会自动勾上）。
    /// </summary>
    public static readonly DependencyProperty ShowFieldNameProperty = DependencyProperty.Register(
        nameof(ShowFieldName),
        typeof(bool),
        typeof(FileNameFieldForm),
        new PropertyMetadata(false, OnShowFieldNameChanged));

    /// <summary>「字段名」列的宽度（<see cref="ShowFieldName"/> 为 false 时收成 0）。</summary>
    public static readonly DependencyProperty FieldNameColumnWidthProperty = DependencyProperty.Register(
        nameof(FieldNameColumnWidth),
        typeof(GridLength),
        typeof(FileNameFieldForm),
        new PropertyMetadata(new GridLength(0)));

    public bool ShowFieldName
    {
        get => (bool)GetValue(ShowFieldNameProperty);
        set => SetValue(ShowFieldNameProperty, value);
    }

    public GridLength FieldNameColumnWidth
    {
        get => (GridLength)GetValue(FieldNameColumnWidthProperty);
        set => SetValue(FieldNameColumnWidthProperty, value);
    }

    private static void OnShowFieldNameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        => ((FileNameFieldForm)d).FieldNameColumnWidth =
            (bool)e.NewValue ? new GridLength(2, GridUnitType.Star) : new GridLength(0);

    /// <summary>面板的「文件命名」字段集合（按引用共享，顺序即文件名中各段的排列顺序）。</summary>
    private readonly List<string> _tags;

    /// <summary>面板的示例值字典（按引用共享，仅用于列表悬停提示，不持久化）。</summary>
    private readonly Dictionary<string, string> _samples;

    /// <summary>向面板索取当前命名效果：每个字段一段（取值 / 是否取到 / 连接符 / 命中的候选）。</summary>
    private readonly Func<List<NameFieldPreview>>? _previewProvider;

    /// <summary>
    /// 回到图面拾取属性文字并写入字段集合：参数为<b>目标行下标</b>
    /// （-1 = 本次拾取到的属性按所属块各自新建一行；&gt;=0 = 第一个块追加进该行，其余块仍新建行）。
    /// 返回状态文字（空串 = 没有拾取到任何东西）。
    /// </summary>
    private readonly Func<int, string>? _pickProvider;

    /// <summary>字段变化后的收尾（面板持久化设置 + 重算文件名）。</summary>
    private readonly Action? _fieldsChanged;

    /// <summary>把状态文字同步到面板状态栏。</summary>
    private readonly Action<string>? _statusSink;

    /// <summary>列表项，Tag 顺序即文件名中各段的排列顺序，与 <see cref="_tags"/> 保持同步。</summary>
    private readonly ObservableCollection<NameFieldEntry> _entries = new();

    /// <summary>当前选中的行（「拾取到本行」把新属性追加到这一行）。</summary>
    private NameFieldEntry? _selectedEntry;

    /// <summary>程序化同步列表项（重建列表、回滚改名）时为 true，避免把内部改动当成用户编辑再次提交。</summary>
    private bool _syncing;

    private bool _itemsBound;

    /// <param name="tags">面板的字段集合（按引用共享，本窗口直接改它）。</param>
    /// <param name="samples">面板的示例值字典（按引用共享）。</param>
    /// <param name="previewProvider">向面板索取当前命名效果（每段取值 + 连接符）。</param>
    /// <param name="pickProvider">回到图面拾取属性文字（参数为行下标，-1 = 新建一行），返回状态文字；面板负责隐窗与 CAD 取点。</param>
    /// <param name="fieldsChanged">字段变化后通知面板（持久化 + 重算文件名）。</param>
    /// <param name="statusSink">把状态文字同步到面板状态栏。</param>
    public FileNameFieldForm(
        List<string> tags,
        Dictionary<string, string> samples,
        Func<List<NameFieldPreview>>? previewProvider,
        Func<int, string>? pickProvider,
        Action? fieldsChanged,
        Action<string>? statusSink)
    {
        InitializeComponent();
        _tags = tags ?? new List<string>();
        _samples = samples ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        _previewProvider = previewProvider;
        _pickProvider = pickProvider;
        _fieldsChanged = fieldsChanged;
        _statusSink = statusSink;

        ReloadFromTags();
        SetStatus(_tags.Count == 0
            ? "尚未设置文件名字段：点「拾取属性文字」到图面上点选 / 框选属性文字，或右键「添加字段 / 增加图幅 / 增加分隔文本」。"
            : $"当前字段：{FormatTagSummary()}");
    }

    // ── 列表刷新 ──

    /// <summary>字段摘要（如「图号 + 图名 / 标题 + 图幅」），还没设置时返回「未设置」。</summary>
    private string FormatTagSummary()
        => _tags.Count == 0 ? "未设置" : string.Join(" + ", _tags.Select(FileNameFieldSpec.DisplayRow));

    /// <summary>状态文字：本窗底部 + 面板状态栏各写一份，关掉窗口后也能在面板上看到。</summary>
    private void SetStatus(string text)
    {
        if (_nameFieldStatus != null)
        {
            _nameFieldStatus.Text = text;
        }

        _statusSink?.Invoke(text);
    }

    /// <summary>
    /// 刷新列表：字段集合与列表项一致时只更新悬停提示（避免打断正在输入的项），
    /// 否则按字段顺序重建列表项。列表项本身就是输入框，可直接改名。
    /// </summary>
    private void ReloadFromTags()
    {
        var same = _entries.Count == _tags.Count;
        if (same)
        {
            for (var i = 0; i < _tags.Count; i++)
            {
                if (!string.Equals(_tags[i], _entries[i].Tag, StringComparison.OrdinalIgnoreCase))
                {
                    same = false;
                    break;
                }
            }
        }

        _syncing = true;
        try
        {
            if (same)
            {
                foreach (var entry in _entries)
                {
                    entry.SetSample(SampleFor(entry.Tag));
                    entry.SyncDisplay();
                }
            }
            else
            {
                _entries.Clear();
                _selectedEntry = null;
                foreach (var tag in _tags)
                {
                    _entries.Add(CreateEntry(tag));
                }
            }

            EnsureItemsBound();
            UpdatePlaceholder();
            UpdateIndexes();
        }
        finally
        {
            _syncing = false;
        }

        RefreshPreview();
    }

    /// <summary>一行的示例值：本行任一候选取到过的文字（用于没识别出图纸时的悬停兜底）。</summary>
    private string SampleFor(string row)
    {
        foreach (var candidate in FileNameFieldSpec.SplitCandidates(row))
        {
            if (_samples.TryGetValue(candidate, out var sample) && !string.IsNullOrWhiteSpace(sample))
            {
                return sample.Trim();
            }
        }

        return "";
    }

    /// <summary>
    /// 只刷新命名效果（面板识别图纸、重算文件名后调用）。
    /// <b>「文件名效果」列显示本行（该属性块）自己拼出来的那几段</b>，取不到值时显示灰色「未取到」；
    /// <b>整串文件名</b>由窗口底部「文件名效果：」统一显示一次（三行各显示各的，便于看出是哪个块贡献的）。
    /// </summary>
    internal void RefreshPreview()
    {
        var previews = _previewProvider?.Invoke() ?? new List<NameFieldPreview>();
        var fullName = BuildFullName(previews);
        for (var i = 0; i < _entries.Count; i++)
        {
            if (i < previews.Count)
            {
                // 效果列显示**本行（该属性块）自己拼出来的那几段**（三行内容因此各不相同，
                // 一眼能看出是哪个块贡献了文件名）；整串只在窗口底部「文件名效果：」显示一次。
                _entries[i].SetPreview(
                    previews[i].Value,
                    previews[i].HasValue,
                    previews[i].LeadingSeparator,
                    previews[i].ResolvedField,
                    previews[i].Value);
            }
            else
            {
                // 效果段数与列表项不一致（字段刚变、面板还没重算）：先按"取不到值"显示，别留上一次的旧文字。
                _entries[i].SetPreview("", false, "", "");
            }
        }

        _previewLine.Text = fullName.Length == 0
            ? (_tags.Count == 0 ? "" : $"文件名效果：未取到值（现为 {FormatTagSummary()}）")
            : $"文件名效果：{fullName}";
    }

    /// <summary>把各段按顺序拼成整串文件名（取不到值的段不参与，与真正写盘的文件名同口径）。</summary>
    private static string BuildFullName(List<NameFieldPreview> previews)
    {
        var builder = new StringBuilder();
        foreach (var preview in previews)
        {
            if (preview.HasValue && preview.Value.Length > 0)
            {
                builder.Append(preview.LeadingSeparator).Append(preview.Value);
            }
        }

        return builder.ToString();
    }

    /// <summary>
    /// 命名效果摘要（如 IN-1-01_平面布置_A2），用于状态文字；还没取到值时退回字段名列表。
    /// 与面板 <c>FormatNameFieldPreviewSummary</c> 同口径（都从当前图纸现算）。
    /// </summary>
    private string PreviewSummaryText()
    {
        var previews = _previewProvider?.Invoke() ?? new List<NameFieldPreview>();
        var builder = new StringBuilder();
        foreach (var preview in previews)
        {
            if (preview.HasValue && preview.Value.Length > 0)
            {
                builder.Append(preview.LeadingSeparator).Append(preview.Value);
            }
        }

        return builder.Length == 0 ? FormatTagSummary() : builder.ToString();
    }

    private void EnsureItemsBound()
    {
        if (_itemsBound)
        {
            return;
        }

        _nameFieldList.ItemsSource = _entries;
        _itemsBound = true;
    }

    private void UpdatePlaceholder()
        => _nameFieldPlaceholder.Visibility = _entries.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

    /// <summary>刷新表格的「序号」列（1 起）：增删与前后移之后行次会变，必须重排，否则序号会跳号。</summary>
    private void UpdateIndexes()
    {
        for (var i = 0; i < _entries.Count; i++)
        {
            _entries[i].SetIndex(i + 1);
        }
    }

    private NameFieldEntry CreateEntry(string tag)
    {
        var entry = new NameFieldEntry(tag, SampleFor(tag));
        entry.TagChanged += OnEntryTagChanged;
        return entry;
    }

    /// <summary>选中一行：只有选中后「拾取到本行」才知道要往哪一行追加字段。</summary>
    private void SelectRow(NameFieldEntry? entry)
    {
        if (ReferenceEquals(_selectedEntry, entry))
        {
            return;
        }

        _selectedEntry?.SetSelected(false);
        _selectedEntry = entry;
        entry?.SetSelected(true);
    }

    /// <summary>字段变化后统一收尾：按新字段重建/同步列表 → 通知面板（持久化 + 重算文件名 + 刷新清单）。</summary>
    private void Commit()
    {
        ReloadFromTags();
        _fieldsChanged?.Invoke();
    }

    // ── 编辑 ──

    /// <summary>
    /// 在列表输入框里直接改字段后的收尾：清空视为删除该字段，重名回滚并提示，
    /// 其余写回字段集合并立即重算文件名。改成不含汉字/字母/数字的内容即成为固定文本（横线等）；
    /// 用「/」分隔可让一行放多个字段（各占一段）。
    /// </summary>
    private void OnEntryTagChanged(NameFieldEntry entry, string previousTag)
    {
        if (_syncing || _entries.IndexOf(entry) < 0)
        {
            return;
        }

        var tag = entry.Tag;
        if (tag.Length == 0)
        {
            RemoveEntry(entry);
            SetStatus($"文件命名：已移除空字段（原「{FileNameFieldSpec.DisplayRow(previousTag)}」）。");
            return;
        }

        var tagIndex = ResolveTagIndex(entry, previousTag);

        // 固定文本（横线等）可以重复出现，只有同名字段才需要挡重名；
        // 一行挂多个字段时逐个候选查重（同一字段出现在两行会让文件名里重复出现同一段文字）。
        var others = CollectCandidatesExcept(tagIndex);
        var duplicated = FileNameFieldSpec.SplitCandidates(tag)
            .Any(candidate => !FileNameFieldSpec.IsLiteral(candidate) && others.Contains(candidate));
        if (duplicated)
        {
            // 重名会让同一属性在文件名里出现两次，直接回滚到改动前的名字。
            _syncing = true;
            try
            {
                entry.Tag = previousTag;
                entry.SyncDisplay();
            }
            finally
            {
                _syncing = false;
            }

            SetStatus($"文件命名：字段「{FileNameFieldSpec.DisplayRow(tag)}」已存在，已保留「{FileNameFieldSpec.DisplayRow(previousTag)}」。");
            return;
        }

        if (tagIndex >= 0)
        {
            _tags[tagIndex] = tag;
        }
        else
        {
            _tags.Add(tag);
        }

        SetStatus($"文件命名：{PreviewSummaryText()}（已改名，文件名同步刷新）");
        Commit();
    }

    /// <summary>收集除指定行以外所有行的候选字段（用于改字段名时查重）。</summary>
    private HashSet<string> CollectCandidatesExcept(int skipIndex)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < _tags.Count; i++)
        {
            if (i == skipIndex)
            {
                continue;
            }

            foreach (var candidate in FileNameFieldSpec.SplitCandidates(_tags[i]))
            {
                set.Add(candidate);
            }
        }

        return set;
    }

    /// <summary>
    /// 找出某个列表项在字段集合里的下标：优先按列表项位置对应（固定文本可以重复，只能靠位置认），
    /// 位置对不上时再按改名前的字段名找；都找不到返回 -1。
    /// </summary>
    private int ResolveTagIndex(NameFieldEntry entry, string previousTag)
    {
        var index = _entries.Count == _tags.Count ? _entries.IndexOf(entry) : -1;
        if (index >= 0 && index < _tags.Count
            && string.Equals(_tags[index], previousTag, StringComparison.OrdinalIgnoreCase))
        {
            return index;
        }

        return _tags.FindIndex(existing =>
            string.Equals(existing, previousTag, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>删除一个字段（右键菜单 / 输入框被清空时调用）。固定文本项只删点中的那一条。</summary>
    private void RemoveEntry(NameFieldEntry entry)
    {
        var index = _entries.IndexOf(entry);
        if (index < 0)
        {
            return;
        }

        var tag = entry.Tag;
        if (ReferenceEquals(_selectedEntry, entry))
        {
            _selectedEntry = null;
        }

        _syncing = true;
        try
        {
            _entries.RemoveAt(index);
            // 列表项与字段集合按位置一一对应；手动新增还没提交的空框会多出一个，越界时自然跳过。
            if (index < _tags.Count
                && string.Equals(_tags[index], tag, StringComparison.OrdinalIgnoreCase))
            {
                _tags.RemoveAt(index);
            }
            else if (tag.Length > 0)
            {
                _tags.RemoveAll(existing => string.Equals(existing, tag, StringComparison.OrdinalIgnoreCase));
            }

            _samples.Remove(tag);
            entry.SetSelected(false);
            UpdatePlaceholder();
            UpdateIndexes();
        }
        finally
        {
            _syncing = false;
        }

        if (tag.Length > 0)
        {
            Commit();
        }
    }

    private void RemoveField_Click(object sender, RoutedEventArgs e)
    {
        if (_tags.Count == 0 && _entries.Count == 0)
        {
            SetStatus("尚未设置文件名字段：点「拾取属性文字」到图面上点选 / 框选属性文字，或右键「添加字段 / 增加图幅 / 增加分隔文本」。");
            return;
        }

        var entry = ResolveEntry(sender);
        if (entry == null)
        {
            SetStatus("请在字段输入框上右键，选择「删除该字段」。");
            return;
        }

        var tag = entry.Tag;
        RemoveEntry(entry);
        if (tag.Length > 0)
        {
            SetStatus($"文件命名：已删除字段「{FileNameFieldSpec.DisplayRow(tag)}」，现为 {FormatTagSummary()}。");
        }
    }

    private void MoveFieldUp_Click(object sender, RoutedEventArgs e) => MoveField(sender, -1);

    private void MoveFieldDown_Click(object sender, RoutedEventArgs e) => MoveField(sender, 1);

    /// <summary>调整字段顺序（顺序决定文件名中各段的先后），并立即重算文件名。</summary>
    private void MoveField(object sender, int delta)
    {
        var entry = ResolveEntry(sender);
        var tag = entry?.Tag ?? "";
        if (entry == null || tag.Length == 0)
        {
            return;
        }

        var index = ResolveTagIndex(entry, tag);
        var target = index + delta;
        if (index < 0 || target < 0 || target >= _tags.Count)
        {
            SetStatus(delta < 0 ? "「" + FileNameFieldSpec.DisplayRow(tag) + "」已经是第一个字段。" : "「" + FileNameFieldSpec.DisplayRow(tag) + "」已经是最后一个字段。");
            return;
        }

        _tags.RemoveAt(index);
        _tags.Insert(target, tag);
        SetStatus($"文件命名：顺序已调整为 {FormatTagSummary()}（文件名同步刷新）");
        Commit();
    }

    /// <summary>从右键菜单取回被点击的字段项（ContextMenu 不在可视树内，需经 PlacementTarget 取 DataContext）。</summary>
    private static NameFieldEntry? ResolveEntry(object sender)
    {
        // 「增加分隔文本」是级联菜单，子 MenuItem 的逻辑父是父 MenuItem 而非 ContextMenu，
        // 所以要沿逻辑树往上找到 ContextMenu，再按 PlacementTarget 认出被右键的那一行。
        if (sender is not MenuItem item)
        {
            return null;
        }

        DependencyObject? node = item;
        while (node != null)
        {
            if (node is ContextMenu menu)
            {
                return menu.PlacementTarget is FrameworkElement target
                    ? target.DataContext as NameFieldEntry
                    : null;
            }

            node = LogicalTreeHelper.GetParent(node);
        }

        return null;
    }

    /// <summary>点一行：选中它（高亮），随后可用「拾取到本行」把新属性追加进该行。</summary>
    private void Row_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        => SelectRow((sender as FrameworkElement)?.DataContext as NameFieldEntry);

    /// <summary>右键时一并选中该行，右键菜单里的「追加拾取到本行 / 拆成独立行」才知道作用于哪一行。</summary>
    private void Row_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        => SelectRow((sender as FrameworkElement)?.DataContext as NameFieldEntry);

    /// <summary>手动新增一个空字段项，并把光标直接放进它的输入框。</summary>
    private void AddField_Click(object sender, RoutedEventArgs e)
    {
        var entry = CreateEntry("");
        // 新增的行要手动输入字段名：先把字段名列显示出来，否则输入框看不见、没法输入。
        ShowFieldName = true;
        _syncing = true;
        try
        {
            EnsureItemsBound();
            _entries.Add(entry);
            UpdatePlaceholder();
            UpdateIndexes();
        }
        finally
        {
            _syncing = false;
        }

        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (FindEditor(entry) is TextBox box)
            {
                box.Focus();
                box.SelectAll();
            }
        }), DispatcherPriority.Loaded);

        SetStatus("文件命名：输入属性名后回车即可（与图纸中属性块的属性名一致，不区分大小写）；"
                  + "用「/」分隔可放多个字段，各占一段都拼进文件名（如 图号/图名）；"
                  + "输入「图幅」取该图纸识别出的图幅；只输入横线、斜杠这类符号则按固定文本拼进文件名。");
    }

    /// <summary>
    /// 「增加分隔文本 → 横线」：在点中的字段之后（在空白处右键时追加到末尾）插入一条固定文本「-」。
    /// 固定文本自己就是分隔符，它后面那一段不再补连接符，用前移/后移可挪到想要的位置；
    /// 想换成别的符号时勾「显示字段名」直接改这一行的文字即可。
    /// </summary>
    private void AddDashField_Click(object sender, RoutedEventArgs e)
        => InsertLiteral(FileNameFieldSpec.DefaultLiteral, ResolveEntry(sender));

    private void AddUnderscoreField_Click(object sender, RoutedEventArgs e)
        => InsertLiteral("_", ResolveEntry(sender));

    private void AddDotField_Click(object sender, RoutedEventArgs e)
        => InsertLiteral(".", ResolveEntry(sender));

    private void AddSharpField_Click(object sender, RoutedEventArgs e)
        => InsertLiteral("#", ResolveEntry(sender));

    /// <summary>
    /// 「增加分隔文本 → 自定义…」：先插入一条横线占位，随即展开字段名列并把光标放进这一行（全选），
    /// 直接输入想要的符号回车即可 —— 任意不含汉字/字母/数字的符号都行（如 _ # . ~ + -）。
    /// ❗「/」会被当成"同一行放多个字段"的分隔符、空格会被丢掉，都当不了固定文本；
    /// 文件名里不能用的 \ : * ? " &lt; &gt; | 也别填。
    /// </summary>
    private void AddCustomLiteralField_Click(object sender, RoutedEventArgs e)
        => InsertLiteral(FileNameFieldSpec.DefaultLiteral, ResolveEntry(sender), startEdit: true);

    /// <summary>
    /// 底部「增加分隔文本」按钮：弹出符号菜单（与列表右键里的同一组命令）。
    /// 按钮菜单没有绑定某一行，插入位置一律是列表末尾；要插到某一段之后请在那一行上右键。
    /// </summary>
    private void AddLiteralMenu_Click(object sender, RoutedEventArgs e)
    {
        if (_addLiteralButton?.ContextMenu is not ContextMenu menu)
        {
            return;
        }

        // 手动打开时要自己指定挂靠位置，否则菜单会落在屏幕左上角。
        menu.Placement = PlacementMode.Bottom;
        menu.PlacementTarget = _addLiteralButton;
        menu.IsOpen = true;
    }

    /// <summary>
    /// 「增加图幅」：在点中的字段之后（在空白处右键时追加到末尾）插入保留字段「图幅」，
    /// 每张图纸各取自己识别出的图幅（A2、A1+1∕2 等），与图框块面板文件名占位符 T 同口径。
    /// </summary>
    private void AddPaperField_Click(object sender, RoutedEventArgs e)
        => InsertPaper(ResolveEntry(sender));

    /// <summary>插入「图幅」保留字段；列表中已有该项时只提示，不重复添加。</summary>
    private void InsertPaper(NameFieldEntry? after)
    {
        var field = FileNameFieldSpec.PaperFieldName;
        if (_tags.Contains(field, StringComparer.OrdinalIgnoreCase))
        {
            SetStatus($"文件命名：「{field}」已在列表中（每张图纸各取自己识别出的图幅，无需重复添加）。");
            return;
        }

        var index = _tags.Count;
        if (after != null)
        {
            var entryIndex = _entries.IndexOf(after);
            if (entryIndex >= 0)
            {
                index = entryIndex + 1;
            }
        }

        _tags.Insert(Math.Max(0, Math.Min(index, _tags.Count)), field);
        // 字段集合变了，Commit 里的 ReloadFromTags 会按新顺序重建列表项。
        Commit();
        SetStatus($"文件命名：已插入「{field}」（按各图纸识别出的图幅取值，"
                  + "加长图按设置窗里的图幅名格式输出；右键可前移 / 后移 / 删除）。");
    }

    /// <summary>
    /// 在指定字段之后（<paramref name="after"/> 为 null 时追加到末尾）插入一条固定文本项。
    /// <paramref name="startEdit"/> 为 true 时同时展开「字段名」列并把光标放进新行（全选），
    /// 便于立刻把默认的横线改成别的符号。
    /// </summary>
    private void InsertLiteral(string text, NameFieldEntry? after, bool startEdit = false)
    {
        var literal = (text ?? "").Trim();
        if (literal.Length == 0)
        {
            return;
        }

        var index = _tags.Count;
        if (after != null)
        {
            var entryIndex = _entries.IndexOf(after);
            if (entryIndex >= 0)
            {
                index = entryIndex + 1;
            }
        }

        index = Math.Max(0, Math.Min(index, _tags.Count));
        _tags.Insert(index, literal);
        if (startEdit)
        {
            // 要手工替换成别的符号：先把字段名列显示出来，否则输入框不可见、聚焦无效。
            ShowFieldName = true;
        }

        // 字段集合变了，Commit 里的 ReloadFromTags 会按新顺序重建列表项。
        Commit();

        if (startEdit && index < _entries.Count)
        {
            var inserted = _entries[index];
            Dispatcher.BeginInvoke(new Action(() => FocusEditorOf(inserted)), DispatcherPriority.Loaded);
        }

        SetStatus(startEdit
            ? $"文件命名：已插入固定文本「{literal}」，直接输入想要的符号后回车即可"
              + "（任意不含汉字/字母/数字的符号都行，如 _ # . ~ +；「/」会被当成同行多字段的分隔符、空格会被丢掉）。"
            : $"文件命名：已插入固定文本「{literal}」（它本身就是分隔符，后面一段不再补连接符；"
              + "右键可前移 / 后移 / 删除，想换成别的符号请勾「显示字段名」后直接改这一行的文字）。");
    }

    /// <summary>
    /// 「拆成独立行」：把一个属性块的多个字段拆成各自一行。
    /// 文件名不变（这些字段本来各占一段、都拼进文件名），拆开只是为了单独排序 / 删除 / 移动。
    /// </summary>
    private void SplitRow_Click(object sender, RoutedEventArgs e)
    {
        var entry = ResolveEntry(sender);
        if (entry == null)
        {
            return;
        }

        var index = ResolveTagIndex(entry, entry.Tag);
        if (index < 0 || index >= _tags.Count)
        {
            return;
        }

        var candidates = FileNameFieldSpec.SplitCandidates(_tags[index]);
        if (candidates.Count <= 1)
        {
            SetStatus("文件命名：本行只有一个字段，无需拆分。");
            return;
        }

        _tags.RemoveAt(index);
        for (var i = candidates.Count - 1; i >= 0; i--)
        {
            _tags.Insert(index, candidates[i]);
        }

        Commit();
        SetStatus($"文件命名：本行的 {candidates.Count} 个字段已拆成 {candidates.Count} 行，"
                  + "文件名不变（每行一个字段，各自成一段；右键可再前后移调整顺序）。");
    }

    /// <summary>在列表里找到某个字段项对应的输入框，用于手动添加后自动聚焦。</summary>
    private TextBox? FindEditor(NameFieldEntry entry)
    {
        if (_nameFieldList.ItemContainerGenerator.ContainerFromItem(entry) is not ContentPresenter presenter)
        {
            return null;
        }

        presenter.ApplyTemplate();
        return presenter.ContentTemplate?.FindName("Editor", presenter) as TextBox;
    }

    /// <summary>点进某个字段：切成可编辑的字段名（属性名 / 块名|属性名）并全选，便于直接改写。</summary>
    private void Editor_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
        if (sender is TextBox { DataContext: NameFieldEntry entry } box)
        {
            BeginEdit(entry, box);
        }
    }

    /// <summary>
    /// 已经聚焦的输入框再被点一次不会再触发焦点事件，这里补一次切换；
    /// 否则回车回到效果显示后就再也点不回编辑态（输入框只读，不会误改命名效果文字）。
    /// </summary>
    private void Editor_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is TextBox { DataContext: NameFieldEntry entry } box && !entry.IsEditing)
        {
            BeginEdit(entry, box);
        }
    }

    private void BeginEdit(NameFieldEntry entry, TextBox box)
    {
        if (entry.IsEditing)
        {
            return;
        }

        entry.BeginEdit();
        Dispatcher.BeginInvoke(new Action(() =>
        {
            box.SelectionStart = 0;
            box.SelectionLength = box.Text.Length;
        }), DispatcherPriority.Input);
    }

    /// <summary>右键「改字段名」：与点进输入框等效。</summary>
    private void EditField_Click(object sender, RoutedEventArgs e)
    {
        var entry = ResolveEntry(sender);
        if (entry == null)
        {
            return;
        }

        if (!ShowFieldName)
        {
            // 字段名列默认隐藏：先把它显示出来，否则输入框不可见、聚焦无效（等布局刷新完再聚焦）。
            ShowFieldName = true;
            Dispatcher.BeginInvoke(new Action(() => FocusEditorOf(entry)), DispatcherPriority.Loaded);
            return;
        }

        FocusEditorOf(entry);
    }

    /// <summary>定位到某行的字段名输入框并进入编辑（找不到就静默返回）。</summary>
    private void FocusEditorOf(NameFieldEntry entry)
    {
        if (FindEditor(entry) is TextBox box)
        {
            box.Focus();
            BeginEdit(entry, box);
        }
    }

    private void Editor_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (sender is not TextBox box || box.DataContext is not NameFieldEntry entry)
        {
            return;
        }

        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            // 先把输入框内容提交成字段名，再切回命名效果显示（顺序不能反，否则改动会被刷掉）。
            box.GetBindingExpression(TextBox.TextProperty)?.UpdateSource();
            entry.CommitEditor();
            if (entry.Tag.Length == 0)
            {
                // 只按了回车却没输入名字：当作没添加，清掉这个空框。
                RemoveEntry(entry);
                return;
            }

            entry.EndEdit();
            return;
        }

        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            // 放弃本次输入：不提交输入框内容，直接回到命名效果显示。
            if (entry.Tag.Length == 0)
            {
                RemoveEntry(entry);
                return;
            }

            // 撤回显示文本（把输入框里没提交的改动丢掉）。
            entry.SyncDisplay();
            entry.EndEdit();
        }
    }

    /// <summary>
    /// 焦点离开时收尾：必须先把输入框里的改动提交成字段名再切回效果显示
    /// （绑定是 LostFocus 触发，反过来的话会读到已刷新的文本而丢掉改动）；空字段项直接移除。
    /// </summary>
    private void Editor_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
        if (sender is not TextBox { DataContext: NameFieldEntry entry } box)
        {
            return;
        }

        if (entry.IsEditing)
        {
            box.GetBindingExpression(TextBox.TextProperty)?.UpdateSource();
            entry.CommitEditor();
            entry.EndEdit();
        }

        if (entry.Tag.Length == 0)
        {
            RemoveEntry(entry);
        }
    }

    private void ClearFields_Click(object sender, RoutedEventArgs e)
    {
        if (_tags.Count == 0)
        {
            return;
        }

        _tags.Clear();
        _samples.Clear();
        _selectedEntry = null;
        Commit();
        SetStatus("文件命名：已清空全部字段，文件名回到默认规则。");
    }

    /// <summary>
    /// 「拾取属性文字」：本次拾取到的属性<b>按所属属性块分行</b>（一个块一行，同块的多个属性各占一段、
    /// 都拼进文件名）；隐藏本窗回到图面拾取（面板自己也会让开图面），
    /// 拾取完刷新列表并把新字段写回面板。
    /// </summary>
    private void Pick_Click(object sender, RoutedEventArgs e) => RunPick(-1, -1);

    /// <summary>
    /// 「拾取到本行」：本次拾取的属性按所属块分组，<b>第一个块的属性追加进选中行</b>（各占一段拼进文件名），
    /// 其余块各自新建一行。既可由底部按钮触发（用当前选中的行），也可由行内右键菜单触发（作用于右键的那一行）。
    /// </summary>
    private void PickIntoRow_Click(object sender, RoutedEventArgs e)
    {
        var entry = sender is MenuItem ? ResolveEntry(sender) : _selectedEntry;
        if (entry == null)
        {
            SetStatus("请先点表格里的一行选中它，再点「拾取到本行」：拾取到的属性会追加到这一行"
                      + "（一行的多个字段各占一段，都拼进文件名）。");
            return;
        }

        var index = _entries.IndexOf(entry);
        if (index < 0)
        {
            return;
        }

        SelectRow(entry);
        SetStatus("文件命名：已选中该行，接下来拾取到的属性会追加进这一行。");
        RunPick(index, index);
    }

    /// <summary>
    /// 回到图面拾取属性文字。
    /// </summary>
    /// <param name="targetRowIndex">要写入的行下标（-1 = 新建一行）。</param>
    /// <param name="reselectIndex">拾取结束后要重新选中的行下标（&lt;0 表示不重选）。</param>
    private void RunPick(int targetRowIndex, int reselectIndex)
    {
        if (_pickProvider == null)
        {
            return;
        }

        CadWindowFocus.HideForCadInput(this);
        string status;
        try
        {
            status = _pickProvider(targetRowIndex) ?? "";
        }
        finally
        {
            // 先让面板恢复、再让本窗恢复，最后本窗在最前面，用户能立刻看到拾取结果。
            CadWindowFocus.RestoreDialog(this);
        }

        Commit();
        if (reselectIndex >= 0 && reselectIndex < _entries.Count)
        {
            // 追加字段后该行的字段名变了，列表会被重建（选中状态丢失），这里按行次重新选中。
            SelectRow(_entries[reselectIndex]);
        }

        if (status.Length > 0)
        {
            SetStatus(status);
        }
    }

    /// <summary>
    /// 「确认」：字段改动在编辑时就已即时生效，这里再落盘一次并给出结果提示，然后关闭。
    /// </summary>
    private void Confirm_Click(object sender, RoutedEventArgs e)
    {
        _fieldsChanged?.Invoke();
        SetStatus(_tags.Count == 0
            ? "文件命名：未设置字段，文件名回到默认规则。"
            : $"文件命名：{PreviewSummaryText()}（已确认，清单里的文件名按此规则输出）");
        Close();
    }

    /// <summary>
    /// 「取消」：只关闭本窗口。字段改动（拾取 / 改名 / 排序 / 删除 / 清空）在编辑时就已即时生效并写入设置，
    /// 点「取消」<b>不会</b>撤回到打开本窗口前的状态——要撤消请在这里手动改回去。
    /// </summary>
    private void Cancel_Click(object sender, RoutedEventArgs e) => Close();
}
