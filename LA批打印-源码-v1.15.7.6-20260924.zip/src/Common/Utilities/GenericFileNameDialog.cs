using System;
using System.Collections.Generic;
using System.Windows;
#if AUTOCAD
using Autodesk.AutoCAD.ApplicationServices;
#if ACAD_CORE
using CadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;
#else
using CadApp = Autodesk.AutoCAD.ApplicationServices.Application;
#endif
#else
using ZwSoft.ZwCAD.ApplicationServices;
using CadApp = ZwSoft.ZwCAD.ApplicationServices.Application;
#endif

namespace ZwcadBatchPlot;

/// <summary>
/// 「通用打印文件命名」的独立入口：给没有打开通用型面板的场景用
/// （图框块面板的设置窗、<c>ZBP_SETTINGS</c> 命令），弹出与通用型面板「文件命名」按钮<b>完全相同</b>的对话框。
/// <para>
/// 字段列表和通用型面板一样取自 <see cref="AppSettings.RectangleFileNameFields"/>，
/// 改动即时写回设置，所以从哪个入口改都是一份数据。
/// 没有图纸上下文时（<paramref name="hostToHide"/> 为 null）预览只显示拾取到的示例值，
/// 这与图框块面板的用法一致：它的图框作业不带属性值，本来也取不到通用型字段的值。
/// </para>
/// </summary>
internal static class GenericFileNameDialog
{
    /// <summary>已经打开的命名对话框；同一时刻只保留一个（字段列表本来就是同一份）。</summary>
    private static FileNameFieldForm? _open;

    /// <summary>
    /// 弹出「文件命名」对话框。
    /// </summary>
    /// <param name="settings">要编辑的那份设置（字段列表写在它的 <c>RectangleFileNameFields</c> 上）。</param>
    /// <param name="hostToHide">拾取属性文字时要临时让开图面的宿主窗口（面板 / 设置窗）；没有可传 null。</param>
    /// <param name="statusSink">把状态文字同步到宿主的界面上（如面板状态栏）；不传只留在对话框里。</param>
    public static void Show(AppSettings settings, Window? hostToHide, Action<string>? statusSink)
    {
        if (_open is { IsVisible: true } existing)
        {
            existing.Activate();
            return;
        }

        var fields = new GenericFileNameFieldSet(
            settings,
            new List<string>(),
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase));
        fields.Load(settings.RectangleFileNameFields);

        var dialog = new FileNameFieldForm(
            fields.Fields,
            fields.Samples,
            () => fields.BuildPreviews(null),
            rowIndex => PickFields(fields, hostToHide, rowIndex),
            fields.Persist,
            statusSink);
        dialog.Closed += (_, _) =>
        {
            _open = null;
            if (hostToHide is { IsVisible: true })
            {
                // 关掉子窗后把宿主拉回前台，别让焦点落到别的进程。
                CadWindowFocus.RestoreDialog(hostToHide);
            }
        };
        _open = dialog;
        CadDialog.ShowModeless(dialog);
    }

    /// <summary>
    /// 回图面拾取属性文字（点中取该文字、回车改框选、可反复追加）：拾取前让开宿主窗口，
    /// 结束后恢复；返回状态文字（空串 = 什么都没拾到，此时保留对话框原来的提示）。
    /// <para>
    /// <paramref name="rowIndex"/>：&lt;0 = 本次拾取到的属性<b>按所属属性块分行</b>（一个块一行，
    /// 同块的多个属性各占一段、都拼进文件名）；&gt;=0 = 第一个块的属性追加进该行，其余块仍各自新建一行。
    /// </para>
    /// </summary>
    private static string PickFields(GenericFileNameFieldSet fields, Window? hostToHide, int rowIndex)
    {
        List<PickedAttributeName> picked;
        int skipped;
        if (hostToHide != null)
        {
            CadWindowFocus.HideForCadInput(hostToHide);
        }
        else
        {
            CadWindowFocus.ActivateCadWindow();
        }

        try
        {
            picked = AttributeNameFieldPicker.Pick(GetActiveDocument(), out skipped);
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(
                "拾取属性文字失败: " + ex.Message,
                "文件命名",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            return "";
        }
        finally
        {
            if (hostToHide != null)
            {
                CadWindowFocus.RestoreDialog(hostToHide);
            }
        }

        // 一个属性块 = 一行：本次拾取到的属性按所属块分组，同块的多个属性放在一行、各占一段都拼进文件名，
        // 不同块各自成行；「拾取到本行」时第一个块写进指定行。
        var added = fields.AddPickedByBlock(picked, rowIndex);

        if (picked.Count == 0 && skipped == 0)
        {
            // 直接回车/ESC 结束且没有拾取到任何东西：保持原状态提示，不刷掉用户看到的信息。
            return "";
        }

        var reusedHint = picked.Count > added ? $"，{picked.Count - added} 个已在列表中" : "";
        var skippedHint = skipped > 0 ? $"，跳过 {skipped} 次空拾取" : "";
        return fields.Fields.Count == 0
            ? $"文件命名：未拾取到属性字段{skippedHint}"
            : $"文件命名：{fields.EffectSummary(null)}（本次新增 {added} 个字段{reusedHint}{skippedHint}） | 文件名已按字段刷新";
    }

    private static Document? GetActiveDocument()
    {
        try
        {
            // 不缓存文档引用：设置窗打开期间用户可能已切换图纸。
            return CadApp.DocumentManager.MdiActiveDocument;
        }
        catch
        {
            return null;
        }
    }
}
