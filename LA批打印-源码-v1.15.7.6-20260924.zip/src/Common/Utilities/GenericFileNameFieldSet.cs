using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZwcadBatchPlot;

/// <summary>
/// 通用型批量打印「文件命名」的字段集合：字段列表 + 拾取到的示例值 + 按图纸取值 / 拼命名效果。
/// <para>
/// 字段列表与示例值都按<b>引用共享</b>给「文件命名」对话框（<c>FileNameFieldForm</c>），
/// 所以这里持有的就是面板 / 设置窗正在用的那一份，对话框里的增删改会立刻反映到两边。
/// 持久化位置是 <see cref="AppSettings.RectangleFileNameFields"/>，两个面板与设置窗共用同一份，
/// 这也是「设置 - 文件名 - 通用打印文件命名」与通用型面板上的「文件命名」按钮能"关联"的原因。
/// </para>
/// <para>
/// 字段列表里的<b>一项 = 文件名的一段 = 一个属性块</b>：拾取到的属性按<b>所属属性块</b>分行
/// （见 <c>AddPickedByBlock</c>），一段里可以挂该块的多个候选字段（<c>FileNameFieldSpec.CandidateSeparator</c>
/// 分隔），各占一段、都拼进文件名。
/// </para>
/// </summary>
internal sealed class GenericFileNameFieldSet
{
    private readonly AppSettings _settings;
    private readonly List<string> _fields;
    private readonly Dictionary<string, string> _samples;

    /// <param name="settings">持有该字段列表的设置对象（取值要用它的连接符与加长图图名格式）。</param>
    /// <param name="fields">字段列表（按引用共享给对话框），顺序即文件名中各段的排列顺序。</param>
    /// <param name="samples">示例值字典（按引用共享；仅作列表悬停提示与预览兜底，不持久化）。</param>
    public GenericFileNameFieldSet(AppSettings settings, List<string> fields, Dictionary<string, string> samples)
    {
        _settings = settings;
        _fields = fields;
        _samples = samples;
    }

    /// <summary>字段列表（顺序即文件名中各段的排列顺序），每项可含多个候选字段。</summary>
    public List<string> Fields => _fields;

    /// <summary>字段的示例值字典（拾取时记下各字段取到的文字）。</summary>
    public Dictionary<string, string> Samples => _samples;

    /// <summary>字段摘要（如「图号 + 图名 / 标题 + 图幅」），还没设置时返回「未设置」。</summary>
    public string FieldSummary()
        => _fields.Count == 0 ? "未设置" : string.Join(" + ", _fields.Select(FileNameFieldSpec.DisplayRow));

    /// <summary>
    /// 从设置恢复字段列表（保留本次会话已有字段的示例值）：每行按候选规整（去空白、丢空项、去重），
    /// 再按整行保序去重（不区分大小写），固定文本项（横线等）允许重复出现。
    /// </summary>
    public void Load(IEnumerable<string>? stored)
    {
        var loaded = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var field in stored ?? Enumerable.Empty<string>())
        {
            var row = FileNameFieldSpec.JoinCandidates(FileNameFieldSpec.SplitCandidates(field));
            if (row.Length == 0)
            {
                continue;
            }

            if (!FileNameFieldSpec.IsLiteral(row) && !seen.Add(row))
            {
                continue;
            }

            loaded.Add(row);
        }

        _fields.Clear();
        _fields.AddRange(loaded);

        // 示例值只保留仍是某个候选字段的键，避免列表提示与实际字段不一致。
        var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in _fields)
        {
            foreach (var candidate in FileNameFieldSpec.SplitCandidates(row))
            {
                keys.Add(candidate);
            }
        }

        foreach (var stale in _samples.Keys.Where(key => !keys.Contains(key)).ToList())
        {
            _samples.Remove(stale);
        }
    }

    /// <summary>
    /// 加入一个文件名字段（独占一行）；该字段已出现在任何一行里时只更新示例值并返回 false。
    /// 字段文本为「属性名」或「块名|属性名」（同名属性来自不同属性块时各自成一项）。
    /// </summary>
    public bool AddPicked(PickedAttributeName field)
    {
        var key = FileNameFieldSpec.Compose(field.BlockName, field.Tag);
        if (key.Length == 0)
        {
            return false;
        }

        if (!string.IsNullOrWhiteSpace(field.Sample))
        {
            _samples[key] = field.Sample.Trim();
        }

        if (ContainsCandidate(key))
        {
            return false;
        }

        _fields.Add(key);
        return true;
    }

    /// <summary>
    /// 把本次拾取到的属性<b>按属性块分行</b>追加：<b>一个属性块 = 一行</b>，
    /// 行内该块的多个属性各占一段、都拼进文件名，不同块的属性不混在同一行。
    /// <para>
    /// 该块在列表里已经有行（行内已含它的属性）时把新属性追加到那一行；
    /// <paramref name="firstRowIndex"/> 指定了行时，第一个块优先写进那一行（「拾取到本行」），
    /// 其余块仍各自新建一行。
    /// </para>
    /// </summary>
    /// <param name="picked">本次拾取到的属性（顺序即各块的成行顺序）。</param>
    /// <param name="firstRowIndex">第一个块要写进的行下标（&lt;0 = 该块自己新建一行）。</param>
    /// <returns>真正新增的字段个数（已存在的不重复添加）。</returns>
    public int AddPickedByBlock(IEnumerable<PickedAttributeName> picked, int firstRowIndex)
    {
        var groups = GroupByOwnerBlock(picked);
        var added = 0;
        var firstGroup = true;
        foreach (var group in groups)
        {
            var keys = CollectNewKeys(group);
            if (keys.Count == 0)
            {
                // 这个块的属性全都在列表里了，不再新增行。
                continue;
            }

            var rowIndex = firstGroup && firstRowIndex >= 0 && firstRowIndex < _fields.Count
                ? firstRowIndex
                : FindRowOfBlock(group);
            if (rowIndex >= 0 && rowIndex < _fields.Count)
            {
                AppendKeysToRow(rowIndex, keys);
            }
            else
            {
                _fields.Add(FileNameFieldSpec.JoinCandidates(keys));
            }

            added += keys.Count;
            firstGroup = false;
        }

        return added;
    }

    /// <summary>
    /// 按属性<b>实际所属的属性块</b>分组：<b>一个块一组</b>，组的先后按组内第一个属性在拾取结果里的先后。
    /// 取不到块名的属性（被单独选中的孤立属性文字）各自单独成一组，避免把不相干的属性混进同一行。
    /// </summary>
    private static List<List<PickedAttributeName>> GroupByOwnerBlock(IEnumerable<PickedAttributeName> picked)
    {
        var groups = new List<List<PickedAttributeName>>();
        var indexByBlock = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var anonymous = 0;
        foreach (var field in picked ?? Enumerable.Empty<PickedAttributeName>())
        {
            var block = (field.OwnerBlock ?? "").Trim();
            if (block.Length == 0)
            {
                // 块名取不到时用一个不会与真块名冲突的临时键（真块名不会是「#数字」）。
                block = "#" + anonymous++;
            }

            if (!indexByBlock.TryGetValue(block, out var index))
            {
                index = groups.Count;
                indexByBlock[block] = index;
                groups.Add(new List<PickedAttributeName>());
            }

            groups[index].Add(field);
        }

        return groups;
    }

    /// <summary>找出已经含有该块属性的行（该块还没进列表时返回 -1）。</summary>
    private int FindRowOfBlock(List<PickedAttributeName> group)
    {
        var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var field in group)
        {
            var key = FileNameFieldSpec.Compose(field.BlockName, field.Tag);
            if (key.Length > 0)
            {
                keys.Add(key);
            }
        }

        if (keys.Count == 0)
        {
            return -1;
        }

        return _fields.FindIndex(row =>
            FileNameFieldSpec.SplitCandidates(row).Any(candidate => keys.Contains(candidate)));
    }

    /// <summary>把若干字段追加进指定行的候选（排在该行原有字段之后）。</summary>
    private void AppendKeysToRow(int rowIndex, List<string> keys)
    {
        var merged = FileNameFieldSpec.SplitCandidates(_fields[rowIndex]);
        foreach (var key in keys)
        {
            if (!merged.Contains(key, StringComparer.OrdinalIgnoreCase))
            {
                merged.Add(key);
            }
        }

        _fields[rowIndex] = FileNameFieldSpec.JoinCandidates(merged);
    }

    /// <summary>
    /// 拾取到的属性 → 尚未出现在任何一行里的字段（按拾取顺序，去重），顺带记下示例值。
    /// </summary>
    private List<string> CollectNewKeys(IEnumerable<PickedAttributeName> picked)
    {
        var keys = new List<string>();
        foreach (var field in picked ?? Enumerable.Empty<PickedAttributeName>())
        {
            var key = FileNameFieldSpec.Compose(field.BlockName, field.Tag);
            if (key.Length == 0)
            {
                continue;
            }

            if (!string.IsNullOrWhiteSpace(field.Sample))
            {
                _samples[key] = field.Sample.Trim();
            }

            // 同一字段出现在两行会让同一段文字在文件名里出现两次，这里一律不重复添加。
            if (ContainsCandidate(key) || keys.Contains(key, StringComparer.OrdinalIgnoreCase))
            {
                continue;
            }

            keys.Add(key);
        }

        return keys;
    }

    /// <summary>该字段是否已经出现在字段列表的某一行里（含该行的其他字段）。</summary>
    private bool ContainsCandidate(string key)
        => _fields.Any(row =>
            FileNameFieldSpec.SplitCandidates(row).Contains(key, StringComparer.OrdinalIgnoreCase));

    /// <summary>把当前字段列表写回设置对象并落盘（对话框每次改动后调用）。</summary>
    public void Persist()
    {
        _settings.RectangleFileNameFields = _fields.ToList();
        AppSettingsStore.Save(_settings);
    }

    /// <summary>
    /// 按列表顺序解析各段；<paramref name="job"/> 为 null 时属性字段一律取不到值
    /// （固定文本项与拾取到的示例值仍然有效，供没有图纸上下文的入口用）。
    /// </summary>
    public List<NameFieldSegment> Build(PlotJob? job, bool allowSampleFallback)
        => NameFieldComposer.Build(
            _fields,
            _settings.PdfFileNameSeparator ?? "_",
            field =>
            {
                var value = ResolveValue(job, field, out var found);
                return found ? value : null;
            },
            allowSampleFallback ? _samples : null);

    /// <summary>
    /// 交给「文件命名」对话框的当前命名效果：<b>每行一个</b>（与该行的字段个数无关）。
    /// 一行的多个属性各占一段，这里把它们按段序拼成该行的文字；该行一个属性都没取到值时 HasValue=false。
    /// </summary>
    public List<NameFieldPreview> BuildPreviews(PlotJob? job)
    {
        // 段 → 行：一行的多个属性会产出多个段，先按行归拢，保证与对话框里的行数一一对应。
        var byRow = new List<List<NameFieldSegment>>();
        for (var i = 0; i < _fields.Count; i++)
        {
            byRow.Add(new List<NameFieldSegment>());
        }

        foreach (var segment in Build(job, allowSampleFallback: true))
        {
            if (segment.RowIndex >= 0 && segment.RowIndex < byRow.Count)
            {
                byRow[segment.RowIndex].Add(segment);
            }
        }

        var previews = new List<NameFieldPreview>(byRow.Count);
        foreach (var row in byRow)
        {
            var builder = new StringBuilder();
            var resolved = new List<string>();
            var hasValue = false;
            var leading = "";
            foreach (var segment in row)
            {
                if (!segment.HasValue || segment.Value.Length == 0)
                {
                    continue;
                }

                if (!hasValue)
                {
                    // 整行前面要补的连接符＝该行第一个有效段前面的那个（只交给调用方拼整串用，
                    // 本行自己显示的文字不带它，免得行首冒出一个下划线）。
                    leading = segment.LeadingSeparator;
                }
                else
                {
                    builder.Append(segment.LeadingSeparator);
                }

                builder.Append(segment.Value);
                hasValue = true;
                if (segment.ResolvedField.Length > 0)
                {
                    resolved.Add(segment.ResolvedField);
                }
            }

            previews.Add(new NameFieldPreview(
                builder.ToString(),
                hasValue,
                leading,
                string.Join(FileNameFieldSpec.CandidateDisplaySeparator, resolved)));
        }

        return previews;
    }

    /// <summary>命名效果摘要（如 IN-1-01_平面布置_A2），用于状态栏；还没取到值时退回字段名列表。</summary>
    public string EffectSummary(PlotJob? job)
    {
        var builder = new StringBuilder();
        foreach (var segment in Build(job, allowSampleFallback: true))
        {
            if (segment.HasValue && segment.Value.Length > 0)
            {
                builder.Append(segment.LeadingSeparator).Append(segment.Value);
            }
        }

        return builder.Length == 0 ? FieldSummary() : builder.ToString();
    }

    /// <summary>
    /// 取某个字段在指定图框作业里的文字；<paramref name="found"/> 表示是否取到非空值。
    /// 字段为「块名|属性名」时只认该属性块，为纯属性名时取任意属性块里的命中；
    /// 字段为保留名「图幅」时取该图纸<b>识别出的图幅</b>（与图框块面板文件名占位符 T 同口径）；
    /// 固定文本项（横线等）不取值，交给 <c>NameFieldComposer.Build</c> 原样输出。
    /// ❗传入的必须是<b>单个候选字段</b>（已用 <c>FileNameFieldSpec.SplitCandidates</c> 拆开）。
    /// </summary>
    private string ResolveValue(PlotJob? job, string field, out bool found)
    {
        found = false;
        if (job == null || FileNameFieldSpec.IsLiteral(field))
        {
            return "";
        }

        if (FileNameFieldSpec.IsPaperField(field))
        {
            // 「图幅」保留字段：按该图纸识别出的图幅取值（A2、A1+1∕2 等），
            // 加长图名格式沿用「设置窗 - 文件名页」里的配置，与占位符 T 完全一致。
            var paper = FileNameSanitizer.NormalizeLongPaperFraction(
                OutputPaperNameResolver.Resolve(job, _settings.LongPaperSnapToleranceMm),
                _settings.LongPaperNameFormat);
            if (string.IsNullOrWhiteSpace(paper))
            {
                return "";
            }

            found = true;
            return paper.Trim();
        }

        FileNameFieldSpec.Parse(field, out var blockName, out var tag);
        if (tag.Length == 0)
        {
            return "";
        }

        var value = blockName.Length > 0
            ? (job.AttributeValuesByBlock.TryGetValue(FileNameFieldSpec.ScopeKey(blockName, tag), out var scoped) ? scoped : "")
            : (job.AttributeValues.TryGetValue(tag, out var plain) ? plain : "");
        if (string.IsNullOrWhiteSpace(value))
        {
            return "";
        }

        found = true;
        return value.Trim();
    }
}
