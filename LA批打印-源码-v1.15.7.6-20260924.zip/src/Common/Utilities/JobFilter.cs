using System;
using System.Collections.Generic;
using System.Linq;

namespace ZwcadBatchPlot;

/// <summary>
/// 图纸过滤谓词（两面板共用的「过滤图纸」逻辑）。
/// 关键字支持多个值，以逗号/分号（中英文均可）分隔，任一匹配即命中（OR）。
/// </summary>
internal static class JobFilter
{
    /// <summary>把关键字字符串拆成去重后的非空关键字列表；为空返回空列表（表示不过滤）。</summary>
    public static IReadOnlyList<string> ParseKeywords(string? keyword)
    {
        if (string.IsNullOrWhiteSpace(keyword))
        {
            return new List<string>();
        }

        return keyword!
            .Split(new[] { ',', ';', '，', '；' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => s.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>
    /// 判断单个作业是否通过过滤。effectiveFileName 为通用型面板实际显示的文件名
    /// （通用型清单“文件名”列绑定的是 Row.FileName，而非 job.DisplayOutputFileName），
    /// 不传时回退到 job.DisplayOutputFileName。
    /// </summary>
    public static bool IsMatch(AppSettings settings, PlotJob job, string? effectiveFileName = null)
    {
        var keywords = ParseKeywords(settings.FilterKeyword);
        if (keywords.Count == 0)
        {
            return true;
        }

        if (settings.FilterScope == 3)
        {
            // 全部：图名/图号/文件名三者任一含任一关键字即命中。
            return ContainsAny(job.Title, keywords)
                || ContainsAny(job.DrawingNumber, keywords)
                || ContainsAny(effectiveFileName ?? job.DisplayOutputFileName, keywords);
        }

        var text = GetScopeText(settings.FilterScope, job, effectiveFileName);
        return ContainsAny(text, keywords);
    }

    /// <summary>取指定匹配范围对应的字段文本；scope=3 时回退到图名。</summary>
    public static string GetScopeText(int scope, PlotJob job, string? effectiveFileName = null)
    {
        return scope switch
        {
            0 => job.Title ?? "",
            1 => job.DrawingNumber ?? "",
            2 => effectiveFileName ?? job.DisplayOutputFileName ?? "",
            _ => job.Title ?? ""
        };
    }

    /// <summary>
    /// 取“文本列表”去重候选值：按当前匹配范围取字段文本。
    /// scope=3（全部）时把图名 / 图号 / 文件名三者的值都收进来，方便直接点选。
    /// </summary>
    /// <param name="fileNameSelector">
    /// 每个作业“实际文件名”的取值器。通用型面板清单的“文件名”列绑定的是 Row.FileName，
    /// 与 job.DisplayOutputFileName 无关；必须由面板传入该取值器，文本列表才会与打印窗口里的文件名一致。
    /// 传空时回退 job.DisplayOutputFileName（图框块面板即为此情形）。
    /// </param>
    public static IReadOnlyList<string> CollectDistinctValues(
        IReadOnlyList<PlotJob> jobs, int scope, Func<PlotJob, string?>? fileNameSelector = null)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new List<string>();
        const int maxItems = 500;
        foreach (var job in jobs)
        {
            if (scope == 3)
            {
                AddValue(result, seen, job.Title);
                AddValue(result, seen, job.DrawingNumber);
                AddValue(result, seen, ResolveFileName(job, fileNameSelector));
            }
            else
            {
                AddValue(result, seen, GetScopeText(scope, job, ResolveFileName(job, fileNameSelector)));
            }

            if (result.Count >= maxItems)
            {
                break;
            }
        }

        result.Sort(NaturalStringComparer.Instance);
        return result;
    }

    /// <summary>解析某个作业实际使用的文件名：优先用面板传入的取值器，回退 job.DisplayOutputFileName。</summary>
    private static string? ResolveFileName(PlotJob job, Func<PlotJob, string?>? fileNameSelector)
    {
        var name = fileNameSelector?.Invoke(job);
        return string.IsNullOrWhiteSpace(name) ? job.DisplayOutputFileName : name;
    }

    private static void AddValue(List<string> result, HashSet<string> seen, string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return;
        }

        if (seen.Add(value!))
        {
            result.Add(value!);
        }
    }

    private static bool ContainsAny(string? text, IReadOnlyList<string> keywords)
    {
        if (string.IsNullOrEmpty(text))
        {
            return false;
        }

        foreach (var kw in keywords)
        {
            if (text!.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }
        }

        return false;
    }
}
