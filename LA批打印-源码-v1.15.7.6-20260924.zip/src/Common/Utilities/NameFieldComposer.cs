using System;
using System.Collections.Generic;

namespace ZwcadBatchPlot;

/// <summary>
/// 通用型「文件命名」列表里的一段：固定文本项取自身，属性字段取该图纸上的属性值。
/// 原为 RectangleBatchPlotForm 的私有嵌套类型，图框块面板与设置窗的「通用打印文件命名」入口也要用，故提为共享类型。
/// 不用 <c>readonly struct</c>：Common 源码还要编译进 net45 目标，用普通类最稳。
/// <para>
/// 列表里的<b>一行 = 一个属性块</b>，行内的多个属性<b>各占一段</b>（都拼进文件名），
/// 所以一个行可能产出多个段，段里用 <see cref="RowIndex"/> 记它属于哪一行。
/// </para>
/// </summary>
internal sealed class NameFieldSegment
{
    public NameFieldSegment(string field, string resolvedField, string value, bool hasValue, string leadingSeparator, int rowIndex)
    {
        Field = field;
        ResolvedField = resolvedField;
        Value = value;
        HasValue = hasValue;
        LeadingSeparator = leadingSeparator;
        RowIndex = rowIndex;
    }

    /// <summary>本段的字段文本（属性名 /「块名|属性名」/ 固定文本）。</summary>
    public string Field { get; }

    /// <summary>本段取到值时的字段名（没取到值时为空串）。</summary>
    public string ResolvedField { get; }

    /// <summary>本段属于列表里的第几行（0 起）：一行 = 一个属性块，可能产出多个段。</summary>
    public int RowIndex { get; }

    /// <summary>参与文件名的那段文字（固定文本项即其本身）。</summary>
    public string Value { get; }

    /// <summary>本段是否参与文件名（取到了值，或本身是固定文本）。</summary>
    public bool HasValue { get; }

    /// <summary>拼在本段前面的连接符；第一段、没取到值的段、以及紧跟在固定文本后的段为空。</summary>
    public string LeadingSeparator { get; }
}

/// <summary>
/// 按「文件命名」字段列表顺序解析各段：命名效果预览与真正的文件名共用这一份实现
/// （通用型面板用它拼真实文件名，图框块面板与设置窗的「通用打印文件命名」只用它算预览），
/// 保证"对话框里看到什么就打出什么"。
/// </summary>
internal static class NameFieldComposer
{
    /// <summary>
    /// 固定文本项（手动插入的横线等）原样参与文件名、并且充当它与后面一段之间的分隔；
    /// 属性字段依次到该图纸上取值，取不到的段不参与文件名。
    /// <para>
    /// <b>一行 = 一个属性块</b>：一行里的多个属性<b>各占一段、都拼进文件名</b>
    /// （按行内顺序排列；某个属性在本图取不到值时那一段不参与）。
    /// 取不到真实值时才退回该属性拾取到的示例文字（仅命名效果预览传 <paramref name="sampleFallback"/>）。
    /// </para>
    /// </summary>
    /// <param name="fields">字段列表，顺序即文件名中各段的排列顺序；每行可含多个属性（「||」分隔）。</param>
    /// <param name="separator">参与文件名的段之间补的连接符。</param>
    /// <param name="resolveValue">取某个字段在某图纸上的文字；取不到返回 null 或空串。</param>
    /// <param name="sampleFallback">取不到值时退回本次拾取到的文字（仅命名效果预览传；null 表示不退回）。</param>
    public static List<NameFieldSegment> Build(
        IReadOnlyList<string> fields,
        string separator,
        Func<string, string?> resolveValue,
        IReadOnlyDictionary<string, string>? sampleFallback)
    {
        var segments = new List<NameFieldSegment>(fields.Count);
        var emitted = false;
        var literalBefore = false;
        for (var rowIndex = 0; rowIndex < fields.Count; rowIndex++)
        {
            var field = fields[rowIndex];
            if (FileNameFieldSpec.IsLiteral(field))
            {
                // 固定文本（横线）：自己就是分隔符，前面不补连接符，紧跟其后的字段也不补。
                segments.Add(new NameFieldSegment(field, field, field, true, "", rowIndex));
                emitted = true;
                literalBefore = true;
                continue;
            }

            // 一行的多个属性各占一段，都拼进文件名（不再只取第一个取到值的）。
            foreach (var candidate in FileNameFieldSpec.SplitCandidates(field))
            {
                var value = (resolveValue(candidate) ?? "").Trim();
                if (value.Length == 0 && sampleFallback != null
                    && sampleFallback.TryGetValue(candidate, out var sample)
                    && !string.IsNullOrWhiteSpace(sample))
                {
                    // 本图取不到真实值时退回拾取到的示例文字（仅预览用，真实文件名不退回）。
                    value = sample.Trim();
                }

                var found = value.Length > 0;

                // 连接符只加在真正参与文件名的段之间（与拼真实文件名的口径一致）。
                segments.Add(new NameFieldSegment(
                    candidate,
                    found ? candidate : "",
                    value,
                    found,
                    found && emitted && !literalBefore ? separator : "",
                    rowIndex));
                if (found)
                {
                    emitted = true;
                }

                literalBefore = false;
            }
        }

        return segments;
    }
}
