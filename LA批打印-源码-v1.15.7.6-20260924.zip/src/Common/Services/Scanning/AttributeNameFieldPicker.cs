using System;
using System.Collections.Generic;
using System.Linq;
#if AUTOCAD
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
#else
using ZwSoft.ZwCAD.ApplicationServices;
using ZwSoft.ZwCAD.DatabaseServices;
using ZwSoft.ZwCAD.EditorInput;
using ZwSoft.ZwCAD.Geometry;
#endif

namespace ZwcadBatchPlot;

/// <summary>
/// 拾取到的属性字段：<see cref="BlockName"/> 为属性所在的属性块名（空=不限块），
/// <see cref="Tag"/> 为属性名，<see cref="Sample"/> 为拾取时的属性值（仅作提示）。
/// 不使用 init 访问器：Common 源码还要编译进 net48 目标。
/// </summary>
internal sealed class PickedAttributeName
{
    public string BlockName { get; set; } = "";
    public string Tag { get; set; } = "";
    public string Sample { get; set; } = "";

    /// <summary>
    /// 该属性<b>实际所属的属性块名</b>（与 <see cref="BlockName"/> 不同：后者在"同名属性只来自一个块"
    /// 时会留空以写成不限块的字段，这里始终记真实块名，供「一个属性块 = 一行」的分组使用）。
    /// </summary>
    public string OwnerBlock { get; set; } = "";

    /// <summary>该属性所在位置（世界坐标）：面板据此判断"拾取的是清单里的哪张图"。</summary>
    public double PickedX { get; set; }
    public double PickedY { get; set; }

    /// <summary>列表项文本：「块名|属性名」，无块名时只有属性名。</summary>
    public string Field => FileNameFieldSpec.Compose(BlockName, Tag);
}

/// <summary>
/// 通用型批量打印「文件命名」的属性拾取器。两种方式都能用：
/// <list type="bullet">
/// <item>单击点中某个属性文字：把它<b>所在属性块的全部属性</b>一次收下（一行 = 一个块、多个属性）；
/// 取不到所属块（孤立的属性文字）时只收点中的这一个；</item>
/// <item>回车改用框选：把窗口内所有属性文字按位置顺序（从上到下、从左到右）一次性收下。</item>
/// </list>
/// 可以反复拾取逐次追加，ESC 结束。
/// 同名属性只来自一个属性块时按纯属性名收（别的图纸换了块名也照样能取到值）；
/// 同名属性分散在多个属性块上时才写成「块名|属性名」加以区分。
/// 拾取在 CAD 命令上下文（面板隐藏后）进行。
/// </summary>
internal static class AttributeNameFieldPicker
{
    /// <summary>嵌套块递归深度上限，防止自引用块定义无限展开。</summary>
    private const int MaxNestedDepth = 6;

    /// <summary>拾取到的一个属性候选。</summary>
    private sealed class AttributeCandidate
    {
        public string BlockName { get; set; } = "";
        public string Tag { get; set; } = "";
        public string Text { get; set; } = "";
        public Point3d Position { get; set; }
        /// <summary>文字高度（世界单位），用于"拾取点是否落在这个属性文字上"的判定。</summary>
        public double Height { get; set; }
        /// <summary>文字宽度因子，参与文字长度估算。</summary>
        public double WidthFactor { get; set; } = 1.0;
    }

    /// <summary>
    /// 反复拾取直到用户结束（ESC）。点击直接取该属性文字；在点选提示下按回车则改用框选，
    /// 一次收下范围内的全部属性文字。<paramref name="skippedCount"/> 为框选到空范围的次数。
    /// </summary>
    public static List<PickedAttributeName> Pick(Document? document, out int skippedCount)
    {
        skippedCount = 0;
        var picked = new List<PickedAttributeName>();
        if (document == null)
        {
            return picked;
        }

        var editor = document.Editor;
        var database = document.Database;
        // 框选只让块参照与属性文字参与选择，避免选到图线、标注等无关对象。
        var filter = new SelectionFilter(new[] { new TypedValue((int)DxfCode.Start, "INSERT,ATTRIB") });
        // 跨轮次去重：来回拾取也不会把同一个字段加两遍。
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var skipped = 0;
        // 点选走 CAD 的嵌套实体拾取（点中属性文字直接返回该属性）。
        // 万一某个平台不支持这个接口，就退化成纯框选，功能不至于完全不可用。
        var nestedSupported = true;

        while (true)
        {
            if (nestedSupported)
            {
                PromptNestedEntityResult? nested;
                try
                {
                    var options = new PromptNestedEntityOptions(
                        "\n点中要作为文件名的属性文字(回车=改用框选，Esc=结束): ")
                    {
                        AllowNone = true
                    };
                    nested = editor.GetNestedEntity(options);
                }
                catch
                {
                    nestedSupported = false;
                    nested = null;
                }

                if (nested != null)
                {
                if (nested.Status == PromptStatus.OK)
                {
                    var batch = ResolvePickedAttributes(database, nested);
                    if (batch == null || batch.Count == 0)
                    {
                        editor.WriteMessage(
                            "\n这里不是属性文字。请点中属性文字本身；想把一片区域里的属性一次全取，请按回车改用框选。");
                        continue;
                    }

                    // 点中一个属性 = 取它所在属性块的全部属性（一行 = 一个块、多个属性）。
                    var addedHere = AddBatch(picked, seen, batch);
                    var ownerName = batch[0].BlockName.Length > 0 ? $"「{batch[0].BlockName}」" : "该属性块";
                    editor.WriteMessage(addedHere > 0
                        ? $"\n已取 {ownerName} 的全部属性（共 {batch.Count} 个，本次新增 {addedHere} 个）。可继续点选，或回车改用框选。"
                        : $"\n{ownerName} 的属性都已在文件名字段列表中。可继续点选，或回车改用框选。");
                    continue;
                }

                    if (nested.Status != PromptStatus.None)
                    {
                        // 用户按了 ESC（或发生错误）：结束拾取。
                        break;
                    }
                }
            }

            // 回车（或点选接口不可用）→ 框选一轮，收下范围内全部属性文字；之后继续拾取。
            if (!PickByWindow(editor, database, filter, picked, seen, ref skipped))
            {
                break;
            }
        }

        skippedCount = skipped;
        return picked;
    }

    /// <summary>
    /// 框选一轮：把窗口内的属性文字（属性块上的属性，含嵌套块）按位置顺序
    /// 一次收下并追加到字段列表。返回 false 表示用户放弃了拾取（回车/ESC）。
    /// </summary>
    private static bool PickByWindow(
        Editor editor,
        Database database,
        SelectionFilter filter,
        List<PickedAttributeName> picked,
        HashSet<string> seen,
        ref int skipped)
    {
        PromptSelectionResult result;
        try
        {
            var options = new PromptSelectionOptions
            {
                MessageForAdding = "\n框选要作为文件名的属性文字(回车/Esc 结束): ",
                AllowDuplicates = false
            };
            result = editor.GetSelection(options, filter);
        }
        catch
        {
            return false;
        }

        if (result.Status != PromptStatus.OK || result.Value == null)
        {
            return false;
        }

        var ids = result.Value.GetObjectIds();
        if (ids == null || ids.Length == 0)
        {
            return false;
        }

        var batch = CollectSelection(database, ids);
        if (batch.Count == 0)
        {
            skipped++;
            editor.WriteMessage("\n框选范围内没有属性文字，已跳过（请框住标题栏这类带属性的属性块）。");
            return true;
        }

        var added = AddBatch(picked, seen, batch);
        var empty = batch.Count(candidate => candidate.Text.Length == 0);
        var emptyHint = empty > 0
            ? $"，其中 {empty} 个在本图为空（列表里显示灰色，不参与本图文件名）"
            : "";
        editor.WriteMessage(
            $"\n本次框选加入 {added} 个文件名字段（范围内共 {batch.Count} 个属性文字{emptyHint}）。"
            + "可继续拾取；想只取某一个属性文字时，直接点中那个文字即可。");
        return true;
    }

    /// <summary>
    /// 把"点中的嵌套实体"还原成<b>它所在属性块的全部属性</b>：点中属性文字（或某些平台点中属性块时
    /// 回的块参照）都收下<b>该属性块（含嵌套块）里的所有属性</b> —— 一行 = 一个块、多个属性，
    /// 每个属性各占一段拼进文件名。取不到所属块（孤立的属性文字）时只收点中的这一个。
    /// 返回 null 表示点中的不是属性文字 / 属性块。
    /// </summary>
    private static List<AttributeCandidate>? ResolvePickedAttributes(
        Database database,
        PromptNestedEntityResult nested)
    {
        try
        {
            using var tr = database.TransactionManager.StartTransaction();
            var id = nested.ObjectId;
            if (!id.IsValid || id.IsErased)
            {
                return null;
            }

            if (tr.GetObject(id, OpenMode.ForRead, false) is AttributeReference attribute)
            {
                var batch = new List<AttributeCandidate>();
                var ownerId = attribute.OwnerId;
                if (!ownerId.IsNull
                    && tr.GetObject(ownerId, OpenMode.ForRead, false) is BlockReference owner)
                {
                    CollectAttributes(
                        tr,
                        owner,
                        CadTextExtractor.GetBlockName(owner, tr),
                        owner.BlockTransform,
                        batch,
                        new HashSet<ObjectId>(),
                        new HashSet<ObjectId>(),
                        0);
                }

                if (batch.Count == 0)
                {
                    AddAttribute(batch, attribute, "", Matrix3d.Identity);
                }

                tr.Commit();
                return batch.Count > 0 ? batch : null;
            }

            if (tr.GetObject(id, OpenMode.ForRead, false) is BlockReference blockRef)
            {
                var batch = new List<AttributeCandidate>();
                CollectAttributes(
                    tr,
                    blockRef,
                    CadTextExtractor.GetBlockName(blockRef, tr),
                    blockRef.BlockTransform,
                    batch,
                    new HashSet<ObjectId>(),
                    new HashSet<ObjectId>(),
                    0);

                tr.Commit();
                return batch.Count > 0 ? batch : null;
            }

            return null;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// 把一轮拾取的结果并进字段列表：先从上到下（Y 降序）、再从左到右（X 升序）；
    /// 同名属性只来自一个属性块时用纯属性名，来自多个块时才写成「块名|属性名」。
    /// 返回本次真正新增的字段数。
    /// </summary>
    private static int AddBatch(
        List<PickedAttributeName> picked,
        HashSet<string> seen,
        List<AttributeCandidate> batch)
    {
        var ordered = batch
            .OrderByDescending(candidate => candidate.Position.Y)
            .ThenBy(candidate => candidate.Position.X)
            .ToList();

        var blocksByTag = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var candidate in ordered)
        {
            if (candidate.BlockName.Length == 0)
            {
                // 取不到块名（属性文字孤立被选中）时不参与"是否同名多块"的判断。
                continue;
            }

            if (!blocksByTag.TryGetValue(candidate.Tag, out var blocks))
            {
                blocks = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                blocksByTag[candidate.Tag] = blocks;
            }

            blocks.Add(candidate.BlockName);
        }

        var added = 0;
        foreach (var candidate in ordered)
        {
            var blockName = blocksByTag.TryGetValue(candidate.Tag, out var blocks) && blocks.Count > 1
                ? candidate.BlockName
                : "";
            var key = FileNameFieldSpec.Compose(blockName, candidate.Tag);
            if (key.Length == 0 || !seen.Add(key))
            {
                continue;
            }

            picked.Add(new PickedAttributeName
            {
                BlockName = blockName,
                Tag = candidate.Tag,
                Sample = candidate.Text,
                // 真实块名另存一份：分组（一个属性块 = 一行）要用它，而 BlockName 可能是空（不限块写法）。
                OwnerBlock = candidate.BlockName,
                PickedX = candidate.Position.X,
                PickedY = candidate.Position.Y
            });
            added++;
        }

        return added;
    }

    /// <summary>

    /// <summary>
    /// 展开一轮框选选中的对象：单独选中的属性文字取自身（块名取自其所属块参照），
    /// 块参照取其（含嵌套块）的全部属性；属性位置统一变换回世界坐标，
    /// 供"从上到下、从左到右"排序。
    /// </summary>
    private static List<AttributeCandidate> CollectSelection(Database database, ObjectId[] ids)
    {
        var batch = new List<AttributeCandidate>();
        // 已收集过的属性：属性文字常跟着所属块一起被选中，避免同一属性重复入列。
        var covered = new HashSet<ObjectId>();
        try
        {
            using var tr = database.TransactionManager.StartTransaction();
            foreach (var id in ids)
            {
                if (!id.IsValid || id.IsErased || !covered.Add(id))
                {
                    continue;
                }

                if (tr.GetObject(id, OpenMode.ForRead, false) is not Entity entity)
                {
                    covered.Remove(id);
                    continue;
                }

                if (entity is AttributeReference attribute)
                {
                    var ownerName = "";
                    var toWorld = Matrix3d.Identity;
                    var ownerId = attribute.OwnerId;
                    if (!ownerId.IsNull
                        && !covered.Contains(ownerId)
                        && tr.GetObject(ownerId, OpenMode.ForRead, false) is BlockReference owner)
                    {
                        ownerName = CadTextExtractor.GetBlockName(owner, tr);
                        toWorld = owner.BlockTransform;
                    }

                    AddAttribute(batch, attribute, ownerName, toWorld);
                    continue;
                }

                if (entity is BlockReference blockRef)
                {
                    CollectAttributes(
                        tr,
                        blockRef,
                        CadTextExtractor.GetBlockName(blockRef, tr),
                        blockRef.BlockTransform,
                        batch,
                        covered,
                        new HashSet<ObjectId>(),
                        0);
                }
            }

            tr.Commit();
        }
        catch
        {
            // 拾取期间任何读取失败（对象已删、事务异常）都按"没拾取到属性"处理。
        }

        return batch;
    }

    /// <summary>收下一个属性（属性名为空的不算）。</summary>
    private static void AddAttribute(
        List<AttributeCandidate> batch,
        AttributeReference attribute,
        string blockName,
        Matrix3d toWorld)
    {
        var tag = (attribute.Tag ?? "").Trim();
        if (tag.Length == 0)
        {
            return;
        }

        double widthFactor;
        try
        {
            widthFactor = attribute.WidthFactor;
        }
        catch
        {
            widthFactor = 1.0;
        }

        batch.Add(new AttributeCandidate
        {
            BlockName = blockName,
            Tag = tag,
            Text = (attribute.TextString ?? "").Trim(),
            Position = attribute.Position.TransformBy(toWorld),
            Height = attribute.Height,
            WidthFactor = widthFactor > 0 ? widthFactor : 1.0
        });
    }

    /// <summary>
    /// 递归收集块参照（含嵌套块）的属性，位置统一变换回世界坐标，并记下属性直接所属的块名。
    /// 同一块定义只展开一次，<paramref name="covered"/> 同时挡住"已被单独选中的属性"重复入列。
    /// </summary>
    private static void CollectAttributes(
        Transaction tr,
        BlockReference blockRef,
        string blockName,
        Matrix3d toWorld,
        List<AttributeCandidate> batch,
        ISet<ObjectId> covered,
        ISet<ObjectId> visitedDefinitions,
        int depth)
    {
        if (depth > MaxNestedDepth)
        {
            return;
        }

        var attributeCollection = blockRef.AttributeCollection;
        if (attributeCollection != null)
        {
            foreach (ObjectId attributeId in attributeCollection)
            {
                if (!attributeId.IsValid || attributeId.IsErased || !covered.Add(attributeId))
                {
                    continue;
                }

                if (tr.GetObject(attributeId, OpenMode.ForRead, false) is AttributeReference attribute)
                {
                    AddAttribute(batch, attribute, blockName, toWorld);
                }
            }
        }

        if (blockRef.BlockTableRecord.IsNull || !visitedDefinitions.Add(blockRef.BlockTableRecord))
        {
            return;
        }

        if (tr.GetObject(blockRef.BlockTableRecord, OpenMode.ForRead, false) is not BlockTableRecord definition)
        {
            return;
        }

        foreach (ObjectId id in definition)
        {
            if (tr.GetObject(id, OpenMode.ForRead, false) is not BlockReference nested)
            {
                continue;
            }

            // 嵌套块的属性在各自块坐标系里，叠加本层变换才能回到世界坐标。
            CollectAttributes(
                tr,
                nested,
                CadTextExtractor.GetBlockName(nested, tr),
                nested.BlockTransform * toWorld,
                batch,
                covered,
                visitedDefinitions,
                depth + 1);
        }
    }
}
