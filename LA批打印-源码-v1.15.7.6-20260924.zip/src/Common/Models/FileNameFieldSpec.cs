using System;
using System.Collections.Generic;
using System.Linq;

namespace ZwcadBatchPlot;

/// <summary>
/// 通用型批量打印「文件命名」列表项的文本规格：
/// <list type="bullet">
/// <item>只有属性名（如「图号」）= 不限属性块，该图框内任意属性块里名为「图号」的属性都算；</item>
/// <item>「块名|属性名」（如「标题栏|图号」）= 只取该属性块里的这个属性，
/// 用于同名属性分散在多个属性块上的场景（多个属性块上不同文字分别组成文件名）；</item>
/// <item>「图幅」（保留名，见 <see cref="PaperFieldName"/>）= 取该图纸识别出的图幅，
/// 不去属性块里找同名属性（要取属性块里的图幅属性请写「块名|图幅」）；</item>
/// <item>整项不含汉字/字母/数字（如「-」「/」）= 固定文本，原样拼进文件名并充当分隔。</item>
/// </list>
/// 列表输入框里就是这段文字，可直接编辑。
/// AutoCAD 块名不允许 &lt; &gt; / \ " : ; ? * | , = 等字符，故 <see cref="Separator"/> 不会与块名冲突。
/// </summary>
internal static class FileNameFieldSpec
{
    /// <summary>块名与属性名的分隔符。</summary>
    public const string Separator = "|";

    /// <summary>手动插入的固定文本的默认值：一条横线。</summary>
    public const string DefaultLiteral = "-";

    /// <summary>
    /// 「图幅」保留字段名：列表项正好是「图幅」时，取该图纸**识别出的图幅**（如 A2、A1+1∕2），
    /// 与图框块面板文件名占位符 T 同口径；不按属性名去图纸里找「图幅」属性。
    /// 想取属性块里的「图幅」属性，写成「块名|图幅」即可（带块名的写法一律走属性取值）。
    /// </summary>
    public const string PaperFieldName = "图幅";

    /// <summary>该项是否为「图幅」保留字段（整项就是「图幅」两字，允许首尾空白）。</summary>
    public static bool IsPaperField(string? field)
        => string.Equals((field ?? "").Trim(), PaperFieldName, StringComparison.Ordinal);

    /// <summary>
    /// 该项是否为「固定文本」（手动插入的横线「-」、斜杠「/」、间隔点「·」等）：
    /// 整项不含汉字/字母/数字时按字面量处理 —— 原样拼进文件名，并充当它前后的分隔，
    /// 不再拿它去图纸里找同名属性。
    /// </summary>
    public static bool IsLiteral(string? field)
    {
        var text = (field ?? "").Trim();
        if (text.Length == 0)
        {
            return false;
        }

        foreach (var ch in text)
        {
            // 属性名里可能出现的字符（汉字「图号」、字母「NO」、数字「A2」）一律按字段处理。
            if (char.IsLetterOrDigit(ch) || ch > 0x7F)
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>固定文本项的文本本身（已去空白）；不是固定文本时返回空串。</summary>
    public static string LiteralText(string? field)
    {
        var text = (field ?? "").Trim();
        return IsLiteral(text) ? text : "";
    }

    /// <summary>拼出列表项文本：无块名时只返回属性名。</summary>
    public static string Compose(string? blockName, string? tag)
    {
        var name = (blockName ?? "").Trim();
        var attribute = (tag ?? "").Trim();
        if (name.Length == 0)
        {
            return attribute;
        }

        return attribute.Length == 0 ? name : name + Separator + attribute;
    }

    /// <summary>拆分列表项文本；没有块名部分时 <paramref name="blockName"/> 为空。</summary>
    public static void Parse(string? field, out string blockName, out string tag)
    {
        var text = (field ?? "").Trim();
        var index = text.IndexOf(Separator, StringComparison.Ordinal);
        if (index <= 0 || index >= text.Length - 1)
        {
            // 不构成「块名|属性名」（无分隔符、以分隔符开头或结尾）时按纯属性名处理。
            blockName = "";
            tag = text;
            return;
        }

        blockName = text.Substring(0, index).Trim();
        tag = text.Substring(index + Separator.Length).Trim();
        if (blockName.Length == 0)
        {
            // 「|图号」这种写法等同不限块。
            tag = text.Trim();
        }
    }

    /// <summary>该图框作业里「块名|属性名」的字典键。</summary>
    public static string ScopeKey(string? blockName, string? tag)
        => (blockName ?? "").Trim() + Separator + (tag ?? "").Trim();

    // ── 一行多个字段（一个属性块 = 一行）──
    // 一行放一个属性块的多个字段：出图时<b>每个字段各占一段、都拼进文件名</b>（按行内顺序）。
    // 存储用 CandidateSeparator（"||"）：块名与属性名都不允许出现「|」，
    // 所以双竖线只可能是字段之间的分隔；界面显示用 CandidateDisplaySeparator（" / "）。

    /// <summary>一行里多个候选字段的分隔符（存储用，不出现在界面上）。</summary>
    public const string CandidateSeparator = "||";

    /// <summary>界面上一行里多个候选字段的显示分隔符。</summary>
    public const string CandidateDisplaySeparator = " / ";

    /// <summary>
    /// 拆分一行里的多个字段（保持先后顺序）；空项与重复项丢弃。
    /// ❗要取值时必须先拆开再逐个 <see cref="Parse"/>：整行直接 Parse 会把
    /// 「图号||标题栏|图号」错切成块名「图号」+ 属性「|图号」。
    /// </summary>
    public static List<string> SplitCandidates(string? row)
    {
        var candidates = new List<string>();
        var text = (row ?? "").Trim();
        var start = 0;
        while (start < text.Length)
        {
            var index = text.IndexOf(CandidateSeparator, start, StringComparison.Ordinal);
            if (index < 0)
            {
                AddCandidate(candidates, text.Substring(start));
                break;
            }

            AddCandidate(candidates, text.Substring(start, index - start));
            start = index + CandidateSeparator.Length;
        }

        return candidates;
    }

    /// <summary>把若干候选字段拼成一行（去空白、丢空项与重复项）；没有有效候选时返回空串。</summary>
    public static string JoinCandidates(IEnumerable<string>? candidates)
    {
        var parts = new List<string>();
        foreach (var candidate in candidates ?? Enumerable.Empty<string>())
        {
            AddCandidate(parts, candidate);
        }

        return parts.Count == 0 ? "" : string.Join(CandidateSeparator, parts);
    }

    /// <summary>界面输入框里的一行文本 → 候选字段（按「/」拆分；块名与属性名都不会含「/」）。</summary>
    public static List<string> SplitDisplayCandidates(string? text)
    {
        var parts = new List<string>();
        foreach (var part in (text ?? "").Split('/'))
        {
            AddCandidate(parts, part);
        }

        return parts;
    }

    /// <summary>一行在界面上的显示文本（多个候选用「 / 」连接）。</summary>
    public static string DisplayRow(string? row)
        => string.Join(CandidateDisplaySeparator, SplitCandidates(row));

    private static void AddCandidate(List<string> candidates, string? text)
    {
        var candidate = (text ?? "").Trim();
        if (candidate.Length == 0 || candidates.Contains(candidate, StringComparer.OrdinalIgnoreCase))
        {
            return;
        }

        candidates.Add(candidate);
    }
}
